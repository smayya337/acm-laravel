import java.util.Scanner;
import java.util.HashMap;
import java.util.ArrayList;
import java.io.*;

public class regulars {
  public static void main (String[] args) {
    Scanner kb = new Scanner(System.in);
    int cases = Integer.parseInt(kb.nextLine().trim());
    for (int k = 1; k <= cases; k++) {
      System.out.println("Case " + k + ":");
      int entries = Integer.parseInt(kb.nextLine().trim());
      HashMap<String, ArrayList> hm = new HashMap<String, ArrayList>();
      for (int i = 0; i < entries; i++) {
        String line = kb.nextLine();
        String[] llst = line.split(" ");
        line = line.substring(llst[0].length()+1, line.length());
        if (hm.get(llst[0]) == null) {
          hm.put(llst[0], new ArrayList<String>());
          hm.get(llst[0]).add(line);
        } else {
          hm.get(llst[0]).add(line);
        }
      }
      int peoples = Integer.parseInt(kb.nextLine().trim());
      for (int j = 0; j < peoples; j++) {
        String person = kb.nextLine().trim();
        ArrayList<String> eats = hm.get(person);
        HashMap<String, Integer> my_eats = new HashMap<String, Integer>();
        int max = 0;
        String dish = "";
        for (String s : eats) {
          if (my_eats.get(s) == null) {
            my_eats.put(s, 1);
            if (max == 0) {
              max = 1;
              dish = s;
            }
          } else {
            int new_val = my_eats.get(s)+1;
            my_eats.put(s, new_val);
            if (new_val > max) {
              max = new_val;
              dish = s;
            }
          }
        }

        if (eats.size() < 3) {
          System.out.println(person + " Not a regular");
        } else if (my_eats.size() == 1) {
          System.out.println(person + " " + dish);
        } else if (my_eats.size() >= 3) { 
          System.out.println(person + " Not a regular regular");
        } 
      }
      }
  }
}
