import java.util.*;

public class solution4 {

	public static void main(String[] args) {
		// Parse Input
		Scanner scanner = new Scanner(System.in);
		int numCases = scanner.nextInt();
		for (int i = 0; i < numCases; i++) {
			int numNodes = scanner.nextInt();
			double[][] map = new double[numNodes][numNodes]; // adjacency matrix
			int start = scanner.nextInt()-1;
			int goal = scanner.nextInt()-1;
			int numEdges = scanner.nextInt();
			for (int j = 0; j < numEdges; j++) {
				int from = scanner.nextInt()-1;
				int to = scanner.nextInt()-1;
				double probSurvive = scanner.nextDouble();
				map[from][to] = max(map[from][to], probSurvive);
			}

			// We'll be doing a modified Dijkstra's (longest path here)
			boolean[] known = new boolean[numNodes]; // keep track of what's done
			int numUnknown = numNodes;
			double[] distance = new double[numNodes]; // longest distance to node (best chance of survival)
			for (int j =0; j < numNodes; j++) {
				distance[j] = -Double.MAX_VALUE; // lowest possible value
				known[j] = false;
			}
			distance[start] = 1; // needs to be one since we're multiplying

			while (numUnknown >0) {
				int curr = 0;
				for (int q = 0; q < numNodes; q++) { // loop to get highest
					if (!known[q] && (distance[q] > distance[curr] || known[curr])) {
						
						 curr = q;
					}
				}
				known[curr] = true; // mark as known
				numUnknown--;
				for (int next = 0; next < numNodes; next++) {
					if(map[curr][next]-0.0 > .0000001 && !known[next]) { //adjacent and useful
						distance[next] = max(distance[next], distance[curr]*map[curr][next]);
					}
				}
					
			}	

			System.out.println("Case " + (i+1) + ": " +  distance[goal]);
		}
	}


	static double max(double a, double b) {
		if (b > a) return b;
		return a;
	}

}
