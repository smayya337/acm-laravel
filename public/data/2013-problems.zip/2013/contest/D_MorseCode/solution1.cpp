// Bloomfield's morse solution, 3-11-13
//
// I cheated and googled for 'morse code text file' because I didn't
// feel like typing it in myself
//
#include <iostream>
#include <string>
using namespace std;
string morse[] = {".-","-...","-.-.","-..",".","..-.","--.","....","..",".---","-.-",".-..","--","-.","---",".--.","--.-",".-.","...","-","..-","...-",".--","-..-","-.--","--.."};
int main() {
  int n, x;
  string s;

  //iterate over cases
  cin >> n;
  for ( int i = 1; i <= n; i++ ) {
    cout << "Case " << i << ": ";

    //iterate over 5 characters
    for ( int j = 0; j < 5; j++ ) {
      cin >> s;
      int index = -1; // yes, I could use a hash here
      //check string against each possible code in array
      for ( int k = 0; k < 26; k++ )
	if ( morse[k] == s )
	  index = k;//when found, keep the offset
      cout << (char)('A'+index);//take advantage of ASCII encoding for an elegant printing
    }
    cout << endl;
  }
}
