import java.util.*;

/*
 * Solves "Toad Puzzle" from HSPC 2017
 * Equivalent to "Theta Puzzle" (Problem I, Greater NY ICPC Regional 2009)
 */

public class puzzle {
  public static void main(String[] args) {
    Scanner cin = new Scanner(System.in);
    int P = cin.nextInt();
    
    //iterate over test cases
    for (int test = 0; test < P; test++) {
      int setNum = cin.nextInt();
      String startingConfig = cin.next(); //read next word
      
      //Solve the puzzle
      solvePuzzle(new Node(startingConfig + "X"), setNum);
    }
  }
 
  //Solves puzzle with BFS
  public static void solvePuzzle(Node start, int testNum) {
    //Handle special case: start node *is* end node
    if (start.isFinal()) {
      System.out.printf("%d 0\n", testNum);
      return;
    }
    
    //Initialization of BFS
    Queue<Node> stack = new LinkedList<Node>();
    Set<Node> visited = new HashSet<Node>();
    stack.add(start);
    visited.add(start);
    Node currNode = start;
    boolean found = false;
    
    //Loop through the stack!
    while(!stack.isEmpty() && !found) {
      currNode = stack.remove();
      
      if (currNode.isFinal()) {
        found = true; //We found it!
      }
      else { //Add unvisited neighbors to the stack
        for (Node n : currNode.getNeighbors()) {
          if (!visited.contains(n)) {
            stack.add(n);
            visited.add(n);
          }
        }
      }      
    } 
    
    //Outputs
    if (found)
      System.out.printf("%d %d\n", testNum, currNode.dist); // currNode.history has the actual solution
    else if (stack.isEmpty())
      System.out.printf("%d NO SOLUTION\n", testNum);
    else
      System.out.println("error");
  }
}

class Node {
  public char[] state; //This uniquely identifies a node
  public String history; //This stores the path to get to the node
  public int dist; //This is the shortest distance from the start node
  
  public Node(String state) {
    this.state = state.toCharArray();
    this.history = "";
    this.dist = 0;
  }
  
  public Node(char[] state, String history, int dist) {
    this.state = state;
    this.history = history;
    this.dist = dist;
  }
  
  //Does the logic to find the neighbors of this node
  public ArrayList<Node> getNeighbors() {
    ArrayList<Node> neighbors = new ArrayList<Node>();
    
    int xLoc = indexOf(state, 'X');
    
    if (xLoc == 6) { //The blank is in the center of the ring
      neighbors.add(new Node(swap(state, 6, 1), history + state[1], dist + 1));
      neighbors.add(new Node(swap(state, 6, 4), history + state[4], dist + 1));
    }
    else if (xLoc < 6) { //if the blank is on the ring:
      //Shift CW
      int nextXLoc = (xLoc == 5) ? 0 : xLoc + 1;
      char swapChar = state[nextXLoc];
      neighbors.add(new Node(swap(state, xLoc, nextXLoc), history + swapChar, dist + 1));
      
      //Shift CCW:
      nextXLoc = (xLoc == 0) ? 5 : xLoc - 1;
      swapChar = state[nextXLoc];
      neighbors.add(new Node(swap(state, xLoc, nextXLoc), history + swapChar, dist + 1));

      
      if (xLoc == 1)
        neighbors.add(new Node(swap(state, 1, 6), history + state[6], dist + 1)); //Swap with center
      if (xLoc == 4)
        neighbors.add(new Node(swap(state, 4, 6), history + state[6], dist + 1)); //Swap with center
    }
    
    return neighbors;
    
  }
  
  @Override
  public boolean equals(Object o) {
    Node n = (Node) o; //Cast unsafe
    String s1 = new String(this.state);
    String s2 = new String(n.state);
    return s1.equals(s2);
  }
  
  //Apparently, HashSet needs this... :(
  @Override
  public int hashCode()  {
    return (new String(state)).hashCode();
  }
  
  public boolean isFinal() {  
    return (new String(state)).equals("ABCDEFX");
  }
 
  /////Problem specific methods/////
  
  //Finds the "free" slot
  private static int indexOf(char[] a, char c) {
    for (int i = 0; i < a.length; i++) {
      if (a[i] == c) return i;
    }
    return -1;
  }
  
  //Swaps two characters in the state string
  private static char[] swap(char[] a, int i, int j) {
    char[] b = new char[a.length];
    System.arraycopy(a, 0, b, 0, a.length);
    
    b[j] = a[i];
    b[i] = a[j];
    
    return b;
  }
}
