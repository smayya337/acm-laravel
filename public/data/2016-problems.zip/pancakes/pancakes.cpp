#include <iostream>
using namespace std;

int main() {
    int t;
    cin >> t;

    for(int i = 0; i < t; i++) {
        int n;
        cin >> n;
        // The idea used here is to use the closed-form solution of the towers of hanoi problem,
        // which gives the solution easily in the form (2^n)-1
        long long l = (1l << n) - 1;
        cout << "Case " << i+1 << ": " << l << endl;
    }
}
