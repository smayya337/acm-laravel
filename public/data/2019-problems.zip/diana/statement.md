# Target Practice

Everyone knows that the best archer of Mount Olympus is Diana, the Goddess of the Hunt. However, her twin brother Apollo disagrees, so he challenges her to an archery contest. Little does he know that the reason for Diana's skill is her understanding of physics that allows her to never miss.


Every shot in this competition is taken from the origin of a Cartesian plane towards a target at some position (x, y). The arrow is fired with velocity $v_i$ m/s at an angle of $\theta$ radians above the +x axis.

The equations governing the flight of an arrow are:


$v_y = v_i * sin(\theta)$


$v_x = v_i * cos(\theta)$


$x = v_x * t$


$y = v_y * t - \frac{1}{2}*9.8*t^2$



Diana will always hit the target exactly. Given the x-position of the target (in m) find the height, or y-position, of her target.
