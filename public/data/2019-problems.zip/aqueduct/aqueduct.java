import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedList;

public class Aqueduct {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int cases = Integer.parseInt(br.readLine());
        for(int k = 0; k < cases; k++) {
            String line = br.readLine();
            String[] lineParts = line.split(" ");
            int sectionCount = Integer.parseInt(lineParts[0]);
            int connections = Integer.parseInt(lineParts[1]);
            Section[] sections = new Section[sectionCount];
            for (int i = 0; i < sectionCount; i++) {
                line = br.readLine();
                lineParts = line.split(" ");
                sections[Integer.parseInt(lineParts[0])] = new Section(Integer.parseInt(lineParts[1]), Integer.parseInt(lineParts[2]), Integer.parseInt(lineParts[3]));
            }
            for (int j = 0; j < connections; j++) {
                line = br.readLine();
                lineParts = line.split(" ");
                int s1 = Integer.parseInt(lineParts[0]);
                int s2 = Integer.parseInt(lineParts[1]);
                if (sections[s1].topHeight == sections[s2].bottomHeight) {
                    sections[s2].connected.add(sections[s1]);
                    sections[s1].incoming++;
                } else {
                    sections[s1].connected.add(sections[s2]);
                    sections[s2].incoming++;
                }
            }
            Section[] topSorted = new Section[sectionCount];
            int idx = 0;
            LinkedList<Section> queue = new LinkedList<>();
            for (Section s : sections)
                if (s.incoming == 0)
                    queue.add(s);
            while (!queue.isEmpty()) {
                Section s = queue.removeFirst();
                topSorted[idx++] = s;
                for (Section s2 : s.connected)
                    if (--s2.incoming == 0)
                        queue.add(s2);
            }
            for (int i = 0; i < sections.length; i++) {
                for (Section s : topSorted[i].connected) {
                    s.maximumDistance = Math.max(s.maximumDistance, topSorted[i].maximumDistance + topSorted[i].length);
                }
            }
            int max = 0;
            for (Section s : sections) {
                max = Math.max(max, s.maximumDistance + s.length);
            }
            System.out.println(max);
        }
    }
    static class Section {
        public int topHeight, bottomHeight;
        public int length;
        public ArrayList<Section> connected = new ArrayList<>();
        public int incoming = 0;
        public int maximumDistance = 0;

        public Section(int start, int end, int length) {
            this.topHeight = start;
            this.bottomHeight = end;
            this.length = length;
        }
    }
}
