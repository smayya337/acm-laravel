import java.io.*;
import java.util.*;

public class solution3 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int numCases = in.nextInt();
		for(int aaa=1;aaa<=numCases;aaa++) {
			int M = in.nextInt();
			int N = in.nextInt();
			int P = in.nextInt();
			kid[] kids = new kid[P];
			for(int i=0;i<P;i++)
				kids[i] = new kid(in.next(), in.nextInt(), in.nextInt(), in.next());
			int step = in.nextInt();
			for(int a=0;a<step;a++) {
				for(kid k : kids)
					k.step(M, N);
				for(int i=0;i<P;i++) {
					ArrayList<kid> colliding = new ArrayList<kid>();
					for(int j=i;j<P;j++) {
						if(!kids[j].resolved && kids[i].x == kids[j].x && kids[i].y == kids[j].y)
							colliding.add(kids[j]);
					}
					if(colliding.size() == 1) {
						colliding.get(0).resolved = true;
					} else if(colliding.size() == 2) {
						kid shorter = colliding.get(0);
						kid longer = colliding.get(1);
						if(shorter.name.length() > longer.name.length()) {
							kid tmp = shorter;
							shorter = longer;
							longer = tmp;
						}
						int lX = longer.xDiff;
						int lY = longer.yDiff;
						longer.xDiff = shorter.xDiff;
						longer.yDiff = shorter.yDiff;
						shorter.xDiff = -lX;
						shorter.yDiff = -lY;
						shorter.resolved = true;
						longer.resolved = true;
					} else {
						for(kid k : colliding) {
							k.resolved = true;
							k.xDiff *= -1;
							k.yDiff *= -1;
						}
					}
				}
			}
			kid closest = kids[1];
			double closestDist = kids[1].dist(kids[0]);
			for(int i=2;i<P;i++) {
				double dist = kids[i].dist(kids[0]);
				if(dist < closestDist && Math.abs(dist - closestDist) > 0.0001) {
					closestDist = dist;
					closest = kids[i];
				} else if(Math.abs(dist - closestDist) <= 0.0001) {
					if(kids[i].name.length() < closest.name.length()) {
						closest = kids[i];
					}
				}
			}
			System.out.println("Case " + aaa + ": " + closest.name);
		}
	}
}

class kid {
	String name;
	int x;
	int y;
	int xDiff;
	int yDiff;
	boolean resolved = false;
	
	public kid(String name, int x, int y, String dir) {
		this.name = name;
		this.x = x;
		this.y = y;
		if(dir.equals("N")) {
			yDiff = 1;
			xDiff = 0;
		} else if(dir.equals("S")) {
			yDiff = -1;
			xDiff = 0;
		} else if(dir.equals("E")) {
			yDiff = 0;
			xDiff = 1;
		} else {//W
			yDiff = 0;
			xDiff = -1;
		}
	}
	
	public void step(int W, int H) {
		resolved = false;
		int newX = x + xDiff;
		int newY = y + yDiff;
		if(newX < 0 || newX >= W || newY < 0 || newY >= H) {
			xDiff *= -1;
			yDiff *= -1;
			newX = x + xDiff;
			newY = y + yDiff;
		}
		x = newX;
		y = newY;
	}
	
	public double dist(kid o) {
		double xD = x - o.x;
		double yD = y - o.y;
		return xD*xD + yD*yD;
	}
}
