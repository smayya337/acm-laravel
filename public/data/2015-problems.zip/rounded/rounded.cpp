#include<iostream>
#include<string>
using namespace std;

/*
 * Solves Problem 4 from the 2015 HSPC.
 * Andrew Norton (apn4za)
 */

bool isRound(char c);

int main() {
    int N;
    cin >> N;

    for (int i = 0; i < N; i++) {
        string s;
        cin >> s;
        bool rounded = true;
        for (int j = 0; j < s.size(); j++)
            rounded &= isRound(s[j]);

        cout << (rounded ? "ROUNDED" : "NOT ROUNDED") << endl;
    }

    return 0;
}

bool isRound(char c) {
    return (c=='B') || (c=='C') || (c=='D') ||
           (c=='G') || (c=='J') || (c=='O') ||
           (c=='P') || (c=='Q') || (c=='R') ||
           (c=='S') || (c=='U') || (c=='2') ||
           (c=='3') || (c=='5') || (c=='6') ||
           (c=='8') || (c=='9') || (c=='0');
}
