#include <iostream>
#include <string>
#include <fstream>



using namespace std;

int main() {
    int numProblems;
    cin >> numProblems;

    for (int prob = 1; prob <= numProblems; prob++) {
        int numRegions;
        cin >> numRegions;

        string* colors = new string[numRegions];
        int ignore;
        for (int i = 0; i < numRegions; i++) {
            cin >> ignore >> colors[i];
        }

        int numBorders;
        cin >> numBorders;
        bool valid = true;
        for (int i = 0; i < numBorders; i++) {
            int b1,b2;
            cin >> b1 >> b2;
            if (!valid || colors[b1] == colors[b2]) {
                valid = false;
            }
        }

        if (valid) {
            cout << "valid" << endl;
        } else {
            cout << "invalid" << endl;
        }

        delete[] colors;
        colors = NULL;
    }
}
