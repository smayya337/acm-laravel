#include <iostream>
#include <map>
#include <vector>
#include <string>
using namespace std;

int main() {
  int n, x;
  map<int,vector<int> > m;
  string control;
  
  cin >> n;
  for ( int i = 0; i < n; i++ ) {
    cin >> x; // how many nodes
    m.clear();
    for ( int j = 0; j < x; j++ )
      m[j] = vector<int>(x,0);
    
    for ( int j = 0; j < x; j++ ) {
      cin >> control;
      for ( int k = 0; k < x; k++ )
	if ( control[k] == '1' )
	  m[j][k] = 1;
    }

#ifdef DEBUG
    cout << "Case " << (i+1) << " map: " << endl;
    for ( int j = 0; j < x; j++ ) {
      cout << "\t" << j << ":";
      for ( int k = 0; k < x; k++ )
	if ( m[j][k] == 1 )
	  cout << " -> " << k;
      cout << endl;
    }
#endif

    


  }
  return 0;
}
