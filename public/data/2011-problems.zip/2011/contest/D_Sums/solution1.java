import java.util.*;
public class ArithGeoChris
{
	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		while(n > 0)
		{
			int a = in.nextInt();
			int b = in.nextInt();
			int c = in.nextInt();
			int d = b - a;
			if(c - b == d)
				System.out.println((int)(n*(2*a + (n-1)*d)/2));
			else
			{
				int r =b/a;
				System.out.println((int)(a*(1 - ((int)Math.pow(r,n)))/(1-r)));
			}
			n = in.nextInt();
		}
	}
}
