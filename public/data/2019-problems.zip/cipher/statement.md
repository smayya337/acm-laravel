# Caesar's Cipher

Caesar has discovered an ingenious way to encode his messages. By shifting the value of each letter in his messages, he can make sure that Brutus will never discover his plans! Your job as Caesar's $scriba$ is to encode Caesar's messages.

To encode a message, each lowercase character $c$ is shifted by $v$, the shifting value, positions in the alphabet to produce the character $s$. For example, if $c=\textsc{\char13}r\textsc{\char13}$ and $v=4$, the shifted value will be $s=\textsc{\char13}t\textsc{\char13}$. All letters in the messages will be lowercase, and overflow past the last letter of the alphabet $\textsc{\char13}z\textsc{\char13}$ cycles through the start of the alphabet. Thus, if $c=\textsc{\char13}u\textsc{\char13}$ and $v=8$, $s=\textsc{\char13}c\textsc{\char13}$.

Given a message and a shifting value, $v$, what will the encoded message be?