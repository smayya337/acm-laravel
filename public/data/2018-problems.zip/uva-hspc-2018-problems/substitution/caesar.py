import sys

def caesar(s):
    return ''.join([' ' if c == ' ' else chr(((ord(c) - ord('A') + 13) % 26) + ord('A')) for c in s])

nCases = int(sys.stdin.readline())
for i in range(nCases):
    s = sys.stdin.readline().strip()
    print(caesar(s))
