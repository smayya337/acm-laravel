/**
 * input generator for substitution
 *
 * This must be compiled with -std=c++11
 *
 * run with a random seed (via command-line parameter) of 4 to
 * generate the wordgrid.judge.in file.
 *
 * Written by Aaron Bloomfield, 2018
 */

#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <fstream>
using namespace std;

int numrandomcases = 200;

int numfixedcases = 4;
const char* fixedcases = R"(defghijklmnopqrstuvwxyzabc
zdooh dqg hyh juhz d sodqw
wjseqvofacugtyhxmpdnikrlzb
winh ad yh ghyoqp ay sfwpoq hv nfq wlaht
wjseqvofacugtyhxmpdnikrlzb
w
wjseqvofacugtyhxmpdnikrlzb
wjseqvofacugtyhxmpdnikrlzb
)";

const char* fixedcases_ans = R"(walle and eve grew a plant
auto is no longer in charge of the axiom
a
abcdefghijklmnopqrstuvwxyz
)";

int main(int argc, char *argv[]) {
  // handle random seed
  int seed = time(NULL);
  if ( argc == 2 )
    sscanf(argv[1],"%d",&seed);
  srand(seed);

  // create list of letters
  string letters;
  for ( int i = 0; i < 26; i++ )
    letters.push_back('a' + i);

  cout << (numrandomcases+numfixedcases) << "\n" << fixedcases;
  for ( int i = 0; i < numrandomcases; i++ ) {
    // create map of letters
    random_shuffle(letters.begin(),letters.end());
    cout << letters << endl;
    // create random string
    int length = rand() % 50 + 3;
    string text;
    for ( int j = 0; j < length; j++ )
      if ( (j == 0) || (j == length-1) || (rand() % 10 < 9) )
	text.push_back((char)(rand()%26 + 'a'));
      else
	text.push_back(' ');
    cout << text << endl;
  }

  return 0;
}


