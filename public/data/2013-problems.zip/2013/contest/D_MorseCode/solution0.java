import java.util.Scanner;

public class Morse2 {

    public static void main (String[] args) 
    {
        Scanner s = new Scanner(System.in);
        
        int n = s.nextInt();

	//iterate over cases        
        for (int i = 0; i < n; i++)
        {
            System.out.print("Case " + (i + 1) + ": ");
             
	    //iterate over 5 characters
            for(int j = 0; j < 5; j++){
                String code = s.next();
                
		//check each case
                if(code.equals(".-"))
                    System.out.print("A");
                    
                else if(code.equals("-..."))
                    System.out.print("B");
                    
                else if(code.equals("-.-."))
                    System.out.print("C");
                    
                else if(code.equals("-.."))
                    System.out.print("D");
                    
                else if(code.equals("."))
                    System.out.print("E");
                    
                else if(code.equals("..-."))
                    System.out.print("F");
                    
                else if(code.equals("--."))
                    System.out.print("G");
                    
                else if(code.equals("...."))
                    System.out.print("H");
                    
                else if(code.equals(".."))
                    System.out.print("I");
                    
                else if(code.equals(".---"))
                    System.out.print("J");
                    
                else if(code.equals("-.-"))
                    System.out.print("K"); 
                                       
                else if(code.equals(".-.."))
                    System.out.print("L");
                    
                else if(code.equals("--"))
                    System.out.print("M");
                    
                else if(code.equals("-."))
                    System.out.print("N");
                    
                else if(code.equals("---"))
                    System.out.print("O");
                    
                else if(code.equals(".--."))
                    System.out.print("P");
                    
                else if(code.equals("--.-"))
                    System.out.print("Q");
                    
                else if(code.equals(".-."))
                    System.out.print("R");
                    
                else if(code.equals("..."))
                    System.out.print("S");
                    
                else if(code.equals("-"))
                    System.out.print("T");  
                                      
                else if(code.equals("..-"))
                    System.out.print("U");
                    
                else if(code.equals("...-"))
                    System.out.print("V");
                    
                else if(code.equals(".--"))
                    System.out.print("W");
                    
                else if(code.equals("-..-"))
                    System.out.print("X");
                    
                else if(code.equals("-.--"))
                    System.out.print("Y");
                    
                else if(code.equals("--.."))
                    System.out.print("Z"); 
                                                      
            }
            System.out.println();  
        }
    }
}
