#include <iostream>
#include <vector>
#include <queue>

using namespace std;

#define MAX(v1, v2) v1 > v2 ? v1 : v2

struct Section {
    int top, bottom, length;
    int incoming = 0;
    int max_dis = 0;
    vector<Section*> connected = {};
    Section(int top, int bottom, int length) :
        top{ top }, bottom{ bottom }, length{ length }{}
};

int main(int argc, char** argv){
    int cases;
    cin >> cases;
    for(int caseno = 0; caseno < cases; caseno++){
        int sectionCount, connections;
        cin >> sectionCount >> connections;
        Section** sections = new Section*[sectionCount];
        for(int i = 0; i < sectionCount; i++){
            int n1, n2, n3, n4;
            cin >> n1 >> n2 >> n3 >> n4;
            sections[n1] = new Section(n2, n3, n4);
        }
        for(int i = 0; i < connections; i++){
            int s1, s2;
            cin >> s1 >> s2;
            if(sections[s1]->top == sections[s2]->bottom){
                sections[s2]->connected.emplace_back(sections[s1]);
                sections[s1]->incoming++;
            } else {
                sections[s1]->connected.emplace_back(sections[s2]);
                sections[s2]->incoming++;
            }
        }

        vector<Section*> topo_sorted = {};
        queue<Section*> queue = {};
        for(int i = 0; i < sectionCount; i++){
            if(sections[i]->incoming == 0)
                queue.push(sections[i]);
        }
        while(queue.size() != 0){
            Section* section = queue.front();
            queue.pop();
            topo_sorted.emplace_back(section);
            for(auto s2 : section->connected){
                if(--s2->incoming == 0){
                    queue.push(s2);
                }
            }
        }

        for (int i = 0; i < sectionCount; i++) {
            for (auto s : topo_sorted[i]->connected) {
                s->max_dis = MAX(s->max_dis, topo_sorted[i]->max_dis + topo_sorted[i]->length);
            }
        }
        int max = 0;
        for (int i = 0; i < sectionCount; i++) {
            max = MAX(max, sections[i]->max_dis + sections[i]->length);
        }
        cout << max << std::endl;

        for(int i = 0; i < sectionCount; i++)
            delete sections[i];

        delete [] sections;
    }
}
