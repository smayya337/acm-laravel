#include <vector>
#include <iostream>
using namespace std;

vector< vector<int>* >* findRolls(int dice, int sides, int sum);

int main() {
  int caseNum = 0;
  cin >> caseNum;
  int *cases = new int[caseNum*3];
  for (int i =0; i < caseNum; i++) {
    cin >> cases[(i*3)+0]; //dice
    cin >> cases[(i*3)+1]; //sides
    cin >> cases[(i*3)+2]; //sum
  }
  
  for (int i = 0; i < caseNum; i++) {
    cout << "Case " << (i+1) << ":" << endl;
    vector< vector<int>* >* rolls = findRolls(cases[(i*3)+0], cases[(i*3)+1], cases[(i*3)+2]);
    for(unsigned int j = 0; j < rolls->size(); j++) {
      vector<int> * roll = (*rolls)[j];
      roll = (*rolls)[j];
      cout << "(";
      for(int k = 0; k < cases[(i*3)+0]-1; k++) {
	cout << (*roll)[k] << ",";
      }
      cout << (*roll)[cases[(i*3)+0]-1] << ")" << endl;
    }
  }
}

vector< vector<int>* >* findRolls(int dice, int sides, int sum) {
  vector< vector<int>* > *rolls = new vector< vector<int>* >();
  if(dice < 1 || sides < 2 || sum < dice || sum > dice*sides) {
    return rolls;
  }
  
  else if (dice==1) {
    vector<int> *roll = new vector<int>();
    roll->push_back(sum);
    rolls->push_back(roll);
    return rolls;
  }
  for(int i = 1; i <= sides; i++) {
    vector< vector<int>* > *partialRolls = findRolls (dice-1, sides, sum-i);
    
    for(unsigned int j = 0; j < partialRolls->size(); j++) {
      vector<int> *partialRoll = (*partialRolls)[j];
      vector<int> *roll = new vector<int>();
      roll->push_back(i);
      for (unsigned int k = 1; k <= partialRoll->size(); k++) {
	roll->push_back((*partialRoll)[k-1]);
      }
      bool add = true;
      
      for(unsigned int k = 1; k < roll->size(); k++) {
	if((*roll)[k] < (*roll)[k-1])
	  add = false;
      }
      if(add)
	rolls->push_back(roll);
    }
  }
  return rolls;
}
