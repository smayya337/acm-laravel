// Solves "Coins" from the 2017 HSPC at UVa
// Solution by Marina Sanusi, 2017

import java.util.*;

public class coins {
  public static void main(String[] args) {
    Scanner kb = new Scanner(System.in);

    // Iterate over each case
    int numCases = kb.nextInt();
    kb.nextLine();
    // 13, 5, 462
    for (int currCase = 0; currCase < numCases; currCase++) {
      String[] line = kb.nextLine().trim().split(" ");
      int money = 13*Integer.parseInt(line[0]) + 5*Integer.parseInt(line[1]) + 462*Integer.parseInt(line[2]);
      System.out.println(money);

    }

  }
}
  

