The first line of the input will be a single integer $n \le 10,000$. There will be $n$ test cases that follow.

Each test case consists of two lines. On the first line will be the shifting value $0 \leq v \leq 128$, and on the second will be the plain message from Caesar. Each message will consist of only lowercase characters (a-z) and spaces.