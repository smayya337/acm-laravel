import java.util.*;

public class solution2 {
    public static void main(String[] args) {
	Scanner stdin = new Scanner(System.in);
	int numCases = stdin.nextInt();
	for(int aaa=1;aaa<=numCases;aaa++) {
		int pow = stdin.nextInt();
		System.out.print("Case " + aaa + ": ");
	    System.out.print (pow-1);
	    for ( ; pow > 0; pow-- )
		System.out.print(" " + stdin.nextInt()*pow);
	    stdin.nextInt(); // reading in the x^0 coefficient
	    System.out.println();
	}
    }
}
