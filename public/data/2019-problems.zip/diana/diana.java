import java.util.Scanner;
public class Diana{
    public static void main(String[] args) throws Exception{
        dianaSolve();
    }
    public static void dianaSolve()throws Exception{
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        for (int i = 0; i < n; i++) {
            double v = scan.nextDouble();
            double theta = scan.nextDouble();
            double x = scan.nextDouble();
            double vy = v * Math.sin(theta);
            double vx = v * Math.cos(theta);
            double t = x/vx;
            System.out.println(vy * t - .5 * 9.8 * Math.pow(t, 2));
        }
    }
}
