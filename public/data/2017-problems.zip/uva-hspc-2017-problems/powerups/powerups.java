// Solves "Power-up Probability" from the 2017 HSPC at UVa
// Solution by Andrew Norton, 2017

import java.util.*;

/*
 * Main concept: building a "frequency map" (e.g. how many times does a certain
 * string occur in a dataset), then finding the maximum of this.
 */
public class powerups {
  public static void main(String[] args) {
    Scanner cin = new Scanner(System.in);
    int numCases = cin.nextInt();
    
    for (int currCase = 0; currCase < numCases; currCase++) {
      // this hashmap maps powerup type to the number of times it occurs in the list
      HashMap<String, Integer> freqCount = new HashMap<String, Integer>();

      int numItems = cin.nextInt();
      for (int i = 0; i < numItems; i++) {
        String itemName = cin.next();

        // this is, essentially, freqCount[itemName] += 1, but handles non-existent keys
        freqCount.put(itemName, 1 + freqCount.getOrDefault(itemName, 0));
      }

      // Now, we get to iterate over the whole map and find the most common item
      int highestCount = 0;
      String highestKey = "Tie";
      for (Map.Entry<String, Integer> e : freqCount.entrySet()) {
        int currCount = e.getValue();

        if (currCount > highestCount) {
          // If it beats our current best item, replace it!
          highestCount = currCount;
          highestKey   = e.getKey();
        }
        else if (currCount == highestCount) {
          // If it ties our current best item, set the output to "Tie"
          highestKey = "Tie";
        }
        // If it doesn't beat or tie the best item, move on to the next item
      }

      // Print out the result!
      System.out.println(highestKey);
    }

  }
}
