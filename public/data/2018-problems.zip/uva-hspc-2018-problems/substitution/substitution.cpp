/*
 * C++ solution to caesar
 *
 * by Aaron Bloomfield, 2018
 */

#include <iostream>
#include <string>
#include <map>
using namespace std;

int main() {
  int n;
  string line, themap;
  cin >> n;
  getline(cin,line); // read in \n on line
  for ( int i = 0; i < n; i++ ) {
    cin >> themap;
    getline(cin,line); // read in \n on line
    getline(cin,line);
    // create decryption map
    map<char,char> m;
    for ( int j = 0; j < 26; j++ )
      m[themap[j]] = 'a' + j;
    m[' '] = ' ';
    // decrypt line
    for ( int j = 0; j < line.length(); j++ )
      cout << m[line[j]];
    cout << endl;
  }
  return 0;
}
