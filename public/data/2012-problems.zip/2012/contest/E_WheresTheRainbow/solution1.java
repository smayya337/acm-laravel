/**Problem: Wheres the Rainbow
* Solver: Matthew Hurtz mnh7mc@virginia.edu
* Problem Writers: Matthew Hurtz (mnh7mc) and Allison Light (aml9j)
* Time Taken: 10 min
**/

import java.util.*;


public class solution1 {
	
	public static void process() {
		Scanner fin = new Scanner(System.in);
		
		int numCases = fin.nextInt();
		
		for(int i=0;i<numCases;i++) {
			double h = fin.nextDouble();
			double theta = fin.nextDouble();
			
			if (h == 0 && theta == 0) break;
			
			double x = h / Math.tan(Math.toRadians(theta)) - h;
			x = Math.abs(x);
			
			System.out.println("Case " + (i+1) + ": " + x);
		}
	}
	
	public static void generateIO() {
		Random r = new Random(15);
		int numCases = 10000;
		System.out.println(numCases);
		for(int i=0;i<numCases;i++) {
			double h = r.nextDouble()*50000+1;
			double theta = r.nextDouble()*90;
			System.out.printf("%.1f %.1f\n", h, theta);
		}
	}
	
	public static void main(String[] args) {
		process();
		//generateIO();
	}

}
