#include <iostream>
using namespace std;
int main() {
  cout << "Pixar" << endl;
  return 0;
}
