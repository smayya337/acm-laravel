import java.util.Scanner;


public class Clocks {
    public static void main (String[] args) {
        Scanner k = new Scanner(System.in);
        int n = k.nextInt();
        for ( int i = 0; i < n; i++ ) {
            int hours = k.nextInt();
            int minutes = k.nextInt();

            String[] start = k.next().split(":");
            String[] end = k.next().split(":");

            double[] overlaps = findOverlapTimes(hours,minutes);

            double start_time = Double.parseDouble(start[0]) + Double.parseDouble(start[1])/minutes;
            double end_time = Double.parseDouble(end[0]) + Double.parseDouble(end[1])/minutes;

            int mint = -1;
            int maxt = overlaps.length - 1;
            while(start_time > overlaps[mint+1]) {
                mint++;
            }
            while(end_time < overlaps[maxt]) {
                maxt--;
            }
            System.out.println(maxt-mint);
        }
        k.close();
    }

    public static double[] findOverlapTimes(int hours, int minutes) {
        double hourHandSpeed = ((double) hours) / ((double) (hours - 1));
        double[] times = new double[hours];
        for(int i = 0; i < hours; i++) {
            times[i] = hourHandSpeed*i;
        }
        times[hours-1] = (double) hours;
        return times;
    }
}
