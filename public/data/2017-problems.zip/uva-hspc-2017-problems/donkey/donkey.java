// Solves "donKEY Kong" from the 2017 HSPC at UVa
// Solution by Andrew Norton, 2017

import java.util.*;

public class donkey {
  private static char shift(char c, int key) {
    if (c != '_')
      return (char)((c - 'A' + key) % 26 + 'A'); // Shift, but wrap around from Z to A
    else
      return '_';
  }

  public static void main(String[] args) {
    Scanner cin = new Scanner(System.in);
    int numCases = cin.nextInt();
    cin.nextLine(); // Discard the newline character

    for (int i = 0; i < numCases; i++) { // For each case
      String ciphertext1 = cin.nextLine(); // get the first ciphertext/plaintext pairing
      String plaintext1  = cin.nextLine();
      
      // Compute the key (note: this is the *decode* key, not the encode key)
      int key = ((int)plaintext1.charAt(0) - (int)ciphertext1.charAt(0) + 26) % 26;

      String ciphertext2 = cin.nextLine();

      // Decode and print!
      System.out.printf("Case %d: ", i+1);
      for (Character c : ciphertext2.toCharArray()) {
        System.out.print(shift(c, key));
      }
      System.out.println();

    }
  }
}
