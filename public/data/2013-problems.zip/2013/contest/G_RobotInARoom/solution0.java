import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class SolveRobot {
	public static void main(String[] args){
		Scanner scan = new  Scanner(System.in);
		int numberRooms = scan.nextInt();
		//read in the number of games
		//iterate through the games
		for(int room=1; room <= numberRooms; room++){
			int Dimension = scan.nextInt();
			int Power = scan.nextInt();
			int fullPower = Power;
			int halfPower = fullPower/2;
			char thisRoom[][] = new char[Dimension][Dimension];
			for(int i = 0; i < Dimension; i++){
				thisRoom[i] = scan.next().toCharArray();
			}
			System.out.println(room+" "+Dimension+" "+Power);

			//iterate through the room and find the robot and the mess
			int robotX=-1,robotY=-1,messX=-1,messY=-1;
			for(int x = 0; x < Dimension; x++){
				for(int y = 0; y < Dimension; y++){
					if(thisRoom[x][y] == 'r'){
						//then this is robot!
						robotX = x;
						robotY = y;
					}else if(thisRoom[x][y] == 'm'){
						//then this is mess!
						messX = x;
						messY = y;
					}
				}
			}
			String direction = "right";
			//create a history table, it's a 2D array arrays (aka a 3d array)
			//if the robot has been in the same place facing the same direction
			//then we are stuck in a loop, so we will never get there
			String history[][][] = new String[Dimension][Dimension][4];
			int time = 0;
			while(Power >= 0){
				//If we are at the mess, we're done
				if(robotX == messX && robotY == messY){
					System.out.println("Case " + room + ": " + time);
					break;
				}
				
				//if we have been here in the same direction before, we're in a loop
				//right = 0
				//left = 1
				//up = 2
				//down = 3
				if((direction == "right" && history[robotX][robotY][0] != null)
						|| (direction == "left" && history[robotX][robotY][1] != null)
						|| (direction == "up" && history[robotX][robotY][2] != null)
						|| (direction == "down" && history[robotX][robotY][3] != null)
						|| (Power == 0)){
					//I've been here before! i'm in an infinite loop!
					System.out.println("Case " + room + ": NEVER");
					break;
				}else{
					//I haven't been here before, mark that I'm here
					if(direction == "right"){
						history[robotX][robotY][0] = "visited";
					}else if(direction == "left"){
						history[robotX][robotY][1] = "visited";
					}else if(direction == "up"){
						history[robotX][robotY][2] = "visited";
					}else if(direction == "down"){
						history[robotX][robotY][3] = "visited";
					}
				}
				
				
				//if we are near a power outlet and power less than halfPower, then stop to charge
				if(thisRoom[robotX+1][robotY] == 'p'
						|| thisRoom[robotX-1][robotY] == 'p'
						|| thisRoom[robotX][robotY+1] == 'p'
						|| thisRoom[robotX][robotY-1] == 'p'){
					if(Power <= halfPower){
						time += fullPower - Power;
						Power = fullPower;
					}
				}
				
				//Find the next space, if it is open, move there. if not, turn right
				int nextX, nextY;
				if(direction == "up"){
					nextX = robotX-1;
					nextY = robotY;
				}else if(direction == "down"){
					nextX = robotX+1;
					nextY = robotY;
				}else if(direction == "right"){
					nextX = robotX;
					nextY = robotY+1;
				}else{
					nextX = robotX;
					nextY = robotY-1;
				}
				if(thisRoom[nextX][nextY] == '-' || thisRoom[nextX][nextY] == 'm' || thisRoom[nextX][nextY] == 'r'){
					robotX = nextX;
					robotY = nextY;
				}else{
					//turn right
					if(direction == "up"){
						direction = "right";
					}else if(direction == "right"){
						direction = "down";
					}else if(direction == "down"){
						direction = "left";
					}else if(direction == "left"){
						direction = "up";
					}
				}
				//decrease the power and increase the timestep
				Power--;
				time++;
			}			
		}
	}
}