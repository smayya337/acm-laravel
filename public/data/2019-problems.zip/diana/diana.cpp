#include <iostream>
#include <stdio.h>
#include <string>
#include <cmath>

using namespace std;

int main(){
 int cases;
 cin >> cases;
 for(int i = 0; i < cases; i++){
   double v0, theta, x;
   cin >> v0 >> theta >> x;
   double vy = v0 * sin(theta);
   double vx = v0 * cos(theta);
   double t = x / vx;
   printf("%0.3f\n", vy * t - 4.9 * t * t);
 }
}
