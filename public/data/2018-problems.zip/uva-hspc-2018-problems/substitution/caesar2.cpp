/*
 * C++ solution to caesar
 *
 * by ???, 2018
 */

#include <iostream>
#include <string>

using namespace std;

int main() {
    int nCases; 
    cin >> nCases;
    string line; 
    getline(cin, line);
    for (int i = 0; i < nCases; i++) {
       getline(cin, line);
       string out(line.length(), ' ');
       for (int j = 0; j < line.length(); j++) {
           if (line[j] == ' ')
               out[j] = ' ';
           else
               out[j] = ((line[j] - 'A' + 13) % 26) + 'A';
       }

       cout << out << endl;
    }
}
