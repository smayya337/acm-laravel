import java.util.*;
import java.io.*;

public class Rounded {
    public static void main(String[] args) {
        Set<Character> rounded = new HashSet<Character>();
        rounded.add('B');
        rounded.add('C');
        rounded.add('D');
        rounded.add('G');
        rounded.add('J');
        rounded.add('O');
        rounded.add('P');
        rounded.add('Q');
        rounded.add('R');
        rounded.add('S');
        rounded.add('U');
        rounded.add('2');
        rounded.add('3');
        rounded.add('5');
        rounded.add('6');
        rounded.add('8');
        rounded.add('9');
        rounded.add('0');

        Scanner sc = new Scanner(System.in);
        int testCases = Integer.parseInt(sc.nextLine());
        for (int i = 0; i < testCases; i++) {
            String nextWord = sc.nextLine();
            boolean roundedWord = true;
            for (int j = 0; j < nextWord.length(); j++) {
                char c = nextWord.charAt(j);
                if (!rounded.contains(c)) {
                    roundedWord = false;
                    break;
                }
            }
            if (roundedWord)
                System.out.println("ROUNDED");
            else
                System.out.println("NOT ROUNDED");
        }
    }
}
