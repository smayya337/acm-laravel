#include <iostream>
#include <cstdio>
using namespace std;

int main() {
  int numCases;
  cin >> numCases;
  for (int i = 0; i < numCases; i++) {
    string unit;
    cin >> unit;
    float temp;
    cin >> temp;  
    float convertedTemp = -1;
    if (unit == "f") {
      convertedTemp = 5.0/9.0 * (temp - 32);
    }
    else {
      convertedTemp = 9.0/5.0 * temp + 32;
    } 
    printf("%.2f\n", convertedTemp);
  }
}
