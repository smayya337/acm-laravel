import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Scanner;

public class Circus {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int cases = sc.nextInt();
        for (int caseno = 0; caseno < cases; caseno++) {
            int people = sc.nextInt();
            ArrayList<String> names = new ArrayList<>();
            HashMap<String, Double> times = new HashMap<>();
            for (int i = 0; i < people; i++) {
                String name = sc.next();
                names.add(name);
                times.put(name, sc.nextDouble());
            }
            names.stream().sorted(Comparator.comparingDouble(times::get)).forEach(System.out::println);
        }
    }
}
