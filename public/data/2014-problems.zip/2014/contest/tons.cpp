#include <iostream>
using namespace std;

int main() {
    while(true) {
        int a,b,c;
        cin >> a >> b >> c;
        if (a == 0 && b == 0 && c == 0) {
            break;
        }
        int n1=a;
        int n2=b;
        for (int i = 0; i < c; i++) {
            int temp = n1;
            n1 = n2;
            n2 = n1 + temp;
        }
        cout << n2 << endl;
    }
}
