/**
 * input generator for ratatoullie
 *
 * This must be compiled with -std=c++11
 *
 * run with a random seed (via command-line parameter) of 4 to
 * generate the wordgrid.judge.in file.
 *
 * Written by Aaron Bloomfield, 2018
 */

#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <fstream>
#include <sstream>

using namespace std;

int numrandomcases = 100;

int numfixedcases = 2;
const char* fixedcases = R"(5 3
1 apples
3 onions 
2 eggs
5 beans
1 pepper
3
1 apples
1 onions
4 beans
1
2 beans
1
1 oranges
2 3
4 beans
2 avacados
1
2 beans
2
2 beans
1 orange
2 
2 beans
2 avacados
)";

const char* fixedcases_ans = R"(Case 1:
Yes
No
No
Case 2:
Yes
No
Yes
)";

int main(int argc, char *argv[]) {
  // handle random seed
  int seed = time(NULL);
  if ( argc == 2 )
    sscanf(argv[1],"%d",&seed);
  srand(seed);

  // create list of 100 ingredients
  vector<string> in;
  for ( int i = 0; i < 100; i++ ) {
    stringstream str;
    str << "ingredient" << i;
    in.push_back(str.str());
  }

  cout << (numrandomcases+numfixedcases) << "\n" << fixedcases;
  for ( int i = 0; i < numrandomcases; i++ ) {
    // how many ingredients and recipies are in this test case?
    int numi = rand() % 45 + 5; // 5 to 50
    int numr = rand() % 18 + 2; // 2 to 20
    cout << numi << " " << numr << endl;
    // generate ingredients
    random_shuffle(in.begin(),in.end());
    auto itin = in.begin(); // the iterator at the end of the ingredients for this test case
    for ( int j = 0; j < numi; j++ ) {
      cout << (rand() % 15 + 5) << " " << in[j] << endl;
      itin++;
    }
    // how many recipies?
    for ( int j = 0; j < numr; j++ ) {
      int numii = rand() % 8 + 2; // 2 to 8
      cout << numii << endl;
      random_shuffle(in.begin(),itin);
      for ( int k = 0; k < numii; k++ ) {
	if ( rand() % 20 < 2 ) // 10% change that an unknown ingredient
	  cout << (rand() % 5 + 1) << " unknownIngredient" << rand() << endl;
	else // a known ingredient
	  cout << (rand() % 5 + 1) << " " << in[k] << endl;
      }
    }
  }
  return 0;
}


