# Solves "Coins" from the 2017 HSPC at UVa
# Solution by Andrew Norton, 2017

from sys import stdin
from operator import mul

if __name__ == '__main__':
  data = stdin.read().splitlines()[1:]
  rates = [13, 5, 462]

  for row in data:
    amts  = [int(n) for n in row.split()]

    # "map" applies "mul" to each item of amts and rates, and "sum" adds them up
    #   So, this is equivalent to:
    #   amts[0]*rates[0] + amts[1]*rates[1] + amts[2]*rates[2]
    print(sum(map(mul, amts, rates)))
