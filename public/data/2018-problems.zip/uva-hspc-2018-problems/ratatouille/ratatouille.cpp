/*
 * C++ solution to ratatoullie
 *
 * by Aaron Bloomfield, 2018
 */

#include <iostream>
#include <map>
#include <string>
using namespace std;

int main() {
  int n, i, r, x, p;
  string s;
  
  cin >> n;
  for ( int m = 0; m < n; m++ ) {
    cout << "Case " << (m+1) << ":" << endl;
    cin >> i >> r;
    // read in ingredients into map
    map<string,int> ing;
    for ( int j = 0; j < i; j++ ) {
      cin >> x >> s;
      //cout << s << ": " << x << endl;
      ing[s] = x;
    }
    // read in recipes
    for ( int j = 0; j < r; j++ ) {
      cin >> p; // how many ingredients in this recipe
      map<string,int> rec;
      // read in the recipe
      for ( int k = 0; k < p; k++ ) {
	cin >> x >> s;
	//cout << s << ": " << x << endl;
	rec[s] = x;
      }
      // can we make it?
      bool cando = true;
      for ( auto it = rec.begin(); it != rec.end(); it++ )
	if ( ing[it->first] < it->second ) {
	  cando = false;
	  break;
	}
      if ( !cando ) {
	cout << "No" << endl;
	continue;
      } else
	cout << "Yes" << endl;
      // make recipe
      for ( auto it = rec.begin(); it != rec.end(); it++ )
	ing[it->first] -= it->second;
    }
  }
  return 0;
}
