// Solves "Sortle!" from the 2017 HSPC at UVa
// Solution by Andrew Norton, 2017

import java.util.*;

public class sortle {
  public static void main(String[] args) {
    Scanner cin = new Scanner(System.in);

    // Iterate over each case
    int numCases = cin.nextInt();
    for (int currCase = 0; currCase < numCases; currCase++) {
      int numPokemons = cin.nextInt();

      Pokemon[] friendList = new Pokemon[numPokemons]; // Allocate array for all the pokemons
      for (int i = 0; i < numPokemons; i++) {
        String name = cin.next();
        String type = cin.next();
        friendList[i] = new Pokemon(name, type); // create a new pokemon for each one in the list
      }

      Arrays.sort(friendList); // Uses the "compareTo" method in the Pokemon class

      System.out.printf("Case %d:\n", currCase + 1);
      for (int i = 0; i < numPokemons; i++) {
        System.out.println(friendList[i]);
      }
    }

  }
  
  // An object to describe a single Pokemon.
  // Just has name and type fields (of type string)
  // Has "compareTo" and "toString" methods
  private static class Pokemon implements Comparable<Pokemon> {
    private String name;
    private String type;
    
    public Pokemon(String name, String type) {
      this.name = name;
      this.type = type;
    }

    // Sort based on type first, then name 
    public int compareTo(Pokemon other) {
      if (this.type.equals(other.type)) {
        return this.name.compareTo(other.name);
      }
      else {
        return this.type.compareTo(other.type);
      }
    }

    public String toString() {
      return String.format("%s %s", this.name, this.type);
    }
    
  }

}
