import java.util.Scanner;

public class eye {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        while(true) {
            int x = in.nextInt();
            int y = in.nextInt();
            if(x == 0 && y == 0)
                break;
            System.out.println((int)Math.round(Math.toDegrees(Math.atan2(y, x))));
        }
    }
}
