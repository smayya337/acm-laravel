import java.util.*;

/* 
 * Solution to "N Queens" from UVA HSPC 2018
 * 
 * Unlike the other solutions, this one is iterative.
 * The formula is:
 *     solution = SUM(k>=0; (5^k)*PRODUCT(0<= j <= k; floor(n/2^j)))
 * Since the product is zero when 2^j is bigger than n, we can stop summing after k > log_2(n).
 *
 * "Wait!" you say.  "How does that formula describe the solution?"
 * The easiest way to see this is likely to work out some example cases. Here's a hand-wavy justification:
 * 
 * The ant hierarchy can be represented by a tree with grouped nodes. On the kth level of the tree, there 
 * are 5*floor(n/2^k) more nodes than on the k-1st level.  This is because each node on the k-1st level 
 * has 5 child groups, where each child group has floor(n/2^k) nodes.  We can invoke mathematical induction 
 * (or pattern-finding, if you're not into rigorous proofs) to show that the kth level then has 
 * (5^k)*PRODUCT(0<= j <= k; floor(n/2^j)) nodes.  
 * 
 * Since this was only for one level, we have to sum over all levels of the tree; the tree stops when we can't 
 * divide the subgroups into any smaller nodes.  The number of times we can divide n by 2 is floor(log_2(n)), so
 * that's when we want to stop.  It turns out we can keep adding past that, because the summands are zero when k 
 * is bigger than the log_2(n), so that lets me just use ceil(log_2(n)) because it's easier to compute.
 */
public class ants {

  // In main, just handle input processing and call a solver function
  public static void main(String[] args) {
    Scanner cin = new Scanner(System.in);

    int x = cin.nextInt(); // number of test cases
    
    for (int i = 0; i < x; i++) {
      int n = cin.nextInt();
      System.out.println(solve(n));
    }
    
  }

  // Implements the formula above
  private static long solve(int n) {
    int sumSize = logBaseTwo(n);
    
    long result = 0;
    long multiplier = 1;
    for (int i = 0; i < sumSize; i++, multiplier *= 5) {
      long subProduct = 1;

      // Product(j=0 to i of floor(n/2^j))
      for (int j = 0; j <= i; j++) {
        subProduct *= n >> j;
      }

      result += multiplier * subProduct;
    }

    return result;
  }

  // Returns the ceiling(log_2(n))
  private static int logBaseTwo(int n) {
    int retVal;

    for(retVal = 0; n > 0; n >>= 1, retVal++);

    return retVal;
  }
}
