#include <iostream>
#include <string>
#include <cstdlib>
using namespace std;
#define N 100
#define SEED 4
string ids[] = { "Mewtwo", "Ganondorf", "Pikachu", "ShigeruMiyamoto", "Luigi", "PrincessZelda", "Red", "Mario", "SamusAran", "Link" };
int main() {
  cout << N << endl;
  // special cases (6)
  cout << "1\nrelease\n";
  cout << "1\ncopy Link\n";
  cout << "2\ncopy Link\ncopy Link\n";
  cout << "3\ncopy Link\nrelease\ncopy Samus\n";
  cout << "6\nrelease\ncopy Link\ncopy Mario\nrelease\nrelease\ncopy Bowser\n";
  cout << "4\ncopy Link\ncopy Link\ncopy Link\nrelease\n";
  // random cases
  srand(SEED);
  for ( unsigned int i = 6; i < N; i++ ) {
    unsigned int size = rand() % 100 + 1;
    if ( i > N-3 )
      size = 1000;
    cout << size << endl;
    for ( unsigned int j = 0; j < size; j++ ) {
      if ( rand() % 2 == 0 )
	cout << "release" << endl;
      else
	cout << "copy " << ids[rand()%10] << endl;
    }
  }
  return 0;
}

