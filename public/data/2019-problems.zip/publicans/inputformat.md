The first line of the input will be a single integer, $n \leq 1,000$. There will be $n$ test cases that follow.

Each test case begins with a single integer $p$ denoting the number of people in Rome, $1 \leq p \leq 10,000$.  The next line will contain $p$ space separated integers, $0 < v_i < 10,000$, denoting the amount of taxes that each citizen would pay if they decided to pay.
