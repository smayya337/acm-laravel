#include <iostream>
#include <string>
using namespace std;

int main(int argc, char* argv[])
{
  int times;

  cin >> times;
  //iterate over cases
  for(int i = 1; i <= times; i++)
    {
      cout << "Case " << i << ": ";
      
      //iterate over 5 characters
      for(int j = 0; j < 5; j++)
	{
	  string character;
	  cin >> character;
	  
	  //check each possible letter
	  if(character.compare(".-") == 0)
	    {
	      cout << "A";
	    }
	   if(character.compare("-...") == 0)
	    {
	      cout << "B";
	    }
	  else if(character.compare("-.-.") == 0)
	    {
	      cout << "C";
	    }
	  else if(character.compare("-..") == 0)
	    {
	      cout << "D";
	    }
	  else if(character.compare(".") == 0)
	    {
	      cout << "E";
	    }
	  else if(character.compare("..-.") == 0)
	    {
	      cout << "F";
	    }
	  else if(character.compare("--.") == 0)
	    {
	      cout << "G";
	    }
	  else if(character.compare("....") == 0)
	    {
	      cout << "H";
	    }
	  else if(character.compare("..") == 0)
	    {
	      cout << "I";
	    }
	  else if(character.compare(".---") == 0)
	    {
	      cout << "J";
	    }
	  else if(character.compare("-.-") == 0)
	    {
	      cout << "K";
	    }
	  else if(character.compare(".-..") == 0)
	    {
	      cout << "L";
	    }
	  else if(character.compare("--") == 0)
	    {
	      cout << "M";
	    }
	  else if(character.compare("-.") == 0)
	    {
	      cout << "N";
	    }
	  else if(character.compare("---") == 0)
	    {
	      cout << "O";
	    }
	  else if(character.compare(".--.") == 0)
	    {
	      cout << "P";
	    }
	  else if(character.compare("--.-") == 0)
	    {
	      cout << "Q";
	    }
	  else if(character.compare(".-.") == 0)
	    {
	      cout << "R";
	    }
	  else if(character.compare("...") == 0)
	    {
	      cout << "S";
	    }
	  else if(character.compare("-") == 0)
	    {
	      cout << "T";
	    }
	  else if(character.compare("..-") == 0)
	    {
	      cout << "U";
	    }
	  else if(character.compare("...-") == 0)
	    {
	      cout << "V";
	    }
	  else if(character.compare(".--") == 0)
	    {
	      cout << "W";
	    }
	  else if(character.compare("-..-") == 0)
	    {
	      cout << "X";
	    }
	  else if(character.compare("-.--") == 0)
	    {
	      cout << "Y";
	    }
	  else if(character.compare("--..") == 0)
	    {
	      cout << "Z";
	    }
	}
      cout << "\n";
    }

  return 0;
}
