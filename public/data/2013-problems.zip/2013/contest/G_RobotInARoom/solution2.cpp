// Bloomfield's robot solution, 3-14-13
#include <iostream>
#include <string>
using namespace std;

char map[100][100]; // (0,0) is the upper left
enum direction { north, east, south, west };
string dirs[] = { "north", "east", "south", "west" };
int dx[] = { 0, 1, 0, -1 };
int dy[] = { -1, 0, 1, 0 };

int main() {
  int x, y, num, n, d, startx, starty;

  //iterate over cases
  cin >> num;
  for ( int i = 1; i <= num; i++ ) {
    // read in board
    cin >> n >> d;
    for ( int yy = 0; yy < n; yy++ )
      for ( int xx = 0; xx < n; xx++ ) {
	cin >> map[xx][yy];
	if ( map[xx][yy] == 'r' ) {
	  x = xx;
	  y = yy;
	}
      }



    int time = 0, power = d, dir = east;
    bool finished = false;
    while ( power > 0 ) {

      char next = map[x+dx[dir]][y+dy[dir]];
      switch (next) {
      case 'p': // wall with outlet
	// FALL THRU
      case 'x': // wall
	//turning right
	dir = ++dir % 4; // turn right
	time++;          // takes 1 unit of time
	power--;         // and 1 unit of power
	break;
      case 'r': // start location
	// FALL THRU
      case '-': // spot to move
	x += dx[dir];
	y += dy[dir];
	time++;
	power--;
	break;
      case 'm': // mess
	time++;
	finished = true;
	break;
      default:
	break;
      }
      if ( finished ) 
	break;
      if ( ((map[x+dx[north]][y+dy[north]] == 'p') || 
	    (map[x+dx[east]][y+dy[east]] == 'p') || 
	    (map[x+dx[south]][y+dy[south]] == 'p') || 
	    (map[x+dx[west]][y+dy[west]] == 'p')) &&
	   (power*2 <= d) ) {
	//recharging
	time += d-power;
	power = d;
      }

      //assume you'd find a solution by now
      if ( time > 100 )
	break;
    }

    //give output 
    if ( finished )
      cout << "Case " << i << ": " << time << endl;
    else
      cout << "Case " << i << ": NEVER" << endl;
  }
}
