import java.util.Scanner;

public class gullet {

    public static void main(String args[]) {
        Scanner keyboard = new Scanner(System.in);
        int space = keyboard.nextInt();
        while (space != 0) {
            int numItems = keyboard.nextInt();
            int[] itemVolumes = new int[numItems];
            int[] itemCalories = new int[numItems];
            for (int i = 0; i < numItems; i++) {
                itemVolumes[i] = keyboard.nextInt();
                itemCalories[i] = keyboard.nextInt();
            }
            knapsack(space, numItems, itemVolumes, itemCalories);
            space = keyboard.nextInt();
        }
        keyboard.close();
    }

    public static void knapsack(int space, int numItems, int[] itemVolumes,
                                int[] itemCalories) {
        int[][] quantity = new int[space + 1][numItems];
        int[][] optimal = new int[space + 1][2];
        for (int i = 1; i < space + 1; i++) {
            int tally = -1;
            optimal[i][0] = optimal[i - 1][0];
            optimal[i][1] = optimal[i - 1][1];
            for (int j = numItems - 1; j > -1; j--) {
                if (i - itemVolumes[j] < 0
                        || optimal[i - itemVolumes[j]][1] + itemVolumes[j] > space) {
                    continue;
                }
                int newCalories = optimal[i - itemVolumes[j]][0]
                                  + itemCalories[j];
                int newVolume = optimal[i - itemVolumes[j]][1] + itemVolumes[j];
                if (optimal[i][0] < newCalories) {
                    optimal[i][0] = newCalories;
                    optimal[i][1] = newVolume;
                    tally = j;
                }
            }
            if (tally > -1) {
                for (int j = 0; j < numItems; j++) {
                    quantity[i][j] = quantity[i - (itemVolumes[tally])][j];
                }
                quantity[i][tally]++;
            } else {
                for (int j = 0; j < numItems; j++) {
                    quantity[i][j] = quantity[i - 1][j];
                }
            }
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < numItems; i++) {
            sb.append(quantity[space][i]);
            if(i<numItems-1)
                sb.append(" ");
        }
        System.out.println(sb.toString());
    }
}
