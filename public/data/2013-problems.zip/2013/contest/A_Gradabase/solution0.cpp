#include <iostream>
#include <string>
using namespace std;

int main(int argc, char* argv[])
{
  int times;

  cin >> times;
  //iterate over cases
  for(int i = 1; i <= times; i++)
    {
      int rows;
      cin >> rows;
	  
      cout << "Case " << i << ":" << endl;
      
      //iterate over students
      for(int j = 0; j < rows; j++)
	{
	  int student;
	  cin >> student;

	  //increment, but print if not graduated
	  if(++student <= 6)
	    {
	      cout << student << '\n';
	    }
	}
    }
  
  return 0;
}
