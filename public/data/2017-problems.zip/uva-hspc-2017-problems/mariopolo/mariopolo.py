# Solves "Mario Polo" from the 2017 HSPC at UVa
# Solution by Andrew Norton, 2017

from sys import stdin

if __name__ == '__main__':
  data = stdin.read().splitlines()
  for row in data[1:]: # iterate over all lines except the first 
    if row == 'Mario':
      print('Polo')
    else:
      print('Silence')
  
