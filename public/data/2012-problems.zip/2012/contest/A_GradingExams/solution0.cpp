/**Problem: Hamming Distance
* Solver: Chris Jones cmj7gh@virginia.edu
* Problem Writers: Peter Chapman and Matt Henderson
* Time Taken: 3 min
* Overall Thoughts: Really straight forward - definitely an easy problem. Creative use for it
* Things to fix: the output for the first test case was incorrect, the answer should be 2
**/



#include <iostream>
using namespace std;
int main(){
	int numProblems;
	cin >> numProblems;
	for(int p=1; p<=numProblems; p++){
		int numChars;
		cin >> numChars;
		char answersGiven[numChars];
		char answerKey[numChars];
		for(int c=0; c<numChars; c++){
			cin >> answersGiven[c];
		}
		for(int c=0; c<numChars; c++){
			cin >> answerKey[c];
		}
		int distance = 0;
		
		for(int c=0; c<numChars; c++){
			if(answersGiven[c] != answerKey[c])
				distance++;
		}
		cout << "Case " << p << ": " << distance << endl;
	}
}

