# Solves "Practice" from the 2017 HSPC at UVa
# Solution by Joseph Tobin, 2017

from sys import stdin
if __name__ == '__main__':
  # Read in all the lines of input
  data = stdin.read().splitlines()
  data = data[1:] # Ignore the number of cases

  for row in data:
    print(int(row) * int(row))
