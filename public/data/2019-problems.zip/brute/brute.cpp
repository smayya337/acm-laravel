#include <iostream>
#include <stdio.h>
#include <string>

using namespace std;

double probability(double* probs, int** rooms, int minutes, int room){
   if(minutes == 0)
       return 1;//probs[room];
   return (probability(probs, rooms, minutes - 1, rooms[room][0] - 1) + probability(probs, rooms, minutes - 1, rooms[room][1] - 1) + probability(probs, rooms, minutes - 1, rooms[room][2] - 1) + probability(probs, rooms, minutes - 1, rooms[room][3] - 1)) / 4 * probs[room];
}

int main(){
 int cases;
 cin >> cases;
 for(int i = 0; i < cases; i++){
   int roomCnt, minutes;
   cin >> roomCnt >> minutes;
   int* rooms[roomCnt];
   double probs[roomCnt];
   for(int j = 0; j < roomCnt; j++){
       int* cons = (int*) malloc(4 * sizeof(int));
       cin >> probs[j] >> cons[0] >> cons[1] >> cons[2] >> cons[3];
       rooms[j] = cons;
   }
   printf("%.3f\n", probability(probs, (int**) rooms, minutes, 0));
 }
}
