# Solves "High Scores!" from the 2017 HSPC at UVa
# Solution by Andrew Norton, 2017

from sys import stdin
from itertools import takewhile

# Returns true if all elements in some iterable x are the same
def all_same(x):
  return len(set(x)) == 1

# Uses python magic to find the common prefix of a list of strings
# Returns a list of characters
def common_prefix(str_list): 
  return [x[0] for x in takewhile(all_same, zip(*str_list))]
  # breakdown:
  #   zip(*str_list) makes a list of tuples from the strings.  E.g.
  #     ['Martha', 'Martin', 'Marina'] -> [('M', 'M', 'M'), ('a', 'a', 'a'), ('r', 'r', 'r'), ('t', 't', 'i'), ...]
  #   takewhile(all_same, - ) returns an iterable of the tuples as long as they are all the same letter.  E.g.
  #     [The list above] -> [ ('M', 'M', 'M'), ('a', 'a', 'a'), ('r', 'r', 'r') ]
  #   [ x[0] for x in - ] creates a list from only the first element of each tuple.  E.g. 
  #     [List above] -> ['M', 'a', 'r']
  #   ...and that's the common prefix!

if __name__ == '__main__':
  data = stdin.read().splitlines()[1:]
  i = 0

  while i < len(data):
    num_items = int(data[i])

    # Splice out the strings we care about
    str_list  = data[i+1:i+1+num_items]

    prefix    = common_prefix(str_list)

    if prefix:
      print(''.join(prefix)) # print the list out as a single string
    else:
      print('No Common Prefix')

    i += 1 + num_items


