import java.util.*;
import java.io.*;

public class legions{
    /*
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        for(int i = 0; i < n; i++){
            int v = input.nextInt();
            System.out.println(v * 1500 + "");
        }
    }
    */
    
    //For legions.judge.out
    public static void main(String[] args) throws IOException{
        Scanner input = new Scanner(new File("legions.judge.in"));
        PrintWriter writer = new PrintWriter("legions.judge.out", "UTF-8");
        int n = input.nextInt();
        for(int i = 0; i < n; i++){
            int v = input.nextInt();
            writer.println(v * 1500 + "");
        }
        writer.flush();
    }
}