// Solves "Kirby Your Enthusiasm" from the 2017 HSPC at UVa
// Solution by Aaron Bloomfield, 2017

#include <iostream>
#include <string>
using namespace std;
int main() {
  unsigned int n, t;
  string s;
  cin >> n;
  for ( int i = 0; i < n; i++ ) {
    cin >> t;
    string state = "Kirby";
    for ( int j = 0; j < t; j++ ) {
      cin >> s;
      if ( s == "release" ) {
	state = "Kirby";
	continue;
      }
      cin >> s;
      if ( state == "Kirby" )
	state = s;
    }
    cout << state << endl;
  }
  return 0;
}
