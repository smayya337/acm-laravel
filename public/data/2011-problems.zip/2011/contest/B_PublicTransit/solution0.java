import java.util.*;
import java.text.*;
public class TransitChris
{
	public static void main(String[] args)
	{
		new TransitChris();
		
		
	}
	public TransitChris()
	{
		Scanner in = new Scanner(System.in);
		while(true)
		{
			int W = in.nextInt();
			if(W == 0)
				break;
			Map<String,Integer> walk = new HashMap<String,Integer>();
			for(int i = 0; i < W; i++)
				walk.put(in.next(),in.nextInt());
			int R = in.nextInt();
			ArrayList<Stop> stops = new ArrayList<Stop>();
			for(int i = 0; i < R; i++)
				stops.add(new Stop(in.next(),in.nextInt(),in.next(),in.nextInt()));
			String dest = in.next();
		
			boolean fail = false;
			Map<String, Integer> solutions= new HashMap<String,Integer>();
			for(String k : walk.keySet())
			{
				if(k.equals(dest))
					solutions.put(k,walk.get(k));
				Map<String, Integer> temps= new HashMap<String,Integer>();
				Map<String, Integer> done= new HashMap<String,Integer>();
				temps.put(k,walk.get(k));
				while(temps.size() > 0)
				{
					//System.out.println(temps.size());
					Map<String, Integer> copy = new HashMap<String,Integer>();
					for(String test : temps.keySet())
					{
						//System.out.println(test);
						int testi = temps.get(test);
						//temps.remove(test);
						for(Stop s : stops)
						{
							if(s.t >= testi && s.id.equals(test.substring(test.length() - 5)))
							{
								if(s.stop.equals(dest))
									done.put(test + " " + s.stop,s.t + s.delt);
								else
									copy.put(test + " " + s.stop,s.t + s.delt);
							}
						}
					}	
					temps.clear();
					temps.putAll(copy);
				}
				Map<String, Integer> arg = new HashMap<String,Integer>();
				int mint = -1;
				for(String s : done.keySet())
				{
					int st = done.get(s);
					if(st < mint || mint == -1)
						mint = st;
				}
				for(String s : done.keySet())
				{
					int st = done.get(s);
					if(st == mint)
						arg.put(s,st);
				}
				mint = -1;
				for(String s : arg.keySet())
				{
					if(s.length() < mint || mint == -1)
						mint = s.length();
				}
				for(String s : arg.keySet())
				{
					if(s.length() == mint)
						solutions.put(s,arg.get(s));
				}
			
			
			}
			if(solutions.size() > 0)
			{
				Map<String, Integer> arg = new HashMap<String,Integer>();
				int mint = -1;
				for(String s : solutions.keySet())
				{
					int st = solutions.get(s);
					if(st < mint || mint == -1)
						mint = st;
				}
				for(String s : solutions.keySet())
				{
					int st = solutions.get(s);
					if(st == mint)
						arg.put(s,st);
				}
				mint = -1;
				for(String s : arg.keySet())
				{
					if(s.length() < mint || mint == -1)
						mint = s.length();
				}
				for(String s : arg.keySet())
				{
					if(s.length() == mint)
						System.out.println("ETA: " + arg.get(s) + " minute(s) Take stop: " + s);
				}
			
			}
			else
				System.out.println("Unreachable");
		}	
		
	}
	private class Stop
	{
		public String id;
		public int t;
		public int delt;
		public String stop;
		public Stop(String id, int t,  String stop,int delt)
		{
			this.id = id;
			this.t = t;
			this.delt = delt;
			this.stop = stop;
		}
		
	}
}
