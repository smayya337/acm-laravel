/**Problem: Yahtzee
 * Solver: Daniel Epstein dae5y@virginia.edu
 * Problem Writers: Daniel Epstein dae5y@virginia.edu, modified from programming challenges book http://www.programming-challenges.com/pg.php?page=downloadproblem&probid=110208&format=html
 * Time Taken: 60 min? 120 min?
**/

import java.io.*;
import java.lang.*;
import java.util.*;

public class solution1{

    public static int[] value;
    public static boolean[] visited;
    public static int[] top;
    public static upto[] uptos;
    public static Roll[] diceRolls;
    public static void main(String [] args){
	Scanner in = new Scanner(System.in);
	int numCases = in.nextInt();
	for(int i=0;i<numCases;i++) {
		diceRolls = new Roll[13];
		for(int n=0;n<13;n++) {
			int[] rolls = new int[5];
			for(int m=0;m<5;m++)
				rolls[m] = in.nextInt();
		    diceRolls[n] = new Roll(rolls);
		}
		value = new int[8192];
		visited = new boolean[8192];
		top = new int[8192];
		uptos = new upto[8192];
		visited[0] = true;
		System.out.println("Case " + (i+1) + ": " + getScore(13, 8191));
	    }
    }
    public static int getScore(int category, int pos) {
	if(visited[pos])
	    return value[pos];
	value[pos] = 0;
	int newPos = pos;

	for(int i=12; i>=0; i--) {
	    //If we've considered this case, pos&bit will be 0
	    int haveIDoneThis = pos & (1<<i);
	    if(haveIDoneThis == 0)
		continue;
	    //I'm now considering that case, so set the bit to be 0
	    newPos = pos ^ (1<<i);
	    int prevScore = getScore(category-1, newPos);
	    int myAddition = diceRolls[12-i].points[category-1];
	    int sum = prevScore + myAddition;

	    visited[pos] = true;
	    if(sum>value[pos]) {
		value[pos] = sum;
		uptos[pos] = new upto(category-1, myAddition);
		top[pos] = newPos;
	    }
	}
	if(category==6 && value[pos] >= 63)
	    value[pos] += 35;
	return value[pos];
    }
}
class Roll {
    public int[] dice;
    public int[] points = new int[13];
    public int[] dc = new int[7];
    public int sum;
    public Roll(int[] s) {
	dice = s;
	Arrays.sort(dice);
	sum=0;
	for(int n=0;n<5;n++) {
	    dc[dice[n]]++;
	    sum+=dice[n];
	}
	calcPoints();
    }
    public void calcPoints() {
	points[0] = dc[1]*1;
	points[1] = dc[2]*2;
	points[2] = dc[3]*3;
	points[3] = dc[4]*4;
	points[4] = dc[5]*5;
	points[5] = dc[6]*6;
	points[6] = sum;
	points[7] = isXOfAKind(3) ? sum : 0;
	points[8] = isXOfAKind(4) ? sum : 0;
	points[9] = isXOfAKind(5) ? 50 : 0;
	points[10] = straightOfLength(4) ? 25 : 0;
	points[11] = straightOfLength(5) ? 35 : 0;
	points[12] = isFullHouse() ? 40 : 0;
    }
    private boolean isXOfAKind(int x) {
	for(int n=0;n<7;n++)
	    if(dc[n]>=x)
		return true;
	return false;
    }
    private boolean straightOfLength(int len) {
	if(len==4) {
	    return (dc[1]>0 && dc[2]>0 && dc[3]>0 && dc[4]>0) ||
		(dc[2]>0 && dc[3]>0 && dc[4]>0 && dc[5]>0) ||
		(dc[3]>0 && dc[4]>0 && dc[5]>0 && dc[6]>0);
	}
	if(len==5) {
	    return (dc[1]>0 && dc[2]>0 && dc[3]>0 && dc[4]>0 && dc[5]>0)||
		(dc[2]>0 && dc[3]>0 && dc[4]>0 && dc[5]>0 && dc[6]>0);
	}
	return false;
    }
    private boolean isFullHouse() {
	return (dice[0] == dice[1] && dice[2] == dice[4]) ||
	    (dice[0] == dice[2] && dice[3] == dice[4]);
    }
}
class upto {
    public int category;
    public int score;
    public upto(int _cat, int _score) {
	category = _cat;
	score = _score;
    }
}
