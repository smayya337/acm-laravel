# Solution to "Racer Car Ranking" (ants) for HSPC 2018 @ UVA
# By Roman Bohuk, 2018

import sys

n = int(sys.stdin.readline())

def stdin(): return sys.stdin.readline().strip("\n")

for i in range(n):
    print(stdin() + ":")
    p = int(stdin())
    scores = {stdin():0 for j in range(p)}
    races = int(stdin())
    for j in range(races):
        r = stdin().split(" ")
        value = int(r[1])
        scores[r[2]] += value
        scores[r[3]] += value // 2
        scores[r[4]] += value // 4
    for s in sorted(scores.keys()):
        print(s + " " + str(scores[s]))
