import java.util.Scanner;

public class Service{
    public static void main(String[] args){
	Scanner sc = new Scanner(System.in);
	int ctest = sc.nextInt();
	for(int itest = 1; itest <= ctest; itest++){
	    int m = sc.nextInt();
	    int n = sc.nextInt();
	    int p = sc.nextInt();
	    int[] mpord_bill = new int[m];
	    for(int im = 0; im < m; im++){
		mpord_bill[im] = sc.nextInt();
	    }
	    int bill = 0;
	    for(int in = 0; in < n; in++){
		int ord = sc.nextInt();
		bill += mpord_bill[ord-1];
	    }
	    int tip = bill * p;
	    tip += 99;
	    tip /= 100;
	    bill += tip;
	    int dollars = bill / 100;
	    int cents = bill % 100;
	    String centString = "";
	    if(cents < 10)
		centString = "0" + cents;
	    else
		centString = "" + cents;
	    System.out.println("Case " + itest + ": $" + dollars + "." + centString);
	}
    }
}
