/** Problem: Whos Afraid of the Big Bad Wolf
* Solver: Chris Cunningham clc3bn@virginia.edu
* Problem Writers: Dan Epstein dae5y@virginia.edu Jonathan DiLorenzo jd9hz@virginia.edu
* Time Taken: 20 min
* Overall Thoughts: Good Problem
* Things to fix: Need to specify decimals in output
**/

import java.util.*;
import java.text.*;
public class solution1
{
	public static void main(String[] args)
	{
		new solution1();
	}
	
	public solution1()
	{
	
		NumberFormat format = NumberFormat.getInstance();
		format.setGroupingUsed(false);
		format.setMaximumFractionDigits(5);
		format.setMinimumFractionDigits(5);
		Scanner in = new Scanner(System.in);
		int cases = in.nextInt();
		for(int c = 0; c < cases; c++)
		{
			int N = in.nextInt();
			int start = in.nextInt();
			int end = in.nextInt();
			int M = in.nextInt();
			Map<Integer,Map<Integer,Double>> map = new HashMap<Integer,Map<Integer,Double>>();
			for(int i = 1; i <= N; i++)
			{
				map.put(i,new HashMap<Integer,Double>());
			}
			
			Set<Integer> path = new HashSet<Integer>();
			path.add(start);
			
			for(int i = 0; i < M; i++)
			{
				int temp = in.nextInt();
				int key = in.nextInt();
				double val = in.nextDouble();
				if(map.get(temp).containsKey(key))
					val = Math.max(val, map.get(temp).get(key));
				map.get(temp).put(key, val);		
			}
						
			Map<Integer,Double> frontier = new HashMap<Integer,Double>();
			frontier = map.get(start);
			
			int max = -1;
			double maxd = -1;
			while(true)
			{
				//select best from frontier
				max = -1;
				maxd = -1;
				for(Integer i : frontier.keySet())
				{
					if(max == -1 || maxd < frontier.get(i))
					{
						maxd = frontier.get(i);
						max = i;
					}
				}
				path.add(max);
				frontier.remove(max);
				
				if(max == end)
					break;
				
				//add to frontier
				Map<Integer,Double> temp = map.get(max);
				for(Integer i : temp.keySet())
				{
					if(path.contains(i))
						continue;
					if(frontier.containsKey(i))
						frontier.put(i,Math.max(frontier.get(i),maxd*temp.get(i)));
					else
						frontier.put(i,maxd*temp.get(i));
				}
					
				
				
			}
			
			System.out.println("Case " + (c + 1) + ": " + format.format(maxd));

		}
	}
}
