/** Problem: Ant Entrapment
* Solver: Chris Cunningham clc3bn@virginia.edu
* Problem Writers: Dan Epstein dae5y@virginia.edu Jonathan DiLorenzo jd9hz@virginia.edu
* Time Taken: <10 min
* Overall Thoughts: 
* Things to fix: need to give better output specification (number of decimal places and how many spaces after the colon)
**/

import java.util.*;
import java.text.*;
public class solution1
{
	public static void main(String[] args)
	{
		new solution1();
	}
	
	public solution1()
	{
		Scanner in = new Scanner(System.in);
		int cases = in.nextInt();
		for(int c = 0; c < cases; c++)
		{
			int N = in.nextInt();
			List<Double> x = new ArrayList<Double>();
			List<Double> y = new ArrayList<Double>();
			for(int i = 0; i < N; i++)
			{
				x.add(in.nextDouble());
				y.add(in.nextDouble());
			}
			double w = Collections.max(x) - Collections.min(x);
			double h = Collections.max(y) - Collections.min(y);
			double a = w*h;
			double p = 2*w+2*h;
			NumberFormat format = NumberFormat.getInstance();
			format.setGroupingUsed(false);
			format.setMaximumFractionDigits(5);
			format.setMinimumFractionDigits(5);
			System.out.println("Case " + (c+1) + ": Area " + a 
						+ ", Perimeter " + p);
		}
	}
}


