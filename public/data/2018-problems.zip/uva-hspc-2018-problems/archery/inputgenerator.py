import random
def getDist(x,y,v,w):
    return (w * (-x/v) - 5 * (x/v)**2 + y)

def getPts(dist):
    dist = abs(dist)
    if dist <= 1:
        return 5
    elif dist <= 2:
        return 3
    elif dist <= 3:
        return 1
    else:
        return 0


for i in range(1000):
    # Choose x and velocity randomly
    x = random.randint(-1000,1001)
    v = random.randint(1,1001)
    w = random.randint(-1000,1001)

    # Point toward the target
    v *= -1 if x >= 0 else 1
    
    # Offset on y to move hit location to 0
    y = -int(round(getDist(x,0,v,w)))

    # Add an offset to hit another part of the target
    pos = random.choice([-4,-3,-2,-1,0,1,2,3,4])
    if abs(pos) == 4:
        pos = random.randint(-1000,1000)
    y += pos

    print(x,y)
    print(v,w)



    

    

