import java.util.ArrayList;
import java.util.Scanner;

public class EvenMoreDice {

	public static void main(String[] args) {
		// Get parameters
		Scanner keyboard = new Scanner(System.in);
		int caseNum = keyboard.nextInt();
		int[][] cases = new int[caseNum][3];
		for (int i = 0; i < caseNum; i++) {
			cases[i][0] = keyboard.nextInt(); // dice
			cases[i][1] = keyboard.nextInt(); // sides
			cases[i][2] = keyboard.nextInt(); // sum
		}
		keyboard.close();

		//iterate over cases
		for (int i = 0; i < caseNum; i++) {

			System.out.println("Case " + (i + 1) + ":");

			// Loop through all valid sum-fitting rolls for the case, outputting
			// one per line
			for (int[] roll : findRolls(cases[i][0], cases[i][1], cases[i][2])) {
				StringBuilder sb = new StringBuilder("(");
				for (int j = 0; j < roll.length - 1; j++) {
					sb.append(roll[j] + ",");
				}
				sb.append(roll[roll.length - 1] + ")");

				System.out.println(sb);
			}
		}
	}

	public static ArrayList<int[]> findRolls(int dice, int sides, int sum) {

		ArrayList<int[]> rolls = new ArrayList<int[]>();

		/*
		 * Error-checking: return empty ArrayList if: --there aren't any dice
		 * --the dice can't exist --the sum is too low (since each die must
		 * yield >=1) --the sum is too high (since each die must yield <= sides)
		 */
		if (dice < 1 || sides < 2 || sum < dice || sum > dice * sides) {
			return rolls;
		}

		// Base case: one die, with a reachable sum (assured by error-checking)
		else if (dice == 1) {
			int[] roll = { sum };
			rolls.add(roll);
		}

		// Recursive case
		else {

			// Iterate through all possible rolls of ONE die
			for (int i = 1; i <= sides; i++) {

				// Create a list of good partial rolls (all rolls beside current
				// die)
				// "good" means that the partial rolls sum with the current die
				// to yield the desired sum.
				ArrayList<int[]> partialRolls = findRolls(dice - 1, sides, sum
						- i);

				// Put each partial roll into our current roll
				for (int[] partialRoll : partialRolls) {
					int[] roll = new int[dice];
					roll[0] = i;
					for (int j = 1; j <= partialRoll.length; j++) {
						roll[j] = partialRoll[j - 1];
					}
					boolean add = true;

					// Only add this roll if it is properly sorted (ascending
					// order)
					for (int k = 1; k < roll.length; k++) {
						if (roll[k] < roll[k - 1])
							add = false;
					}
					if (add)
						rolls.add(roll);
				}
			}
		}
		return rolls;
	}

}
