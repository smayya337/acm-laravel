#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

/*
 * The thing to realize for this problem is that although brute force solutions
 * aren't generally desirable, there's a certain set of cases where it's not 
 * possible to do better, which means that the judges' solution can't be better.
 *
 * That provides an additional constraint on the complexity of the problem, which
 * means that brute force solutions are viable (since the judges' solutions also
 * need to run under that constraint).
 */
void debug(int W, int H, bool* horizborders, bool* vertborders, bool* cellsfilled) {
	for(int k=0;k<W;k++) {
		printf("+-");
	}
	printf("+\n");
	for(int j=0;j<H;j++) {
		printf("|");
		for(int k=0;k<W-1;k++) {
			if(cellsfilled[k+j*W]) {
				printf("X");
			} else {
				printf(" ");
			}
			if(vertborders[j*(W-1)+k]) {
				printf("|");
			} else {
				printf(".");
			}
		}
		if(cellsfilled[(W-1)+j*W]) {
			printf("X");
		} else {
			printf(" ");
		}
		printf("|\n");
		if(j<H-1) {
			for(int k=0;k<W;k++) {
				if(horizborders[j*W+k]) {
					printf("+-");
				} else {
					printf("+ ");
				}
			}
			printf("+\n");
		}
	}
	for(int k=0;k<W;k++) {
		printf("+-");
	}
	printf("+\n");
}
void mark(int W, int H, bool* horizborders, bool* vertborders, bool* cellsfilled, int thisw, int thish, bool value) {
	if(cellsfilled[thisw+thish*W] == value) {
		return;
	}
	cellsfilled[thisw+thish*W] = value;
	if(thish > 0 && !horizborders[thisw + (thish-1)*W]) {
		mark(W, H, horizborders, vertborders, cellsfilled, thisw, thish-1, value);
	}
	if(thish < (H-1)  && !horizborders[thisw + (thish)*W]) {
		mark(W, H, horizborders, vertborders, cellsfilled, thisw, thish+1, value);
	}
	if(thisw > 0 && !vertborders[(thisw-1) + thish*(W-1)]) {
		mark(W, H, horizborders, vertborders, cellsfilled, thisw-1, thish, value);
	}
	if(thisw < W-1 && !vertborders[thisw + thish*(W-1)]) {
		mark(W, H, horizborders, vertborders, cellsfilled, thisw+1, thish, value);
	}
}

int solve(int W, int H, bool* horizborders, bool* vertborders, bool* cellsfilled, int* filledatdepth, int passesleft) {
	if(passesleft == 0) {
		//debug(W, H, horizborders, vertborders, cellsfilled);
		int ret = 0;
		for(int i=0;i<W;i++) {
			for(int j=0;j<H;j++) {
				if(cellsfilled[i+j*W]) {
					ret++;
				}
			}
		}
		//printf("%i\n",ret);
		return ret;
	} else {
		int bestknown = 0;
		// guess cols
		for(int i=0;i<W;i++) {
			// check if marking this col would do anything
			bool wouldhelp = false;
			for(int j=0;j<H;j++) {
				if(!cellsfilled[i+j*W]) {
					wouldhelp = true;
					break;
				}
			}
			if(!wouldhelp) {
				continue;
			}
			// do the marking
			for(int j=0;j<H;j++) {
				if(!cellsfilled[i+j*W]) {
					// mark recursively
					mark(W, H, horizborders, vertborders, cellsfilled, i, j, true);
					filledatdepth[i+j*W] = passesleft;
				}
			}
			int value = solve(W, H, horizborders, vertborders, cellsfilled, filledatdepth, passesleft-1);
			if(value > bestknown) {
				bestknown = value;
			}
			// unmark as cleanup
			for(int j=0;j<H;j++) {
				if(filledatdepth[i+j*W] == passesleft) {
					// mark recursively
					mark(W, H, horizborders, vertborders, cellsfilled, i, j, false);
					filledatdepth[i+j*W] = 0;
				}
			}
		}
		// guess rows
		for(int j=0;j<H;j++) {
			// check if marking this col would do anything
			bool wouldhelp = false;
			for(int i=0;i<W;i++) {
				if(!cellsfilled[i+j*W]) {
					wouldhelp = true;
					break;
				}
			}
			if(!wouldhelp) {
				continue;
			}
			// do the marking
			for(int i=0;i<W;i++) {
				if(!cellsfilled[i+j*W]) {
					// mark recursively
					mark(W, H, horizborders, vertborders, cellsfilled, i, j, true);
					filledatdepth[i+j*W] = passesleft;
				}
			}
			int value = solve(W, H, horizborders, vertborders, cellsfilled, filledatdepth, passesleft-1);
			if(value > bestknown) {
				bestknown = value;
			}
			// unmark as cleanup
			for(int i=0;i<W;i++) {
				if(filledatdepth[i+j*W] == passesleft) {
					// mark recursively
					mark(W, H, horizborders, vertborders, cellsfilled, i, j, false);
					filledatdepth[i+j*W] = 0;
				}
			}
		}
		return bestknown;
	}
}

int main() {
	int ncases;
	int i;
	char dump[30];
	scanf(" %i ", &ncases);
	for(i=0;i<ncases;i++) {
		// each case starts with width, height, and number of syrup passes
		int W;
		int H;
		int npasses;
		scanf(" %i %i %i ", &W, &H, &npasses);
		// set up some data structures
		bool* horizborders = (bool*)malloc(W*(H-1)*sizeof(bool));
		bool* vertborders  = (bool*)malloc((W-1)*H*sizeof(bool));
		for(int j=0;j<W*(H-1);j++) {
			horizborders[j] = false;
		}
		for(int j=0;j<H*(W-1);j++) {
			vertborders[j] = false;
		}
		// parse in the waffle
		// top edge
		for(int k=0;k<W;k++) {
			scanf(" +- ");
		}
		scanf(" + ");
		// chewy center
		for(int j=0;j<H;j++) {
			// even rows
			// left edge
			scanf(" | ");
			for(int k=0;k<W-1;k++) {
				if(scanf(" %[|] ",dump) != 0) {
					vertborders[j*(W-1)+k] = true;
				} else {
					scanf(" . ");
				}
			}
			// right edge
			scanf(" | ");
			// only H-1 odd rows
			if(j < H-1) {
				// odd rows
				for(int k=0;k<W;k++) {
					scanf(" + ");
					if(scanf(" %[-] ",dump) != 0) {
						horizborders[j*W+k] = true;
					}
				}
				scanf(" + ");
			}
		}
		// bottom edge
		for(int k=0;k<W;k++) {
			scanf(" +- ");
		}
		scanf(" + ");
		bool* cellsfilled = (bool*)malloc(W*H*sizeof(bool));
		int filledatdepth[W*H];
		for(int j=0;j<W*H;j++) {
			cellsfilled[j] = false;
			filledatdepth[j] = 0;
		}
		// DEBUG: TODO: REMOVE
		//debug(W, H, horizborders, vertborders, cellsfilled);
		//mark(W, H, horizborders, vertborders, cellsfilled, 1, 1, true);
		//debug(W, H, horizborders, vertborders, cellsfilled);
		//mark(W, H, horizborders, vertborders, cellsfilled, 1, 1, false);
		//debug(W, H, horizborders, vertborders, cellsfilled);
		printf("Case %i: %i\n", i+1, solve(W,H,horizborders,vertborders,cellsfilled, filledatdepth, npasses));
	}
}
