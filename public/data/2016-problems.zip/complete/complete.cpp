#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <string>
#include <vector>
#include <stack>
using namespace std;

#define VLI_CHECK(n) if(ip > (256-n)) { fprintf(stderr, "VLI overrun on line %d\n",__LINE__);exit(1);}

int main() {
	int nprogs;
	cin >> nprogs;
	char dump[10];
	cin.getline(dump, 10);
	for(int prog=0;prog<nprogs;prog++) {
		char program_raw[512];
		char input_raw[512];
		cin.getline(program_raw, 512);
		cin.getline(input_raw, 512);
		uint8_t program[256];
		for(int i=0;i<256;i++) {
			program[i] = 0;
		}
		for(int i=0;i<256;i++) {
			program[i] = 0;
			char p1 = program_raw[i*2];
			char p2 = program_raw[i*2+1];
			if(p1 == '\0' || p2=='\0') {
				break;
			}
			if(p1 >='0' && p1 <='9') {
				program[i] += (p1-'0')*16;
			} else if(p2 >='A' && p2 <='F') {
				program[i] += (p1-'A'+10)*16;
			} else {
				program[i] += (p1-'a'+10)*16;
			}
			if(p2 >='0' && p2 <='9') {
				program[i] += (p2-'0');
			} else if(p2 >='A' && p2 <='F') {
				program[i] += (p2-'A'+10);
			} else {
				program[i] += (p2-'a'+10);
			}
		}
		/*for(int i=0;i<256;i++) {
			printf("%x ",program[i]);
		}
		printf("\n");*/
		//interpreter loop
		uint8_t registers[16];
		uint8_t &ip = registers[0];
		int input_pointer = 0;
		for(int i=0;i<16;i++) {
			registers[i] = 0;
		}
		stack<uint8_t> stack;
		while(ip < 254) {
			//printf("%x: %x\n",ip, program[ip]);
			switch(program[ip]) {
				case 0: // mov dest src
					{
						VLI_CHECK(2);
						uint8_t byte2 = program[ip+1];
						registers[byte2/16] = registers[byte2%16];
						ip += 2;
					}
					break;
				case 1: // mov dest imm
					{
						VLI_CHECK(3);
						uint8_t byte2 = program[ip+1];
						uint8_t byte3 = program[ip+2];
						registers[byte2%16] = byte3;
						ip += 3;
					}
					break;
				case 2: // mov [dest] src
					{
						VLI_CHECK(2);
						uint8_t byte2 = program[ip+1];
						program[registers[byte2/16]] = registers[byte2%16];
						ip += 2;
					}
					break;
				case 3: // mov dest [src]
					{
						VLI_CHECK(2);
						uint8_t byte2 = program[ip+1];
						registers[byte2/16] = program[registers[byte2%16]];
						ip += 2;
					}
					break;
				case 4: // add dest src
					{
						VLI_CHECK(2);
						uint8_t byte2 = program[ip+1];
						registers[byte2/16] += registers[byte2%16];
						ip+=2;
					}
					break;
				case 5: // sub dest src
					{
						VLI_CHECK(2);
						uint8_t byte2 = program[ip+1];
						registers[byte2/16] -= registers[byte2%16];
						ip+=2;
					}
					break;
				case 6: // and dest src
					{
						VLI_CHECK(2);
						uint8_t byte2 = program[ip+1];
						registers[byte2/16] &= registers[byte2%16];
						ip+=2;
					}
					break;
				case 7: // or dest src
					{
						VLI_CHECK(2);
						uint8_t byte2 = program[ip+1];
						registers[byte2/16] |= registers[byte2%16];
						ip+=2;
					}
					break;
				case 8: // call imm
					{
						VLI_CHECK(2);
						uint8_t byte2 = program[ip+1];
						stack.push(ip+2);
						ip = byte2;
					}
					break;
				case 9: // ret
					{
						if(stack.size() == 0) {
							fprintf(stderr, "Segmentation fault! ret on empty stack!\n");
							exit(1);
						}
						ip=stack.top();
						stack.pop();
					}
					break;
				case 0xA: // je reg1 reg2 imm
					{
						VLI_CHECK(3);
						uint8_t byte2 = program[ip+1];
						uint8_t byte3 = program[ip+2];
						if(registers[byte2%16] == registers[byte2/16]) {
							ip = byte3;
						} else {
							ip += 3;
						}
					}
					break;
				case 0xB: // jg reg1 reg2 imm
					{
						VLI_CHECK(3);
						uint8_t byte2 = program[ip+1];
						uint8_t byte3 = program[ip+2];
						if(registers[byte2/16] > registers[byte2%16]) {
							ip = byte3;
						} else {
							ip += 3;
						}
					}
					break;
				case 0xC: // j imm
					{
						VLI_CHECK(2);
						uint8_t byte2 = program[ip+1];
						ip = byte2;
					}
					break;
				case 0xD: // read reg
					{
						VLI_CHECK(2);
						uint8_t byte2 = program[ip+1];
						registers[byte2%16] = input_raw[input_pointer];
						if(input_raw[input_pointer] != '\0') {
							input_pointer++;
						}
						ip+=2;
					}
					break;
				case 0xE: // write reg
					{
						VLI_CHECK(2);
						uint8_t byte2 = program[ip+1];
						printf("%c", registers[byte2%16]);
						ip+=2;
					}
					break;
				case 0xF: // terminate
					{
						ip = 255;
					}
					break;
				default:
					fprintf(stderr, "Unknown instruction!\n");
					exit(1);
			}
		}
		printf("\n");
	}
	return 0;
}
