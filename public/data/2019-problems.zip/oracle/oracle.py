import sys

if __name__ == '__main__':
    test_cases = int(sys.stdin.readline())

    for _ in range(test_cases):
        pred = sys.stdin.readline().strip().split()
        actu = sys.stdin.readline().strip().split()

        correct = len(list(filter(lambda t: t[0] == t[1], zip(pred, actu))))

        if correct < 5:
            print("Fraud")
        elif correct < 8:
            print("Draw")
        else:
            print("Oracle")


