// Bloomfield's gradabase solution, 3-11-13
#include <iostream>
using namespace std;
int main() {
  int n, m, x;
  //iterate over cases
  cin >> n;
  for ( int i = 1; i <= n; i++ ) {
    cout << "Case " << i << ":" << endl;

    //iterate over students
    cin >> m;
    for ( int j = 0; j < m; j++ ) {
      cin >> x;
      if ( x != 6 )//if not graduating
	cout << ++x << endl;//print the pre-incremented value
    }
  }
}
