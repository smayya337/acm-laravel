#include <iostream>
#include <sstream>
#include <vector>
using namespace std;

bool visited(int orientation, int y, int x, vector<string> &list){ // returns true if the robot's visited a spot before
	bool ret = false;
	std:ostringstream s;
	s << orientation;
	s.str() += " ";
	s << y;
	s.str() += " ";
	s << x;

	//compare to seen states
	for (int i = 0; i < list.size(); i++){
		if (s.str() == list.at(i)) { ret = true; break; }
	}
	return ret;
}

int main() {	
	char PLUG = 'p';
	char OB = 'x';
	char MESS = 'm';
	char ROB = 'r';
	char EMPTY = '-';

	vector<string> results;

	int c;
	cin >> c;
	
	//iterate over cases
	for (int i = 0; i < c; i++){
		int n, m;
		cin >> n;
		cin >> m;

		//read in grid
		char** grid = new char*[n];
		for (int j = 0; j < n; j++){
			grid[j] = new char[n];
		}
		int robotx, roboty; // robot starting coordinates
		int mx, my; // mess coordinates
		string line;
		for (int j = 0; j < n; j++){ // read in each line
			cin >> line;
			for (int k = 0; k < n; k++){ // add each letter to the array
				if (line[k] == ROB) { robotx = k; roboty = j; }
				if (line[k] == MESS) { mx = k; my = j; }
				grid[j][k] = line[k];
			}
		}
		vector<string> charges; 
		int charge = m; // starts at full charge
		int orientation = 0; // starts facing east. 0 = east, 1 = south, 2 = west, 3 = north
		int minutes = 0;
		bool successful = false;
		while (charge >= 0) {
			// check to see if we're at the mess
			if (robotx == mx && roboty == my) { successful = true; break; }

			// check if we're at half charge or less, if we are check adjacent nondiagonal cells
			if (charge*2 <= m) {
				char c0 = grid[roboty][robotx+1];
				char c1 = grid[roboty+1][robotx];
				char c2 = grid[roboty][robotx-1];
				char c3 = grid[roboty-1][robotx];
				if (c0 == PLUG || c1 == PLUG || c2 == PLUG || c3 == PLUG) {
					// check to see if we've visited this spot before
					if (visited(orientation, roboty, robotx, charges)) { charge = 0; break; }
					// charge
					int diff = m - charge;
					charge += diff;
					minutes += diff;
					// keep track of location and orientation
					std::ostringstream oss;
					oss << orientation;
					oss.str() += " ";
					oss << roboty;
					oss.str() += " ";
					oss << robotx;
					charges.push_back(oss.str());
					continue;
				}
			}


			// check what's in front of the robot
			char infront;
			switch (orientation) { // (0,0) is the top left, (n-1,n-1) is the bot right
				case 0:
					infront = grid[roboty][robotx+1];
					break;
				case 1:
					infront = grid[roboty+1][robotx];
					break;
				case 2:
					infront = grid[roboty][robotx-1];
					break;
				case 3:
					infront = grid[roboty-1][robotx];
					break;
			}
			// if it's an obstacle or a plug, rotate
			if (infront == OB || infront == PLUG) { 
				charge--; 
				minutes++; 
				orientation = (orientation + 1) % 4; 
				continue;
			}
			// otherwise move forward
			charge--;
			minutes++;
			switch (orientation) {
				case 0: // east
					robotx++;
					break;
				case 1: // south
					roboty++;
					break;
				case 2: // west
					robotx--;
					break;
				case 3: // north
					roboty--;
					break;
			}
			continue;
		}
		for (int j = 0; j < n; j++){
			delete grid[j];
		}
		delete grid;		
		std::ostringstream oss;

		//buffer output
		if (successful) {
			string line = "Case ";
			oss << (i+1);
			line += oss.str();
			oss.str("");
			line += ": ";
			oss << minutes;
			line += oss.str();
			results.push_back(line);
		} else {
			string line = "Case ";
			oss << (i+1);
			line += oss.str();
			line += ": NEVER";
			results.push_back(line);
		}
	}

	//print output
	for (int i = 0; i < results.size(); i++){
		cout << results.at(i);
		if (i != results.size() - 1) cout << endl;
	}
	return 0;
}

