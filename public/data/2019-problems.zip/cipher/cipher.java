import java.util.*;

public class cipher{
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        for(int i = 0; i < n; i++){
            int v = input.nextInt();
            input.nextLine();
            String line = input.nextLine();
            for(int j = 0; j < line.length(); j++){
                if(line.charAt(j) == ' '){
                    System.out.print(" ");
                }else{
                    System.out.print((char)((line.charAt(j) - 97 + v) % 26 + 97));
                }
            }
            System.out.println();
        }
    }
}