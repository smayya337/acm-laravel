// Solves "Mario Polo" from the 2017 HSPC at UVa
// Solution by Aaron Bloomfield, 2017

#include <iostream>
#include <string>
using namespace std;
int main() {
  unsigned int n;
  string s;
  cin >> n;
  for ( int i = 0; i < n; i++ ) {
    cin >> s;
    if ( s == "Mario" )
      cout << "Polo" << endl;
    if ( s == "Silence" )
      cout << "Silence" << endl;
  }
  return 0;
}
