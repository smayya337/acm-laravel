import java.io.*;
import java.util.*;

public class Delivery {
    public static void main(String[] args) {
        Scanner cin = new Scanner(System.in);
        int t = cin.nextInt();

        for(int itr = 0; itr < t; itr++) {
            int nints = cin.nextInt(), nroads = cin.nextInt(), ntests = cin.nextInt();

            Set<Integer> accessible = new HashSet<Integer>();
            ArrayList<List<Integer>> adjacent = new ArrayList<List<Integer>>(nints);

            for(int i = 0; i < nints; i++) {
                adjacent.add(new ArrayList<Integer>());
            }

            // Read in all of the roads indicating navigability.
            for(int i = 0; i < nroads; i++) {
                int source = cin.nextInt(), dest = cin.nextInt();
                adjacent.get(source).add(dest);
            }

            // Do a BFS, but really any such thing would suffice.
            Queue<Integer> toProcess = new ArrayDeque<Integer>();
            toProcess.add(0);
            while(!toProcess.isEmpty()) {
                int reached = toProcess.remove();

                if(!accessible.contains(reached)) {
                    accessible.add(reached);

                    for(int child : adjacent.get(reached)) {
                        toProcess.add(child);
                    }
                }
            }

            int found = -1;
            for(int i = 0; i < ntests; i++) {
                int totest = cin.nextInt();

                if(found == -1 || totest < found) {
                    if(!accessible.contains(totest)) {
                        found = totest;
                    }
                }
            }

            if(found == -1) {
                System.out.printf("Case %d: All are accessible\n", itr+1);
            } else {
                System.out.printf("Case %d: %d\n", itr+1, found);
            }
        }
    }
}
