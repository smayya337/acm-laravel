import java.io.*;
import java.util.*;

public class solution3 {
	public static HashMap<Integer, Node> nodes = new HashMap<Integer, Node>();
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int numCases = in.nextInt();
		for(int aaa=1;aaa<=numCases;aaa++) {
			int N = in.nextInt();
			for(int i=1;i<=N;i++)
				nodes.put(i, new Node(i));
			Node start = nodes.get(in.nextInt());
			Node end = nodes.get(in.nextInt());
			int M = in.nextInt();
			for(int i=0;i<M;i++) {
				Node a = nodes.get(in.nextInt());
				Node b = nodes.get(in.nextInt());
				double prob = in.nextDouble();
				if(a.adj.containsKey(b))
					prob = Math.max(prob, a.adj.get(b));
				a.adj.put(b, prob);
			}
			
			PriorityQueue<Node> q = new PriorityQueue<Node>();
			start.visited = true;
			start.dist = 1;
			q.add(start);
			while(q.size()>0) {
				Node n = q.remove();
				if(n == end)
					break;
				n.visited = true;
				for(Node a : n.adj.keySet()) {
					if(!a.visited) {
						q.remove(a);
						a.dist = Math.max(a.dist, n.dist * n.adj.get(a));
						q.add(a);
					}
				}
			}
			System.out.println("Case " + aaa + ": " + end.dist);
		}
	}
}

class Node implements Comparable<Node> {
	HashMap<Node, Double> adj = new HashMap<Node, Double>();
	int num;
	double dist = 0;
	boolean visited = false;
	
	public Node(int i) {
		num = i;
	}
	
	public int compareTo(Node n) {
		return -Double.compare(dist, n.dist);
	}
}
