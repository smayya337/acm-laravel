# Solves "Samsu Charge" from the 2017 HSPC at UVa
# Solution by Andrew Norton, 2017

import sys
from sys import stdin

sys.setrecursionlimit(1500) # python has a fairly shallow default
                            # recursion depth limit. Increase
                            # needed.

##
# t    : current time
# c    : current charge
# C    : charge array
# Z    : monster array
# memo : dictionary for memoization/DP
##
def num_killed(t, c, C, Z, memo):
  # base case: no more time, so can kill 0 monsters
  if t == len(C):
    return 0
  
  # Memoization for speedup
  if (t, c) in memo:
    return memo[(t, c)]

  waitBest  = num_killed(t+1, c + C[t], C, Z, memo)
  shootBest = num_killed(t+1, 0, C, Z, memo) + min(c+C[t], Z[t])

  # If we don't shoot, the best we can do is to recurse with more charge
  # If we shoot, we kill min(currCharge + C[t], Z[t]) monsters and recurse
  # We do the best of these two options

  best = max(waitBest, shootBest)
  memo[(t, c)] = best

  return best
  

if __name__ == '__main__':
  data = stdin.read().splitlines()[1:]
  i = 0

  while i < len(data):
    Z = [int(s) for s in data[i+1].split() ] # get space monsters
    C = [int(s) for s in data[i+2].split() ] # get charge amounts
    print(num_killed(0, 0, C, Z, {}))

    i += 3 # skip ahead to next block
