// Solves "Pokeballs" from the 2017 HSPC at UVa
// Solution by Salah Assana, 2017

/*

When there is only 1 Pokeball in the sack Player 1 will lose because the are not enough Pokeballs from the start
and they are unable to complete their first turn.

When there are 2 Pokeballs in the sack Player 1 wil win because they will take 2 Pokeballs leaving Player 2 with
no Pokeballs to take on their turn.

When there are 3 Pokeballs in the sack Player 1 will win because they will take 2 Pokeballs leaving Player 1 with
1 Pokeball.
*/

import java.util.*;

public class pokeballs
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);

        int t = sc.nextInt();

            while(t-- > 0)
            {
                int n = sc.nextInt();

                if(n % 7 == 0 || n % 7 == 1)
                {
                    System.out.println("Second");
                }
                
                else
                {
                    System.out.println("First");
                }
            }
    }
}
