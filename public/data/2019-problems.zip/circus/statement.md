# Circus Sorting

All hail the greatest sport ever to exist: Roman chariot racing! Last week, the biggest race of the year was run for the Roman Games at the Circus Maximus. But somehow in all the commotion, the ranking sheet was lost! The officials still have the list of each chariot's time, however. Can you give them back the list of the rankings?
