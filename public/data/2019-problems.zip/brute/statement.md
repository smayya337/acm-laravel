# Et Tu Brute?

Caesar has been betrayed! He always thought his best friends were the senators of Rome, but it turns out they are trying to kill him. Even his best friend, Marcus Junius Brutus, is in on the plot. Luckily, he's managed to get away, for now. If he can make it out of the senate he'll be okay, and he can overthrow the senate and take over Rome.

Unfortunately, he's a little rattled, and is not making smart decisions. Every minute, he is randomly choosing which room he enters and hides in for the next minute. In each room there is a $p\%$ chance that he will be captured. After $m$ minutes the senators will give up the search and go back to their homes, allowing him to escape. Calculate the chance that he will escape if he chooses rooms at random. 
