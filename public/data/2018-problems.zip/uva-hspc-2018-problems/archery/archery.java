import java.util.*;

public class archery {
  public static void main(String[] args) {
    Scanner cin = new Scanner(System.in);

    int numCases = cin.nextInt();

    for (int currCase = 0; currCase < numCases; currCase++) {
      double x0 = (double)cin.nextInt();
      double y0 = (double)cin.nextInt();
      double vX = (double)cin.nextInt();
      double vY = (double)cin.nextInt();

      double t = tAtZero(x0, vX);
      double y = yAtT(t, y0, vY);

      System.out.println(score(y));
    }

  }

  // Scores a shot based on the y-coordinate of the y-intercept
  private static int score(double y) {
    if (Math.abs(y) < 1)
      return 5;
    else if (Math.abs(y) < 2)
      return 3;
    else if (Math.abs(y) < 3)
      return 1;
    else
      return 0;
  }

  // Get the y value at a particular time
  private static double yAtT(double t, double y0, double vY) {
    return -5*t*t + vY*t + y0;
  }

  // Figure out when we reach x=0 (the y-axis)
  private static double tAtZero(double x0, double vX) {
    return -x0/vX;
  }
}
