import sys

ncases = int(sys.stdin.readline())
for i in range(ncases):
    x,y = map(int, sys.stdin.readline().split(" "))
    v,w = map(int, sys.stdin.readline().split(" "))

    dist = abs(w * (-x/v) - 5 * (x/v)**2 + y)
    if dist < 1:
        print(5)
    elif dist < 2:
        print(3)
    elif dist < 3:
        print(1)
    else:
        print(0)
