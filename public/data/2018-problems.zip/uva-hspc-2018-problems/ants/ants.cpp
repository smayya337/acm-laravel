/*
 * C++ solution to ants
 *
 * by Aaron Bloomfield, 2018
 */

#include <iostream>
using namespace std;

long f(long n) {
  if ( n == 0 )
    return 0;
  if ( n == 1 )
    return 1;
  else
    return 5 * n * f(n/2) + n;
}

int main() {
  long x, n;
  cin >> x;
  for ( int i = 0; i < x; i++ ) {
    cin >> n;
    cout << f(n) << endl;
  }
  return 0;
}
