/**
*Where's the rainbow
*Chris Cunningham (clc3bn)
*/

import java.util.*;
import java.text.*;
public class solution2
{
	public static void main(String[] args)
	{
		new solution2();
	}
	
	public solution2()
	{
		Scanner in = new Scanner(System.in);
		int numCases = in.nextInt();
		int tcase = 1;
		while(tcase <= numCases)
		{
			double h = in.nextDouble();
			double theta = in.nextDouble();
			double x = h/Math.tan(theta*Math.PI/180) - h;
			x=Math.abs(x);
			
			System.out.println("Case " + tcase + ": " + x);
			tcase++;
		}
		
		
	}
}
