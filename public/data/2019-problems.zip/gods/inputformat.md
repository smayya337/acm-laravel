The first line of the input will be a single integer, $n \leq 1,000$. There will be $n$ test cases that follow.


The first line of each test case will contain two integers, the number of gods $0 < g \leq 1,000$ and the number of queries $q < 1,000$. $g$ lines will then follow, each with the name of a god and the role of that god, for example, "Vulcan Blacksmithing". Each godly name and role will consist only of letters and no spaces, but the name and the role will be separated by a space.  No god will be listed twice.  $q$ queries will follow, one on each line, with the name of a god, such as "Vulcan".
