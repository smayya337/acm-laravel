/*
 * C++ solution to goingup
 *
 * by Aaron Bloomfield, 2018
 */

#include <iostream>
using namespace std;

int main() {
  int n, a, b;
  cin >> n;
  for ( int i = 0; i < n; i++ ) {
    cin >> a >> b;
    cout << (a/b + (a%b==0?0:1)) << endl;
  }
  return 0;
}
