The first line of the input will be a single integer, $n \leq 1,000$. There will be $n$ test cases that follow.


Each test case will start with a line of 2 integers: the number of rooms $5 \leq r \leq 50$ and the number of minutes Caesar must survive, $m \leq 10$. The next $r$ lines will consist of a floating point number $p < 1$ denoting the probability that Caesar survives for the next minute in this room and 4 integers between 1 and r (inclusive on both ends) denoting which rooms the current room is connected to. Caesar always spends the first minute in room 1. 

Note: The senate is weird, just because room a leads to room b does not mean Caesar can get back into room a from room b.
