#include <iostream>
#include <string>
#include <unordered_map>

int main(int argc, char** argv){
    int cases;
    std::cin >> cases;
    for(int caseno = 0; caseno < cases; caseno++) {
        int gods, queries;
        std::cin >> gods >> queries;
        std::unordered_map<std::string, std::string> godOf = {};
        for (int i = 0; i < gods; i++) {
            std::string s1, s2;
            std::cin >> s1 >> s2;
            godOf.emplace(s1, s2);
        }
        for (int i = 0; i < queries; i++) {
            std::string query;
            std::cin >> query;
            std::cout << godOf.at(query) << std::endl;
        }
    }
}
