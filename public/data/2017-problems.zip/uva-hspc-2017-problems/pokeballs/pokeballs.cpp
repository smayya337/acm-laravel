// Solves "Pokeballs" from the 2017 HSPC at UVa
// Solution by Aaron Bloomfield, 2017

#include <iostream>
using namespace std;
int main() {
  unsigned int x, y;
  cin >> y;
  for ( unsigned int i = 0; i < y; i++ ) {
    cin >> x;
    if ( x % 7 == 0 || x % 7 == 1 )
      cout << "Second" << endl;
    else
      cout << "First" << endl;
  }
}
