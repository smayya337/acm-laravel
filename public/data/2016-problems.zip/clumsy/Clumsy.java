import java.util.*;
import java.io.*;

public class Clumsy {

    public static class Crepe {
        public long x;
        public long y;
        public long r;
        public boolean seen;
        public List<Integer> adjacent;

        public Crepe(long x, long y, long r) {
            this.x = x;
            this.y = y;
            this.r = r;
            this.seen = false;
            this.adjacent = new ArrayList<Integer>();
        }

        public boolean intersects(Crepe other) {
            // Euclidean distance checking without doing square root.
            return (this.x - other.x)*(this.x - other.x) + (this.y - other.y)*(this.y - other.y) <= (this.r + other.r)*(this.r + other.r);
        }

        public void fill(ArrayList<Crepe> crepes) {
            this.seen = true;
            for(int i : adjacent) {
                if(!crepes.get(i).seen) {
                    crepes.get(i).fill(crepes);
                }
            }
        }
    }

    public static void main(String[] args) {
        Scanner cin = new Scanner(System.in);
        int n = cin.nextInt();

        for(int i = 0; i < n; i++) {
            int m = cin.nextInt();
            ArrayList<Crepe> crepes = new ArrayList<Crepe>();

            for(int j = 0; j < m; j++) {
                crepes.add(new Crepe(cin.nextInt(), cin.nextInt(), cin.nextInt()));
            }
            
            // Determine intersections.
            for(int j = 0; j < m; j++) {
                for(int k = j+1; k < m; k++) {
                    if(crepes.get(j).intersects(crepes.get(k))) {
                        crepes.get(j).adjacent.add(k);
                        crepes.get(k).adjacent.add(j);
                    }
                }
            }

            // Run floodfill on every crepe.
            int groups = 0;
            for(int j = 0; j < m; j++) {
                if(!crepes.get(j).seen) {
                    groups++;
                    crepes.get(j).fill(crepes);
                }
            }

            System.out.printf("Case %d: %d\n", i+1, groups);
        }
    }
}
