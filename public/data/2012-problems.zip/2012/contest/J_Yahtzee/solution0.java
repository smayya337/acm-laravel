import java.io.*;
import java.util.*;

public class solution2 {
	static int[] dpArr;
	static Roll[] rolls;
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int numCases = in.nextInt();
		for(int aaa=1;aaa<=numCases;aaa++) {
			rolls = new Roll[13];
			for(int a=0;a<13;a++) {
				int[] dice = new int[5];
				for(int i=0;i<5;i++)
					dice[i] = in.nextInt();
				rolls[a] = new Roll(dice);
			}
			dpArr = new int[1<<13];
			for(int i=0;i<dpArr.length;i++)
				dpArr[i] = -1;
			dpArr[0] = 0;
			int max = dp((1<<13) - 1, 0);
			System.out.println("Case " + aaa + ": " + max);
		}
	}
	
	public static int dp(int index, int numRolls) {
		if(dpArr[index] != -1)
			return dpArr[index];
		int topScore = 0;
		//actual logic!
		for(int i=0;i<13;i++) {
			int shift = 1<<i;
			//if you haven't yet used the ith dice roll
			if((shift & index) > 0) {
				topScore = Math.max(topScore, dp(index-shift, numRolls+1) + rolls[i].scores[12-numRolls]);
			}
		}
		
		if(numRolls == 7 && topScore >= 63) //bonus time!
			topScore += 35;
		dpArr[index] = topScore;
		return topScore;
	}
}

class Roll {
	int[] dice;
	int[] count;
	int[] scores = new int[13];
	int sum = -1;
	public Roll(int[] d) {
		dice = d;
		count = new int[6];
		for(int i=0;i<6;i++)
			count[i] = count(i+1);
		sum = sum();
		Arrays.sort(dice);
		score();
	}
	
	private void score() {
		//ones-sixes
		for(int i=0;i<6;i++)
		scores[i] = (i+1)*count[i];
		//chance
		scores[6] = sum;
		//three of a kind
		if((dice[0] == dice[1] && dice[1] == dice[2]) ||
		(dice[1] == dice[2] && dice[2] == dice[3]) ||
		(dice[2] == dice[3] && dice[3] == dice[4]))
			scores[7] = sum;
		//four of a kind
		if((dice[0] == dice[1] && dice[1] == dice[2] && dice[2] == dice[3]) ||
		(dice[1] == dice[2] && dice[2] == dice[3] && dice[3] == dice[4]))
			scores[8] = sum;
		//small straight
		if((count[0] >= 1 && count[1] >= 1 && count[2] >= 1 && count[3] >= 1) ||
		(count[1] >= 1 && count[2] >= 1 && count[3] >= 1 && count[4] >= 1) ||
		(count[2] >= 1 && count[3] >= 1 && count[4] >= 1 && count[5] >= 1))
			scores[9] = 25;
		//large straight
		if((count[0] >= 1 && count[1] >= 1 && count[2] >= 1 && count[3] >= 1 && count[4] >= 1) ||
		(count[1] >= 1 && count[2] >= 1 && count[3] >= 1 && count[4] >= 1 && count[5] >= 1))
			scores[10] = 35;
		//full house
		if((dice[0] == dice[1] && dice[1] == dice[2] && dice[3] == dice[4]) ||
		(dice[0] == dice[1] && dice[2] == dice[3] && dice[3] == dice[4]))
			scores[11] = 40;
		//yahtzee
		if(dice[0] == dice[1] && dice[1] == dice[2] && dice[2] == dice[3] && dice[3] == dice[4])
			scores[12] = 50;
	}
	
	private int count(int num) {
		int c = 0;
		for(int d : dice)
			c += d==num?1:0;
		return c;
	}
	
	private int sum() {
		int c = 0;
		for(int d : dice)
			c+=d;
		return c;
	}
}
