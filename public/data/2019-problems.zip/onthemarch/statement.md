# Marching Legion

There's a rebellion in Antioch! Caesar is preparing to dispatch an entire legion of his best troops to quell the rebellion, but before he does, he wants to make certain the legion will make it to Antioch. Along the way, there are mountains, rivers, seas, and mythical monsters, each of which the legion cannot pass through. Given a map a legion must travel through, find out if the legion can reach Antioch from Rome.
