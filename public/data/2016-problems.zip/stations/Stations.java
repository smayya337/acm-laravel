import java.util.*;

public class Stations {
  public static void main(String[] args) {
    Scanner cin = new Scanner(System.in);

    int T = cin.nextInt();
    // Read and solve test cases
    for (int testCase = 0; testCase < T; testCase++) {
      Set<String> foodSet = new HashSet<String>();
      int f = cin.nextInt(); // Number of stations

      for (int i = 0; i < f; i++)
        foodSet.add(cin.next());

      int s = cin.nextInt();
      FlowGraph G = new FlowGraph();
      Set<String> personSet = new HashSet<String>();
      
      // Create the graph
      for (int i = 0; i < s; i++) {
        String person = cin.next();

        // Get all food requests from each person
        int outEdges  = cin.nextInt();
        for (int j = 0; j < outEdges; j++) {
          String food = cin.next();
          G.addEdge(person, food, 1); // food request
        }

        // Every student must register for exactly 1 courses
        G.addEdge("_SOURCE", person, 1);

        personSet.add(person);
      }

      // Connect every food to the sink node
      for (String food : foodSet) {
        G.addEdge(food, "_SINK", 1);
      }
      
      boolean satisfied = personSet.size() == G.maxFlow();

      System.out.printf("Case %d: %s\n", testCase+1, satisfied ? "POSSIBLE" : "NOT_POSSIBLE");
    }
  }
}

class FlowGraph {
  Map<String, Set<String>> adjMap; // Usual adjacency map (undirected)
  Map<Edge, Integer> capacityMap;  // Capacities of each edge (directed)
  Map<Edge, Integer> flowMap;      // Current flow through each edge (directed double edges)

  public FlowGraph() {
    adjMap      = new HashMap<String, Set<String>>();
    capacityMap = new HashMap<Edge, Integer>();
    flowMap     = new HashMap<Edge, Integer>();
  }

  // Adds an edge between src and dst with a given capacity
  public void addEdge(String u, String v, int capacity) {
    Edge e = new Edge(u, v);
    capacityMap.put(e, capacity);
    flowMap.put(e, 0);
    flowMap.put(e.rev(), 0);

    // Update the simple adjacency matrix
    if (!adjMap.containsKey(e.u))
      adjMap.put(e.u, new HashSet<String>());
    adjMap.get(e.u).add(e.v);
    if (!adjMap.containsKey(e.v))
      adjMap.put(e.v, new HashSet<String>());
    adjMap.get(e.v).add(e.u);
  }

  public int maxFlow() {
    Stack<Edge> p = getPath("_SOURCE");
    while (p != null) {
      int cf = minResidualFlow(p);
      for (Edge e : p) {
        flowMap.put(e, flowMap.get(e) + cf);
        flowMap.put(e.rev(), flowMap.get(e.rev()) - cf);
      }

      p = getPath("_SOURCE");
    }

    for (String u : adjMap.keySet()) {
      for (String v : adjMap.get(u)) {
        Edge e = new Edge(u, v);
        if (!flowMap.containsKey(e) || !capacityMap.containsKey(e))
          continue;
      }
    }
    // We should have converged now
    // ... so, get the max flow from the source!
    int maxFlow = 0; 
    for (String u : adj("_SOURCE"))
      maxFlow += flowMap.get(new Edge("_SOURCE", u));

    return maxFlow;
  }

  // Computes the minimum residual flow along a path p
  // (p is just a list of strings from S node to T node
  public int minResidualFlow(Stack<Edge> p) {
    int retVal = Integer.MAX_VALUE;

    for (Edge e : p) 
      retVal = Math.min(retVal, residualFlow(e));

    return retVal;
  }

  public Iterable<String> adj(String u) {
    if (!adjMap.containsKey(u))
      return new ArrayList<String>(); // Empty iterable

    return adjMap.get(u);
  }

  // Computes the residual flow along one edge (this is c_f in wikipedia)
  private int residualFlow(Edge e) {
    int cap = capacityMap.containsKey(e) ? capacityMap.get(e) : 0;
    return cap - flowMap.get(e);
  }
  

  // Gets path starting from u to sink
  // this is a "helper" to call the recursive one
  private Set<String> visited = new HashSet<String>();
  private Stack<Edge> getPath(String u) {
    visited.clear();
    return getPathRec(u);
  }
  // The core path function
  private Stack<Edge> getPathRec(String u) {
    if (visited.contains(u))
      return null;
    
    visited.add(u);

    //No edges need to be taken from here
    if (u.equals("_SINK"))
      return new Stack<Edge>();

    Stack<Edge> retVal = null;
    for (String v : adj(u)) {
      Edge e = new Edge(u, v);
      // DFS through paths where capacity is still good
      int cf = residualFlow(e);
      if (cf > 0)
        retVal = getPathRec(v);

      // If we found a path that goes all the way through, use it!
      if (retVal != null) {
        retVal.push(e);
        return retVal;
      }
    }

    return null;
  }

  static class Edge {
    public String u, v;
    public Edge(String u, String v) {
      this.u = u;
      this.v = v;
    }

    public Edge rev() {
      return new Edge(v, u);
    }

    @Override
    public String toString() {
      return String.format("(%s, %s)", u, v);
    }

    @Override
    public boolean equals(Object o) {
      Edge that = (Edge) o;
      return ((this.u).equals(that.u) && (this.v).equals(that.v));
    }
    
    @Override
    public int hashCode() {
      return (u+v).hashCode();
    }
  }
}
