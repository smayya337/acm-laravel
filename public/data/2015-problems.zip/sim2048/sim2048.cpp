//Problem 5 - the 2048 simulation
//Jay Sebastian (jgs3cd)
//NOTE: I haven't tested this beyond the two sample cases

//doing i/o through cin/cout
#include <iostream>
#include <string>

//the grid of numbers
int grid[4][4];
//temp storage for collapsing a row/col
int ftuple[4];

//forward dec
void collapseTuple();

int main(int argc, char** argv) {
    int n;
    std::cin >> n;

    for ( int i = 0; i < n; i++ ) {

        //input the grid
        for (int i = 0; i < 4; i++)
            for(int j = 0; j < 4; j++)
                std::cin >> grid[i][j];
        //now read the input character by character
        //and transform the grid accordingly with each char
        std::string s;
        std::cin >> s;
        for ( int j = 0; j < s.size(); j++ ) {
            // for (int k = 0; k < 4; k++) {
            //     for (int l = 0; l < 4; l++) {
            //         std::cout << grid[k][l] << " ";
            //     }
            //     std::cout <<"\n";
            // }
            // std::cout << "===== About to do " << s[j] << "\n";
            char c = s[j];
            //we load ftuple based on direction
            //kinda repetitive here
            if (c == 'L') {
                for (int i = 0; i < 4; i++) {
                    ftuple[0] = grid[i][0];
                    ftuple[1] = grid[i][1];
                    ftuple[2] = grid[i][2];
                    ftuple[3] = grid[i][3];
                    collapseTuple();
                    grid[i][0] = ftuple[0];
                    grid[i][1] = ftuple[1];
                    grid[i][2] = ftuple[2];
                    grid[i][3] = ftuple[3];
                }
            }
            if (c == 'R') {
                for (int i = 0; i < 4; i++) {
                    ftuple[0] = grid[i][3];
                    ftuple[1] = grid[i][2];
                    ftuple[2] = grid[i][1];
                    ftuple[3] = grid[i][0];
                    collapseTuple();
                    grid[i][3] = ftuple[0];
                    grid[i][2] = ftuple[1];
                    grid[i][1] = ftuple[2];
                    grid[i][0] = ftuple[3];
                }
            }
            if (c == 'U') {
                for (int i = 0; i < 4; i++) {
                    ftuple[0] = grid[0][i];
                    ftuple[1] = grid[1][i];
                    ftuple[2] = grid[2][i];
                    ftuple[3] = grid[3][i];
                    collapseTuple();
                    grid[0][i] = ftuple[0];
                    grid[1][i] = ftuple[1];
                    grid[2][i] = ftuple[2];
                    grid[3][i] = ftuple[3];
                }
            }
            if (c == 'D') {
                for (int i = 0; i < 4; i++) {
                    ftuple[0] = grid[3][i];
                    ftuple[1] = grid[2][i];
                    ftuple[2] = grid[1][i];
                    ftuple[3] = grid[0][i];
                    collapseTuple();
                    grid[3][i] = ftuple[0];
                    grid[2][i] = ftuple[1];
                    grid[1][i] = ftuple[2];
                    grid[0][i] = ftuple[3];
                }
            }
        }

        //now find the max in the grid
        int max = 0;
        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 4; j++)
                if (grid[i][j] > max)
                    max = grid[i][j];
        std::cout << max << "\n";

    }
}

//once ftuple is loaded, this method collapses it
//(i.e. slides the tiles) towards the 0-indexed side
//the tiles closer to index 0 get shifted first
void collapseTuple() {
    for (int i = 1; i < 4; i++) {
        if (ftuple[i] == 0)
            continue;
        for (int j = i-1; j >= 0; j--) {
            if (j == 0 && ftuple[j] == 0) { //hit the edge of the grid
                ftuple[j] = ftuple[i];
                ftuple[i] = 0;
                break;
            } else if (ftuple[j] == ftuple[i]) { //collide with merge
                ftuple[j] = ftuple[j]*2;
                ftuple[i] = 0;
                // Slide everything else down to fill zeros one to avoid two "movements" in one.
                int slideToPos = j+1;
                for (int k = j+1; k < 3; k++) {
                    if (ftuple[k+1] == 0) continue;
                    ftuple[slideToPos] = ftuple[k+1];
                    ftuple[k+1] = 0;
                    slideToPos = k+1;
                }
                ftuple[3] = 0;
                break;
            } else if (ftuple[j] != 0) { //collide w/o merge
                if (j+1 == i)
                    break; //no change needed
                ftuple[j+1] = ftuple[i];
                ftuple[i] = 0;
                break;
            }
            //otherwise ftuple[j] must be 0
            //so we continue the loop
        }
    }
}
