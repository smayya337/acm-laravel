#include<iostream>
#include<vector>
#include<list>
#include<algorithm>
#include<string>

/*
 *  Solution to infiltration in C++
 *  (apn4za)
 *
 *  I pity the fool who decided to use C++ in the contest... writing the "generate combinations"
 * functions is no joke.
 * 
 *  Needs the O2 flag to run right because I'm doing something stupid somewhere and can't find it.
 * If the max node count was 63 instead of 75, Gosper's Hack would be nice here.
 * I also probably should be using a bitset instead of a vector<bool> for representing combinations.
 */

using namespace std;

typedef vector< list<int> > graph_t;

// Combination tools
void initializeCombination(vector<bool>& combination, unsigned int n, unsigned int r); 
bool nextCombination(vector<bool>& combination);
void printVector(vector<bool>& v);

// Graph tools
void stringToList(string s, list<int>& lst);
void printGraph(graph_t& g);

bool isDominating(graph_t& g, vector<bool>& combination, vector<bool>& scratchSpace);

void printSolution(unsigned int caseNum, vector<bool>& combination);

int main() {
  int numCases;
  cin >> numCases;
  
  int numNodes;
  for (int currCase = 0; currCase < numCases; currCase++) {
    cin >> numNodes; // nodes in the graph

    graph_t graph;
    graph.resize(numNodes);

    string s;
    for (int i = 0; i < numNodes; i++) {
      cin >> s;
      stringToList(s, graph.at(i));
    }

    // printGraph(graph);
    
    // Can stop at 6 because of the greedy algorithm
    vector<bool> scratchSpace(numNodes, false);
    vector<bool> combination;

    for (unsigned int infiltratedNodes = 1; infiltratedNodes < 7; infiltratedNodes++) {
      initializeCombination(combination, numNodes, infiltratedNodes);
      do {
        if (isDominating(graph, combination, scratchSpace)) {
          goto handleSolution; // take that, Dijkstra!
        }
      } while(nextCombination(combination));
    }

    handleSolution:
    printSolution(currCase+1, combination);

  }
  
  return 0;
}

void initializeCombination(vector<bool>& combination, unsigned int n, unsigned int r) {
  combination.resize(n);
  fill(combination.begin()+r, combination.end(), false);
  fill_n(combination.begin(), r, true);
}

// Finds the next r-combination from a collection of n items
bool nextCombination(vector<bool>& combination) {
  unsigned int shiftPosition = -1;
  bool needZero = true;
  unsigned int onesAfter = 0;

  // Find leftmost set index with an unset position to its immediate right
  for (unsigned int curr = combination.size(); curr > 0; curr--) {
    if (combination.at(curr - 1)) {
      onesAfter++;
      if (!needZero) {
        shiftPosition = curr - 1;
        onesAfter     = 0; // keep track of the number of set positions after the set position we shift
      }
      needZero = true;
    }
    else {
      needZero = false;
    }
  }

  if (shiftPosition == -1)
    return false; //Error! We're at the end of the combination cycle
  
  // this goes from 
  // [1, 0, 1, 1, 0, 0] -> [1, 0, 1, 0, 1, 0]
  // For this example, onesAfter = 2
  combination.at(shiftPosition)     = false;
  combination.at(shiftPosition + 1) = true;

  // Now, set first onesAfter positions to true
  fill_n(combination.begin(), onesAfter, true);
  // Next, set positions from onesAfter to just before shiftPosition to false
  fill_n(combination.begin() + onesAfter, shiftPosition - onesAfter + 1, false);

  // So, continuing the example:
  // [1, 0, 1, 0, 1, 0] -> [1, 1, X, X, 1, 0] -> [1, 1, 0, 0, 1, 0]

  return true;
}

void printVector(vector<bool>& v) {
  cout << "[ ";
  for (vector<bool>::iterator it = v.begin(); it != v.end(); it++) {
    if (*it) 
      cout << "1 ";
    else 
      cout << "0 ";
  }
  cout << "]" << endl;
}

void stringToList(string s, list<int>& lst) {
  for (int val = 0; val < s.length(); val++) {
    if (s.at(val) == '1')
      lst.push_back(val);
  }
}

void printGraph(graph_t& g) {
  for (unsigned int i = 0; i < g.size(); i++) {
    cout << i << ": [ ";
    
    list<int>& adjNodes = g.at(i);
    for (list<int>::iterator it = adjNodes.begin(); it != adjNodes.end(); it++) {
      cout << *it << " ";
    }

    cout << "]" << endl;
  }
}

bool isDominating(graph_t& g, vector<bool>& combination, vector<bool>& scratchSpace) {
  fill(scratchSpace.begin(), scratchSpace.end(), false);

  for (unsigned int i = 0; i < combination.size(); i++) {
    if (combination.at(i)) {
      scratchSpace.at(i) = true;
      list<int>::iterator end = g.at(i).end();
      for (list<int>::iterator it = g.at(i).begin(); it != end; it++) {
        scratchSpace.at(*it) = true;
      }
    }
  }
  // cout << "combination" << endl;
  // printVector(combination);
  // cout << "domination Check" << endl;
  // printVector(scratchSpace);

  // yay C++11 lambdas
  // return true iff all of the scratch space is true
  return all_of(scratchSpace.begin(), scratchSpace.end(), [](bool b){return b;});
}

void printSolution(unsigned int caseNum, vector<bool>& combination) {
  unsigned int numActive = count_if(combination.begin(), combination.end(), [] (bool b) {return b;});
  cout << "Case " << caseNum << ": " << numActive;
  for (unsigned int i = 1; i <= combination.size(); i++) {
    if (combination.at(i-1))
      cout << " " << i;
  }
  cout << endl;
}
