# Fortune Teller of Fraud?

The oracle Pythia claims she can predict the future. A skeptic wants to prove she is a fraud, so they agree to a challenge. Pythia will predict the temperature of the next 10 days. 10 days later, the skeptic will return with the actual daily temperatures. If she gets at least 8 correct, the skeptic will accept her as the Oracle. If she gets fewer than 5 correct, the skeptic will declare her a fraud. If she gets 5,6, or 7 correct it is a draw. Given Pythia's predictions and the actual temperatures, determine the belief of the skeptic.
