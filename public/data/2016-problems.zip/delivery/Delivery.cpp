#include <iostream>
#include <vector>
#include <list>
#include <stack>
using namespace std;

int main() {
    int t;
    cin >> t;

    for(int itr = 0; itr < t; itr++) {
        int nints, nroads, ntests;
        cin >> nints >> nroads >> ntests;

        // Ready the adjacency map.
        vector<list<int> > adjacents;
        for(int i = 0; i < nints; i++) {
            adjacents.push_back(list<int>());
        }

        // Add things to the map.
        for(int i = 0; i < nroads; i++) {
            int src, dest;
            cin >> src >> dest;
            adjacents[src].push_back(dest);
        }

        // Create a list of whether each spot
        // is accessible by some manner.
        vector<bool> accessible(nints, false);

        // Do a DFS.
        stack<int> toprocess;
        toprocess.push(0);

        while(!toprocess.empty()) {
            int next = toprocess.top();
            toprocess.pop();
            
            if(!accessible[next]) {
                accessible[next] = true;

                // Add all of this node's children to the
                // list of things to process.
                for(list<int>::iterator it = adjacents[next].begin();
                        it != adjacents[next].end();
                        it++) {
                    toprocess.push(*it);
                }
            }
        }
        
        // Do the tests of the various places given and
        // compute the output.
        int found = -1;
        for(int i = 0; i < ntests; i++) {
            int totest;
            cin >> totest;

            if(found == -1 || totest < found) {
                if(!accessible[totest]) {
                    found = totest;
                }
            }
        }

        if(found == -1) {
            cout << "Case " << itr+1 << ": All are accessible" << endl;
        } else {
            cout << "Case " << itr+1 << ": " << found << endl;
        }
    }

    return 0;
}
