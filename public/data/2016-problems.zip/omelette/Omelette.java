import java.util.Scanner;
import java.lang.StringBuilder;

public class Omelette {
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		int ctest = Integer.parseInt(sc.nextLine());
		for(int itest = 1; itest-1 < ctest; itest++){
			String ln = sc.nextLine();
			String[] rgtok = ln.split(" ");
			int sum = 0;
			int prod = 1;
			for(int i = 0; i < rgtok.length; i++){
			    if(rgtok[i].equals("+")){
				sum += prod;
				prod = 1;
			    }
			    else if(rgtok[i].equals("*")){
				//do nothing
				prod *= 1;
			    }
			    else{
				prod *= Integer.parseInt(rgtok[i]);
			    }
			}
			sum += prod;
			System.out.println(fromagize(itest) + ": "+  
					   fromagize(sum));
		}
	}
	
	public static String fromagize(int k){
	    StringBuilder result = new StringBuilder();
	    for(int i = 0; i < k - 1; i++){
		result.append("omelette du fromage ");
	    }
	    if(k > 0)
		result.append("omelette du fromage");
	    return result.toString();
	}
	
}
