# Solves "Power-up Probability" from the 2017 HSPC at UVa
# Solution by Marina Sanusi, 2017

from sys import stdin

if __name__ == '__main__':
  data = stdin.read().splitlines()
  for row in data[1:]: # iterate over all lines except the first 
    row_split = row.split(" ") 
    powerups = {}
    for powerup in row_split[1:]:
      if powerup in powerups:
        powerups[powerup] += 1
      else:
        powerups[powerup] = 1

    max_powerup = ""
    max_times = 0
    tie = False
    for powerup in powerups:
      if powerups[powerup] > max_times:
        max_times = powerups[powerup]
        max_powerup = powerup
        tie = False
      elif powerups[powerup] == max_times:
        tie = True
      
    if not tie:
      print(max_powerup)
    else:
      print("Tie")


