# Gods Abound

Jupiter, Janus, and Juno; Mars, Mercury, and Minerva; Vulcan, Venus, and Vesta. The Romans had many, many gods. And while they're capable enough to remember the names, they need a bit of help remembering that Mercury was the god of blacksmithing, or was it Vulcan? Either way, your task is to write a program to help keep track of which god does what.