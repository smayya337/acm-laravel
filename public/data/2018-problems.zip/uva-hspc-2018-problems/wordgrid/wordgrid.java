// Henry Conklin 2018

import java.util.Scanner;

public class wordgrid {
    private static String[] ds = {"n","ne", "e","se", "s","sw", "w","nw"};
    private static int[] dx    = { 0, 1, 1, 1, 0,-1,-1,-1};
    private static int[] dy    = {-1,-1, 0, 1, 1, 1, 0,-1};
    public static boolean search(int x, int y, int w, int h, int d, String word, String grid) {
        int i = 0;
        // Iterate in a direction until all chars found, invalid char found, or go off the grid
        while (x >= 0 && x < w && y >= 0 && y < h && i < word.length()) {
            if (word.charAt(i) != grid.charAt(y * w + x)) return false;
            x += dx[d];
            y += dy[d];
            i++;
        }
        // Found all chars?
        return i == word.length();

    }


    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int ncases = in.nextInt();
        for (int i = 0; i < ncases; i++) {
            int w = in.nextInt();
            int h = in.nextInt();
            String grid = in.next();
            String word = in.next();
            boolean found = false;
            for (int x = 0; x < w && !found; x++) {
                for (int y = 0; y < h && !found; y++) {
                    for (int d = 0; d < ds.length && !found; d++) {
                        if (search(x,y,w,h,d,word,grid)) {
                            System.out.format("%d %d %s\n", x, y, ds[d]);
                            found = true;
                        }
                    }
                }
            }

            if (!found) System.out.println("not found");
        }
    }
}
