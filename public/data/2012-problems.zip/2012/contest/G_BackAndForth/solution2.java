import java.io.*;
import java.util.*;

/*
* Author: Daniel Epstein, dae5y@virginia.edu
*/
public class solution2 {
	public static int width;
	public static int height;
	public static Player[] players;
	
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int numCases = in.nextInt();
		for(int aaa=1;aaa<=numCases;aaa++) {
			width = in.nextInt();
			height = in.nextInt();
			int numPlayers = in.nextInt();
			players = new Player[numPlayers];
			for(int i=0;i<numPlayers;i++) {
				String name = in.next();
				int x = in.nextInt();
				int y = in.nextInt();
				char dir = in.next().charAt(0);
				players[i] = new Player(name, x, y, dir);
			}
			int numRounds = in.nextInt();
			for(int i=0;i<numRounds;i++) {
				for(int j=0;j<numPlayers;j++)
					players[j].step();
				for(int j=0;j<numPlayers;j++) {
					if(players[j].reversed)
						continue;
					ArrayList<Player> sameLoc = new ArrayList<Player>();
					for(int k=j;k<numPlayers;k++) {
						if(players[k].reversed)
							continue;
						if(players[j].x == players[k].x && players[j].y == players[k].y)
							sameLoc.add(players[k]);
					}
					if(sameLoc.size() == 2) {
						Player p1 = sameLoc.get(0);
						Player p2 = sameLoc.get(1);
						p1.reversed = true;
						p2.reversed = true;
						Player sName = p1.name.length()<p2.name.length()?p1:p2;
						Player lName = p1.name.length()<p2.name.length()?p2:p1;
						int sx = sName.diffX;
						int sy = sName.diffY;
						sName.diffX = -lName.diffX;
						sName.diffY = -lName.diffY;
						lName.diffX = sx;
						lName.diffY = sy;
					} else if(sameLoc.size() > 2) {
						for(Player p : sameLoc) {
							p.reverse();
							p.reversed = true;
						}
					}
				}
			}
			
			double dist = Double.MAX_VALUE;
			int pPos = -1;
			for(int i=1;i<numPlayers;i++) {
				double dSq = players[0].distanceSq(players[i]);
				//System.out.println(players[i].name + " " + dSq);
				if(dSq < dist) {
					dist = dSq;
					pPos = i;
				} else if(Math.abs(dSq - dist) < 0.001) {
					if(players[i].name.length() < players[pPos].name.length())
						pPos = i;
				}
			}
			System.out.println("Case " + aaa + ": " + players[pPos].name);
		}
	}
}

class Player {
	public String name;
	public int x;
	public int y;
	public int diffX;
	public int diffY;
	public boolean reversed = false;
	public Player(String name, int x, int y, char dir) {
		this.name = name;
		this.x = x;
		this.y = y;
		switch(dir) {
			case 'N':
				diffY = 1;
				diffX = 0;
				break;
			case 'S':
				diffY = -1;
				diffX = 0;
				break;
			case 'E':
				diffY = 0;
				diffX = 1;
				break;
			case 'W':
				diffY = 0;
				diffX = -1;
				break;
		}
	}
	
	public void reverse() {
		diffX *= -1;
		diffY *= -1;
	}
	
	public void step() {
		if(x + diffX < 0 || x+diffX >= solution2.width)
			diffX *= -1;
		if(y + diffY < 0 || y+diffY >= solution2.height)
			diffY *= -1;
		x += diffX;
		y += diffY;
		reversed = false;
	}
	
	public double distanceSq(Player other) {
		int xDiff = x - other.x;
		int yDiff = y - other.y;
		return xDiff*xDiff + yDiff*yDiff;
	}
}
