# Solution to "Ancestor Age" (miguel) for HSPC 2018 @ UVA
# By Roman Bohuk, 2018

import sys

# The hard part about this problem is dealing with m's that are not coprime

# Extended euclidean algorithm for modular inverses
def modinv(a, m):
    m_original, x0, x1 = m, 1, 0
    if m == 1: return 0
    while a > 1:
        k, m, a = a // m, a % m, m
        x1, x0 = x0 - k * x1, x1
    return x0 % m_original

def is_prime(n):
    if n in (1,2): return True
    if n%2 == 0: return False
    return all(n % i != 0 for i in range(3, int(n**0.5) + 1, 2))

# Unique factors
factors = lambda n: [i for i in range(2,n+1) if n % i == 0]

# Reduced the modular equations to coprime m's and checks if they are valid
def split_into_comprime(rem, mod):
    d = {} # will store the equations as m:r
    for i in range(len(rem)):
        rt, mt = rem[i], mod[i]
        if mt == 0: continue
        for i in factors(mt):
            # Checks if any of the factors have contradictory remainders
            if i in d.keys() and d[i] != rt % i: return (False, False)
            if i not in d.keys(): d[i] = rt % i
    mod_new = [i for i in d.keys() if is_prime(i)]
    rem_new = [d[i] for i in mod_new]
    return(rem_new, mod_new)

# Chinese remainder theorem
def crt(r, m):
    # Get prime factors
    rem_new, mod_new = split_into_comprime(r, m)
    #print(rem_new, mod_new)
    if not rem_new: return "Cannot be determined"
    else:
        # Product of all mods
        p = 1
        for i in mod_new: p *= i
        # Chinese remainder theorem
        x = 0
        for i in range(len(rem_new)):
            pp = p // mod_new[i]
            x += rem_new[i] * modinv(pp, mod_new[i]) * pp
        x %= p
        # Keep incrementing the value until it is valid
        mx, p_new = max(m), 1
        for i in mod_new: p_new *= i
        while x < mx or not all(r[i] == x % m[i] for i in range(len(m))):
            x += p_new
        return x

# Input
if __name__ == "__main__":
    n = int(sys.stdin.readline())
    for i in range(n):
        m = int(sys.stdin.readline())
        rem, mod = [], []
        for j in range(m):
            t = [int(k) for k in sys.stdin.readline().split(" ")]
            rem.append(t[0])
            mod.append(t[1])
        print(crt(rem,mod))
