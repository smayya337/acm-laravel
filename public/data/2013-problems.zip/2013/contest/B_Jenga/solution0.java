import java.util.Scanner;

public class Jenga {

    public static void main (String[] args) 
    {
        Scanner s = new Scanner(System.in);

	//get number of test cases
        int n = s.nextInt();
        
	//iterate over test cases
        for (int i = 0; i < n; i++)
        {
            System.out.print("Case " + (i + 1) + ": ");
            boolean flag = false;

	    //get number of layers in tower
            int m = s.nextInt();
	    //iterate over layers
            for (int j = 0; j < m; j++)
            {
		//hardcoded possible failure rows
                int row = s.nextInt();
                if (row == 000 || row == 001 || row == 100)
                {
                    flag = true;
                }
            }

	    //after checking all layers, give judgment
            if (flag == false)
            {
                System.out.println("Standing");
            }
            else
            {
                System.out.println("Fallen");
            }
        }
    }

}