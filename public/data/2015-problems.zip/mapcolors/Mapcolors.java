import java.util.Scanner;

public class Mapcolors {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int numProbs = in.nextInt();

        for (int prob = 0; prob < numProbs; prob++) {
            int numRegions = in.nextInt();
            String[] colors = new String[numRegions];
            for (int i = 0; i < colors.length; i++) {
                colors[in.nextInt()] = in.next();
            }

            int numBorders = in.nextInt();
            boolean valid = true;
            for (int i = 0; i < numBorders; i++) {
                int b1 = in.nextInt();
                int b2 = in.nextInt();
                if (colors[b1].equals(colors[b2])) {
                    valid = false;
                }
            }

            if (valid)
                System.out.println("valid");
            else
                System.out.println("invalid");
        }
    }
}
