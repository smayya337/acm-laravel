# Solves "Jmp Mario" from the 2017 HSPC at UVa
# Solution by Marina Sanusi, 2017

from sys import stdin

if __name__ == '__main__':
  data = stdin.read().splitlines()
  n = int(data[0])
  moves = {0: "run", 1: "jump", 2: "double jump"}
  i = 1
  for case in range(n):
    line = [int(x) for x in data[i].split(" ")]
    landscape = line[1:] 
    i += 1
    answer = "Case " + str(case+1) + ":"
    traversable = True

    for j, ground in enumerate(landscape[1:], 2):
      height = ground - line[j-1]
      if height > 2:
        traversable = False
        continue
      elif height < 0:
        answer += " run"
      else:
        answer += " " + moves[height]

    if not traversable:
      print("Case " + str(case+1) + ": not traversable")
    else:
      print(answer)


