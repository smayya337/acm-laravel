import java.util.*;

/*
 * Happy number variant (I'll call them quasi-happy numbers)
 * Iteratively apply a function until you reach a value/range,
 * and print the number of iterations it took.
 *
 * Function: Sum of squares of digits taken two at a time.
 *   (It's essentially the Happy Number function, but using
 *    two-digit numbers as "digits.")
 * Base value/range: If the iteration of f on x ever results in
 *    a two-digit number that is greater than or equal to 50,
 *    then x is quasi-happy.  Similar for quasi-sad.
 *
 * I've designed this program so I can easily replace the function
 *    and the success condition.
 *
 * Solution by Andrew Norton; for questions, email apn4za@virginia.edu
 *    with [HSPC 2015] in the subject line.
 */

public class Happy {
    public static void main(String[] args) {
        Scanner cin = new Scanner(System.in);
        int N = cin.nextInt(); //Number of test cases

        for (int test = 0; test < N; test++) { //For each test case
            int x = cin.nextInt(); //Read in the starting variable
            int appCount = 0;      //Number of times the function is applied

            //Keep applying f until we reach the base case
            while (!reachedBase(x) && appCount <= 1000) {
                x = f(x);
                appCount++;
            }

            //Print number of function applications
            if (appCount > 1000)
                System.out.println("LONG");
            else if (x >= 50 && x < 100)
                System.out.println("QUASI-HAPPY: " + appCount);
            else //x > 0 by construction, so `else` is justified.
                System.out.println("QUASI-SAD: " + appCount);
        }
    }

    //The arbitrary function
    //Idea: Happy numbers, but taken two digits at a time
    public static int f(int x) {
        int sum = 0;
        while (x > 0) {
            sum += (x % 100) * (x % 100);
            x /= 100;
        }

        return sum;
    }

    //The "success" condition
    //If we reach a 2-digit number that ends in a
    //  prime digit, the number is quasi-happy.
    public static boolean reachedBase(int x) {
        return (x >= 0 && x < 100);
    }
}
