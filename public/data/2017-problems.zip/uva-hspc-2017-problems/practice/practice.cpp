// Solves "Practice" from the 2017 HSPC at UVa
// Solution by Aaron Bloomfield, 2017

#include <iostream>
using namespace std;
int main() {
  unsigned int n, x;
  cin >> n;
  for ( unsigned int i = 0; i < n; i++ ) {
    cin >> x;
    cout << x*x << endl;
  }
  return 0;
}
