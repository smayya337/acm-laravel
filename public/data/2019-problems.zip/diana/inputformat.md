The input for this problem will begin with a single integer $n \leq 1,000$. There will be $n$ test cases that follow.


Each test case will be on a single line consisting of three floating-point numbers. The first number is the initial velocity of the arrow $0 < v_i \leq 1,000$, in m/s. The second number is the angle at which Diana fires $-\frac{\pi}{2} < \theta < \frac{\pi}{2}$, in radians. The final number is the x-position of the target $0 < x \leq 10,000$ given in meters.