   #include <iostream>
   using namespace std;

   int main() {
      int inputs;
      cin >> inputs;
    
      //iterate over cases
      for (int x = 1; x <= inputs; x++) { 
	//read in problem
         int rows, batterylife;
         cin >> rows;
         cin >> batterylife;
         int startx, starty;
         int messx, messy;
      
	 //read in board
         char room[rows][rows];
         for (int r = 0; r < rows; r++) {
            string s; 
            cin >> s;
            for (int c = 0; c < rows; c++) {  
               room[r][c] = s[c];
               if (s[c] == 'r')
               {
                  startx = r;
                  starty = c;
               }
               if (s[c] == 'm') {
                  messx = r;
                  messy = c;
               }
            }
         }
         int currx = startx;
         int curry = starty;
         int min = 0;
         int currbattery = batterylife;
         bool end = false;
         int dir = 90; //degree 90 is to the right
         bool beenThere[rows][rows][4];
         for (int a = 0; a < rows; a++) {
            for (int y = 0; y < rows; y++) {
               for (int z = 0; z < 4; z++) {
                  beenThere[a][y][z]=false;
                  
               }
            }
         }

         while(end == false) {
	   //keep track of where you've been
            if (dir == 90)  {
               if (beenThere[currx][curry][0] == true) {
                  cout << "Case " << x << ": NEVER" << endl;
                  end = true;
                  break;
               }
               else
                  beenThere[currx][curry][0] = true;
            }
            else if (dir == 180)  {
               if (beenThere[currx][curry][1] == true) {
                  cout << "Case " << x << ": NEVER" << endl;
                  end = true;
                  break;
               }
               else
                  beenThere[currx][curry][1] = true;
            }
            else if (dir == 270)  {
               if (beenThere[currx][curry][2] == true) {
                  cout << "Case " << x << ": NEVER" << endl;
                  end = true;
                  break;
               }
               else
                  beenThere[currx][curry][2] = true;
            }
            else   {
               if (beenThere[currx][curry][3] == true) {
                  cout << "Case " << x << ": NEVER" << endl;
                  end = true;
                  break;
               }
               else
                  beenThere[currx][curry][3] = true;
            }

	    //clean the mess         
            if (room[currx][curry] == 'm') {
               cout << "Case " << x << ": " << min << endl;
               end = true;
               break;
            }
            if (currbattery == 0)
            {
               cout << "Case " << x << ": NEVER" << endl;
               end = true;
               break;
            }
	    
	    //charge the plug
            if (room[currx][curry+1] == 'p' || room[currx][curry-1] == 'p' || room[currx+1][curry] == 'p' || room[currx-1][curry] == 'p' )  {
               if (currbattery <= batterylife/2) {
                  min += (batterylife - currbattery);
                  currbattery = batterylife; }
            }
	    //if right
            if (dir == 90) {
               char c = room[currx][curry+1];
	       
               if (c == '-' || c == 'm' || c == 'r') {
                  curry = curry+1;
                  min++;
                  currbattery--;
               }
               else if (c == 'x' || 'p') {
                  dir = (dir+90)%360;
                  min++;
                  currbattery--;
               }
            
            }
	    //if down
            else if (dir == 180) {
               char c = room[currx+1][curry];
	       
               if (c == '-' || c == 'm' || c == 'r') {
                  currx = currx + 1;
                  min++;
                  currbattery--;
               }
               else if (c == 'x' || c == 'p') {
                  dir = (dir+90)%360;
                  min++;
                  currbattery--;
               }
            
            }
	    //if left
            else if (dir == 270) {
               char c = room[currx][curry-1];
              
               if (c == '-' || c == 'm' || c == 'r') {
                  curry = curry - 1;
                  min++;
                  currbattery--;
               }
               else if (c == 'x' || c == 'p') {
                  dir = (dir+90)%360;
                  min++;
                  currbattery--;
               }
            
            }
	    //if up
            else if (dir == 0) {
               char c = room[currx-1][curry];
              
               if (c == '-' || c == 'm' || c == 'r') {
                  currx = currx - 1;
                  min++;
                  currbattery--;
               }
               else if (c == 'x' || 'p') {
                  dir = (dir+90)%360;
                  min++;
                  currbattery--;
               }
            
            }
         }
      
      }
   
      return 0;
   }
