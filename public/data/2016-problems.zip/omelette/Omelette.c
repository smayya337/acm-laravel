#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void printODF(int num) {
	int j = 0;
	for(j = 0; j < num; j++) {
		if(j < num-1) {
			printf("omelette du fromage ");
		} else {
			printf("omelette du fromage");
		}
	}
}
int main() {
	int numitems = 0;
	int i=0;
	scanf(" %i ", &numitems);
	for(i=0;i<numitems; i++) {
		printODF(i+1);
		printf(": ");
		int cur;
		int total = 0;
		int curproduct = 1;
		char s[3];
		while(1 == 1) {
			scanf(" %i ", &cur);
			cur = cur * curproduct;
			if(scanf(" %[+] ", s) == 1) {
				// add to running sum
				total += cur;
				curproduct = 1;
			} else if(scanf(" %[*] ", s) == 1) {
				// multiply into running product
				curproduct = cur;
				continue;
			} else {
				// end of line
				total += cur;
				curproduct = 1;
				break;
			}
		}
		printODF(total);
		printf("\n");
	}
	return 0;
}
