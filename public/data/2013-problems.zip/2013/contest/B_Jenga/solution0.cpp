#include <iostream>
#include <string>
using namespace std;

int main(int argc, char* argv[])
{
  int times;

  //get number of cases, and iterate over cases
  cin >> times;
  for(int i = 1; i <= times; i++)
    {
      int rows;
      cin >> rows;
      int standing = 1;

      //iterate over rows
      for(int j = 0; j < rows; j++)
	{
	  
	  string layer;
	  cin >> layer;

	  //if the middle is missing along with either side, fallen
	  if(layer[1] == '0' && (layer[0] == '0' || layer[2] == '0'))
	    {
	      standing = 0;
	    }
	}
      
      //report whether standing
      cout << "Case " << i << ": ";
      if(standing)
	{
	  cout << "Standing";
	}
      else
	{
	  cout << "Fallen";
	}
      cout << '\n';
    }
  
  return 0;
}
