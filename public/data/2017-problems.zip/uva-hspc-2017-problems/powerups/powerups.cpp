// Solves "Power-up Probability" from the 2017 HSPC at UVa
// Solution by Aaron Bloomfield, 2017

#include <iostream>
#include <map>
#include <string>
#include <vector>
using namespace std;
int main() {
  unsigned int x, y, max;
  cin >> x;
  for ( unsigned int i = 0; i < x; i++ ) {
    cin >> y;
    map<string,unsigned int> m;
    string s;
    max = 0;
    for ( unsigned int j = 0; j < y; j++ ) {
      cin >> s;
      if ( max < ++m[s] )
	max = m[s];
    }
    vector<string> v;
    for ( map<string,unsigned int>::iterator it = m.begin(); it != m.end(); it++ )
      if ( it->second == max )
	v.push_back(it->first);
    if ( v.size() > 1 )
      cout << "Tie" << endl;
    else
      cout << v[0] << endl;
  }
  return 0;
}
