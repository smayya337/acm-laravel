// Solves "Kirby Your Enthusiasm" from the 2017 HSPC at UVa
// Solution by Joseph Tobin, 2017

import java.util.*;

public class kirby {
    public static void main(String args[]) {
	Scanner cin = new Scanner(System.in);
	int numCases = cin.nextInt();
	for(int currCase = 0; currCase <  numCases; currCase++ ) {
	    int numActions = cin.nextInt();
	    String state = "Kirby";
	    for(int i = 0; i < numActions; i++ ) {
		String input = cin.next();
		if(input.equals("release")) {
		    state = "Kirby";
		}
		else if(input.equals("copy")) {
		    if(state.equals("Kirby")) {
			state = cin.next();
		    }
		    else {
			cin.next();
		    }
		}
	    }
	    System.out.println(state);
	}
    }
}
