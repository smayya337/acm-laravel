import java.util.*;

public class Brute {
    public static void main(String[] args) {
        Scanner cin = new Scanner(System.in);
        int testCt = cin.nextInt();
        for (int testNum = 0; testNum < testCt; testNum++) {
            int len = cin.nextInt();
            int moveCt = cin.nextInt();
            cin.nextLine(); //Advance to next line
            String goal = cin.nextLine();

            ArrayList<String> moves = new ArrayList<String>();
            for (int i = 0; i < moveCt; i++)
                moves.add(cin.nextLine());

            String start = "";
            for (int i = 0; i < len; i++)
                start += 'H';

            if (canReachDFS(start, goal, moves))
                System.out.println("CAN BE SOLVED");
            else
                System.out.println("CANNOT BE SOLVED");

        }
    }

    public static String makeMove(String source, String move) {
        String retVal = "";
        for (int i = 0; i < source.length(); i++) {
            if (move.charAt(i) == 'F') {
                if (source.charAt(i) == 'H')
                    retVal += 'T';
                else
                    retVal += 'H';
            } else
                retVal += source.charAt(i);
        }

        return retVal;
    }

    public static boolean canReachDFS(String source, String dest, ArrayList<String> moves) {
        Stack<String> s = new Stack<String>();
        Set<String> visited = new HashSet<String>();
        s.push(source);
        while (!s.empty()) {
            String curr = s.pop();
            if (curr.equals(dest))
                return true;
            visited.add(curr);

            for (String move : moves) {
                String nextState = makeMove(curr, move);
                if (!visited.contains(nextState))
                    s.push(nextState);
            }
        }

        return false; //could not reach goal
    }
}
