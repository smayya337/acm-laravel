import java.util.*;
class caesar {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int nCases = in.nextInt();
        in.nextLine();
        for (int i = 0; i < nCases; i++) {
            String line = in.nextLine();
            for (int j = 0; j < line.length(); j++) {
                if (line.charAt(j) == ' ')
                    System.out.print(' ');
                else
                    System.out.print((char)(((line.charAt(j) - 'A' + 13) % 26) + 'A'));
            }
            System.out.println();
        }
    }
}
