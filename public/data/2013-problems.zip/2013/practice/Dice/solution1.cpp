// Bloomfield's dice solution, 3-11-13
#include <iostream>
using namespace std;
int main() {
  int n, x, y;
  cin >> n;
  for ( int i = 1; i <= n; i++ ) {
    cin >> x >> y;
    cout << "Case " << i << ": " << (x+y) << endl;
  }
}

    
