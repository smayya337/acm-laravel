import java.util.*;
import java.io.*;
import java.text.*;

public class Intflip {
	public static void main(String[] args) {
		Scanner fin = new Scanner(System.in);
		
		while (fin.hasNextLine()) {
			String line = fin.nextLine();
			long num = Long.parseLong(line);
			if (num < 0) break;
			
			String bin = Long.toBinaryString(num);
			while (bin.length() < 32) bin = "0" + bin;
			
			//System.out.println(bin);
			
			char[] revAra = new char[32];
			for (int i = 0; i < 32; i++) revAra[i] = bin.charAt(31-i);
			
			String rev = new String(revAra);
			
			long numRev = Long.parseLong(rev, 2);
			
			//System.out.println(rev);
			System.out.println(numRev);
		}
	}
}