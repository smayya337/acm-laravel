/*
 * Title: Tug of War (8.6.5, p. 181)
 * 
 * Solved: Adelin Miloslavov, Dec 13, 2010
 * 
 * Problem description: Up to 100 people in a picnic decide to play tug of war.
 * You are supposed to find the setup of two teams that would have the least
 * difference in weight between them. The two teams should also have an equal
 * number of people or differ by at most one person (where there are an
 * odd-number of people).
 * 
 * 
 * Problem solution: This is a dynamic programming problem that requires a lot
 * of pruning. There is a solution in the binder that would not run in time.
 * This solution is achieved by incrementally adding people to each team one by
 * one and forming a triple C(w,i,j), which indicates that a weight difference
 * of w can be achieved by having i people on team 1 and j people on team 2.
 * Each generated triple is then used to generate new triples as more people are
 * added to the teams. There are O(n^3*M) possible pairs, where n is the number
 * of people (max 100) and M is the maximum weight of a person (450). In order
 * to have the solution run in time, some of the triples need to be eliminated
 * early which would eliminate the search for all triples deriving from them.
 * The pruning can be done by running a heuristic to determine a possible
 * minimum difference and then for each triple perform checks to see if that
 * triple may lead to a better solution and discard the triple if that's not the
 * case.
 * 
 * 
 * Tricks and implementation details: Do not forget that the number of people in
 * each team needs to be the same. You also may want to use C++ in order to do
 * less pruning. One heuristic for determining a good starting minimum value is
 * to order the people by weight and put the even numbered people on one side
 * and the odd numbered people on the other. Then you can do a quick check to
 * see if swapping two people would improve the minimum. Then this minimum can
 * be used at each triple to check if that triple has the potential to yield a
 * better result. One way to check this is to put all of the remaining lightest
 * people on the currently heavier side (until the team size is a half of all
 * people) and the heaviest people on the other side and see if the originally
 * heavier side is still heavier with a difference greater than the pruning
 * value. You also want to pre-compute the sum of the weight of each segment of
 * remaining people so that it is not computed at every pair
 */
import java.io.*;
import java.math.BigInteger;
import java.util.*;

public class AdelinBalancing {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int count = 0;
		int numCases = in.nextInt();
		while (in.hasNext()) {
			int N = in.nextInt();
			ArrayList<Integer> people = new ArrayList<Integer>();
			int max = 0;
			int total = 0;
			// Read the input
			for (int i = 0; i < N; i++) {
				int q = in.nextInt();
				people.add(q);
				total += q;
				if (q > max)
					max = q;
			}
			// Sort the people by weight
			Collections.sort(people);
			// Create a sample arrangement to serve as a benchmark when pruning the tree
			int minDiff = 0;
			for (int i = 0; i < N; i++) {
				if ((i % 2) == 0)
					minDiff += people.get(i);
				else
					minDiff -= people.get(i);
			}
			int pairDiff = Math.abs(minDiff);
			boolean change = true;
			boolean[] forbidden = new boolean[N];
			int curI = 0;
			int curJ = 0;
			// Stop when we find a minimum difference equal or less than 1
			// (since it can't get better)
			// Try performing swaps so that we improve the min diff value (to
			// give us a better pruning value)
			while ((minDiff < -1 || minDiff > 1) && change == true) {
				change = false;
				for (int i = 0; i < N; i += 2) {
					for (int j = 1; j < N; j += 2) {
						if (!forbidden[i] && !forbidden[j]) {
							if (Math.abs(-(people.get(i) - people.get(j)) * 2
									+ minDiff) < Math.abs(pairDiff)) {
								pairDiff = -(people.get(i) - people.get(j)) * 2
										+ minDiff;
								curI = i;
								curJ = j;
								change = true;
							}
						}
					}
				}
				forbidden[curI] = true;
				forbidden[curJ] = true;
				minDiff = pairDiff;
			}
			if (minDiff < 0)
				minDiff = -minDiff;
			// Find the total weight of people of a certain weight or less
			ArrayList<Integer> totals = new ArrayList<Integer>();
			totals.add(people.get(0));
			for (int i = 1; i < people.size(); i++) {
				totals.add(totals.get(i - 1) + people.get(i));
			}
			// Add the first person to one of the sides
			HashSet<Triple> dp = new HashSet<Triple>();
			dp.add(new Triple(people.get(0), 1, 0));
			HashSet<Triple> newDp = new HashSet<Triple>();

			int smaller = N / 2;
			int bigger = N / 2 + 1;
			if (smaller + bigger != N)
				bigger = smaller;
			//Run the real exhaustive search with pruning
			for (int k = 1; k < N; k++) {
				int curW = people.get(k);
				// Stop if we have an optimal solution
				if (minDiff == 0 || (total % 2 == 1 && minDiff == 1))
					break;
				//Go through each previously generated triple
				for (Triple t : dp) {
					// Stop if we have an optimal solution
					if (minDiff == 0 || (total % 2 == 1 && minDiff == 1))
						break;
					// Try filling the rest of one side with all the remaining people
					if (t.i == bigger && t.w > 0) {
						int remain = total - totals.get(k - 1);
						if (Math.abs(t.w - remain) < minDiff)
							minDiff = Math.abs(t.w - remain);
					}
					// Try filling the rest of the other side with all the remaining people
					if (t.j == bigger && t.w < 0) {
						int remain = total - totals.get(k - 1);
						if (Math.abs(t.w + remain) < minDiff)
							minDiff = Math.abs(t.w + remain);
					}
					// Prune when the current configuration cannot beat the current stored minimum (for one side)
					if (t.w < 0 && smaller - t.j >= 0 && bigger - t.i >= 0) {
						int maxAchieveValue = t.w
								- (totals.get(smaller - t.j + k - 1) - totals
										.get(k - 1));
						int remain = total - totals.get(smaller - t.j + k - 1);
						if (maxAchieveValue + remain < 0
								&& -(maxAchieveValue + remain) >= minDiff)
							continue;
					}
					// Prune when the current configuration cannot beat the current stored minimum (for the other side)
					if (t.w > 0 && bigger - t.j >= 0 && smaller - t.i >= 0) {
						int maxAchieveValue = t.w
								+ (totals.get(smaller - t.i + k - 1) - totals
										.get(k - 1));
						int remain = total - totals.get(smaller - t.i + k - 1);
						if (maxAchieveValue + remain < 0
								&& maxAchieveValue + remain >= minDiff)
							continue;
					}
					// While there can be more people inserted
					if (t.i <= bigger && t.j <= bigger) {
						// Try inserting person on left side
						if (!(curW + t.w > total / 2 + minDiff + 1))
							newDp.add(new Triple(curW + t.w, t.i + 1, t.j));
						// Try inserting person on right side
						if (!(-curW + t.w < -total / 2 - minDiff - 1))
							newDp.add(new Triple(-curW + t.w, t.i, t.j + 1));
						// Update the minimum value when a full solution is available
						if (t.i + t.j + 1 == N && t.i + 1 - t.j <= 1 && t.j - t.i - 1 <= 1) {
							if (Math.abs(curW + t.w) < minDiff)
								minDiff = Math.abs(curW + t.w);
						}
						// Update the minimum value when a full solution is available
						//We this check differs from the above, because it changes on which side the extra person would be for an odd-numbered solution
						if (t.i + t.j + 1 == N && t.i - t.j - 1 <= 1&& t.j + 1 - t.i <= 1) {
							if (Math.abs(-curW + t.w) < minDiff)
								minDiff = Math.abs(-curW + t.w);
						}
					}
				}
				//Save the old triples and create a new trile set
				HashSet<Triple> temp = dp;
				dp = newDp;
				temp.clear();
				newDp = temp;
			}
			// 2x + minDiff = total
			int x = (total - minDiff) / 2;
			int y = x + minDiff;
			if (N == 1) {
				x = 0;
				y = people.get(0);
			}
			// Print the minimum solution
			System.out.println(x + " " + y);
			count++;
			//if (count != numCases)
			//	System.out.println();
		}

	}
}

class Triple {
	public int w;
	public int i;
	public int j;

	public Triple(int w, int i, int j) {
		this.w = w;
		this.i = i;
		this.j = j;
	}

	public String toString() {
		return w + " " + i + " " + j;
	}

	@Override
	public boolean equals(Object aThat) {
		Triple t = (Triple) aThat;
		return (t.w == w && t.i == i && t.j == j);
	}

	@Override
	public int hashCode() {
		return w + 45001 * i + 50000000 * j;
	}
}