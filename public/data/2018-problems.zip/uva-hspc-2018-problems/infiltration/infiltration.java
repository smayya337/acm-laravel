// Henry Conklin 2018
import java.util.Arrays;
import java.util.BitSet;
import java.util.Scanner;

public class infiltration {

    // Find the next combination of k (comb.length) out of n elements in lexographic order
    // Treat combination as a k digit number in base n, with constraint that digits are strictly increasing
    // returns false if there are no more combinations
    public static boolean nextCombination(int[] comb, int n) {
        return carry(comb, n, comb.length-1);
    }

    // Carry over an increment if an element reaches the end
    // returns false if there are no more combinations
    public static boolean carry(int[] comb, int n, int i) {
        // Done if tried to carry most significant digit (index 0)
        if (i < 0) return false;
        if (comb[i] < n-(comb.length - i)) {
            comb[i]++;
            return true;
        }
        else {
            if (!carry(comb, n, i-1)) return false;
            comb[i] = comb[i-1]+1;
            return true;
        }
    }

    public static int[] initCombination(int k) {
        int[] comb = new int[k];
        for (int i = 0; i < k; i++) {
            comb[i] = i;
        }
        return comb;
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int ncases = in.nextInt();
        for (int cnum = 1; cnum <= ncases; cnum++) {
            int c = in.nextInt();
            in.nextLine();

            // Initialize a list of bitsets to represent the input graph
            // Cell i controls cell j iff the jth bit of cells[i] is set
            BitSet[] cells = new BitSet[c];
            for (int i = 0; i < c; i++) {
                cells[i] = new BitSet(c);
                String line = in.nextLine();
                for (int j = 0; j < c; j++) {
                    // Input says cell i controls cell j, also i controls itself
                    cells[i].set(j, (line.charAt(j) == '1' || i == j));
                }
            }

            // Can prove that there is a covering set of at most 6 cells
            // Brute force all combinations of up to 6 cells, return the smallest
            boolean done = false;
            int[] comb = {0};
            for (int i = 1; i <= 6 && !done; i++) {
                comb = initCombination(i);
                do {
                    done = covers(comb, cells, c);
                    if (done) break;
                } while (nextCombination(comb, c));
            }

            System.out.format("Case %d: %d", cnum, comb.length);
            for (int i : comb) {
                System.out.format(" %d", i+1);
            }
            System.out.println();


        }
    }

    private static boolean covers(int[] comb, BitSet[] cells, int c) {
        BitSet b = new BitSet(c);

        // Add in all cells controlled by each element of the combination
        for (int i : comb) {
            b.or(cells[i]);
        }
        // Are all bits set?
        return b.cardinality() == c;
    }
}
