/*
 * C++ solution to keysort
 *
 * by Aaron Bloomfield, 2018
 */

#include <iostream>
#include <map>
#include <string>
using namespace std;

int main() {
  int n, d, x;
  string door;
  cin >> n;
  for ( int i = 0; i < n; i++ ) {
    cout << "Case " << i+1 << ":" << endl;
    cin >> d;
    map<int,string> doors;
    for ( int j = 0; j < d; j++ ) {
      cin >> x >> door;
      doors[x] = door;
    }
    for ( auto it = doors.begin(); it != doors.end(); it++ )
      cout << it->second << endl;
  }
  return 0;
}
