// Bloomfield's even more dice solution, 3-11-13
#include <iostream>
#include <vector>
using namespace std;

void output (vector<int> num);

//iterate through ordered permutations
bool addone (vector<int> &num, int max) {
  for ( int i = num.size()-1; i >= 0; i-- )
    if ( ++num[i] > max )
      num[i] = 1;
    else
      break;
  // check overflow
  bool valid = false;
  for ( int i = num.size()-1; i >= 0; i-- )
    if ( num[i] != 1 )
      valid = true;
  return valid;
}

//confirm ordering property
bool valid (vector<int> num) {
  for ( int i = 0; i < num.size()-1; i++ )
    if ( num[i] > num[i+1] )
      return false;
  return true;
}

//add up vector
int getsum (vector<int> num) {
  int sum = 0;
  for ( int i = 0; i < num.size(); i++ )
    sum += num[i];
  return sum;
}

//print vector
void output (vector<int> num) {
  cout << "(";
  for ( int i = 0; i < num.size(); i++ ) {
    cout << num[i];
    if ( i != num.size()-1 )
      cout << ",";
  }
  cout << ")\n";
}

int main() {
  int n, d, m, s;
  cin >> n;
  for ( int i = 1; i <= n; i++ ) {
     cin >> d >> m >> s;
     cout << "Case " << i << ":\n";
    // initialize number
    vector<int> num(d);
    for ( int i = 0; i < num.size(); i++ )
      num[i] = 1;
    // consider possibilities
    while ( addone(num,m) )
      if ( valid(num) &&
	   (getsum(num) == s) )
	output(num);
  }
}

    
