#include <iostream>
#include <string>
#include <cstdlib>
using namespace std;

// yes i'm aware this is supah hacky but ugh c++
int getHourOfTime(string s) {
    string toReturn = "";
    for (int i = 0; i < s.length(); i++) {
        if (s[i] == ':')
            return atoi(toReturn.c_str());
        toReturn += s[i];
    }
    return -1;
}

int getMinuteOfTime(string s) {
    int index = 0;
    for (int i = 0; i < s.length(); i++) {
        if (s[i] == ':') {
            index = i;
            break;
        }
    }
    string toReturn = "";
    for (int i = index+1; i < s.length(); i++)
        toReturn += s[i];
    return atoi(toReturn.c_str());
}

int main() {
    int numCases;
    cin >> numCases;
    for (int n = 0; n < numCases; n++) {
        int hours, minutes;
        string start, end;
        cin >> hours;
        cin >> minutes;
        cin >> start;
        int startHour = getHourOfTime(start);
        int startMin = getMinuteOfTime(start);
        cin >> end;
        int endHour = getHourOfTime(end);
        int endMin = getMinuteOfTime(end);
        int count;
        double minOverHour = (double)minutes / hours;
        double percentOfHour = (double)startMin / minutes;
        double minutesMoreBecauseTime = percentOfHour * minOverHour;
        double hoursAngle = startHour * minOverHour + minutesMoreBecauseTime;
        double percentOfHour2 = (double)endMin / minutes;
        double minutesMoreBecauseTime2 = percentOfHour2 * minOverHour;
        double hoursAngle2 = endHour * minOverHour + minutesMoreBecauseTime2;
        if (startHour == endHour) {
            double poi = (minOverHour * endHour) / (1 - minOverHour / minutes);
            if (poi >= hoursAngle && poi <= hoursAngle2) count=1;
            else count = 0;
        } else {
            count = endHour - startHour - 1;
            if (count < 0)	count = 0;
            if (hoursAngle >= startMin) count++;
            if (hoursAngle2 <= endMin) count++;
        }
        cout << count << endl;
    }
    return 0;
}
