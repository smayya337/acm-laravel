# Solves "Pokeballs" from the 2017 HSPC at UVa
# Solution by Andrew Norton, 2017

from sys import stdin

def determine_winner(s):
  n = int(s)
  if n % 7 == 0 or n % 7 == 1:
    return "Second"
  else:
    return "First"
  
if __name__ == '__main__':
  data = stdin.read().splitlines()[1:]

  # "map" applies the "determine_winner" function to each item of data
  winners = map(determine_winner, data)
  for winner in winners:
    print(winner)


