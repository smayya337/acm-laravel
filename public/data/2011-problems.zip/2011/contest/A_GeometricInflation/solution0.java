import java.util.Scanner;
import java.text.NumberFormat;

public class Interest {
	public static void main(String[] args) {
		Scanner fin = new Scanner(System.in);
		
		NumberFormat fmt = NumberFormat.getCurrencyInstance();
		
		while (true) {
			double m1 = fin.nextDouble();
			if (m1 < 0) break;
			double m2 = fin.nextDouble();
			double m3 = fin.nextDouble();
			
			int N = fin.nextInt();
			
			if (N == 1)
				System.out.println("Month " + N + " cost: " + fmt.format(m1));
			else if (N == 2)
				System.out.println("Month " + N + " cost: " + fmt.format(m2));
			else if (N == 3)
				System.out.println("Month " + N + " cost: " + fmt.format(m3));
			else {
				for (int i = 3; i < N; i++) {
					double newVal = Math.round(m1*m2/m3*100.0)/100.0;
					m1 = m2;
					m2 = m3;
					m3 = newVal;
				}
				System.out.println("Month " + N + " cost: " + fmt.format(m3));			
			}
		}
	}
}
