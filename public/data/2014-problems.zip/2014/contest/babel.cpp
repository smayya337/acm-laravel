#include <iostream>
#include <cmath>
using namespace std;

int main() {
    while(true) {
        int c, w, l, p;
        cin >> c >> w >> l >> p;
        if(c == 0 && w == 0 && l == 0 && p == 0)
            break;
        cout << (int)pow(c, w * l * p) << endl;
    }
    return 0;
}
