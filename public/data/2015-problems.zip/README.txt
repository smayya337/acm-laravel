2015 ACM@UVA HSPC Problems
==========================

Internally, the problems were referred to under different names
(so we could theme the contest in any of a variety of ways).  So,
all the sample solutions (and judge I/O) in this zip file are
stored with these internal names instead of the names from the
contest packet.  A mapping is provided below:

Problem     Internal Name
  A           conversion
  B           rounded
  C           strings
  D           mapcolors
  E           happy
  F           change
  G           sim2048
  H           trees
  I           clocks
  J           coingame

Solutions have been provided in Java and C++ for all contest 
problems.  If a solution or input file is missing, please contact
HSPC staff at hspc@virginia.edu.
