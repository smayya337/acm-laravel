/* Matthew Hurtz
 * Canyon Crossing
 * Verified for Judging Data on 3.5.12
 */
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;

public class solution2 {
	public static void main(String[] args) {
		Scanner fin = new Scanner(System.in);
		
		int CS = fin.nextInt();
		for (int c = 0; c < CS; c++) {
			int H = fin.nextInt();
			int W = fin.nextInt();
			int N = fin.nextInt();
			
			ArrayList<Node> nodes = new ArrayList<Node>();
			
			Node bottom = new Node();
			bottom.edgePos = 0;
			nodes.add(bottom);
			
			Node top = new Node();
			top.edgePos = H;
			nodes.add(top);
			
			for (int n = 0; n < N; n++) {
				double x = fin.nextDouble();
				double y = fin.nextDouble();
				double r = fin.nextDouble();
				
				Node newNode = new Node();
				newNode.x = x;
				newNode.y = y;
				newNode.r = r;
				
				for (Node node : nodes) {
					if (newNode.intersects(node)) {
						node.links.add(newNode);
						newNode.links.add(node);
					}
				}
                
                nodes.add(newNode);
			}
            
			System.out.println("Case " + (c+1) + ": " + ((bottom.connectedTo(top)) ? "Find Another Path" : "Clear To Go"));
		}
	}
}

class Node {
	HashSet<Node> links = new HashSet<Node>();
	
	double x, y, r;
	
	int edgePos = -1;
	
	boolean visited = false;
    
    boolean isCon = false;
    boolean isNotCon = false;
	
	public boolean intersects(Node other) {
		if (edgePos != -1) {
			if (other.edgePos != -1) {
                return (edgePos == other.edgePos);
            }
			return (Math.abs(other.y - edgePos) <= other.r);
		} else if (other.edgePos != -1) {
			return other.intersects(this);
		}
		
		double deltaX = x - other.x;
		double deltaY = y - other.y;
		return (deltaX*deltaX+deltaY*deltaY <= (r+other.r)*(r+other.r));
	}
    
    /*public boolean intersects(Node other) {
		double dX = x - other.x;
		double dY = y - other.y;
		double distSq = dX*dX + dY*dY;
		double rSq = (r+other.r)*(r+other.r);
		return rSq >= distSq;
	}*/
	
	public Node() {
		
	}
	
	public boolean connectedTo(Node end) {
		if (this == end) return true;
        if (isCon) return true;
        if (isNotCon) return false;
		
		visited = true;
		
		for (Node n : links) {
			if (!n.visited) {
				if (n.connectedTo(end)) {
                    isCon = true;
					return true;
				}
			}
		}
		
		visited = false;
		
        isNotCon = true;
		return false;
	}
}
