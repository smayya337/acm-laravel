// Solves "High Scores!" from the 2017 HSPC at UVa
// Solution by Aaron Bloomfield, 2017

#include <iostream>
#include <string>
using namespace std;
int main() {
  string p, s;
  unsigned int n, c;
  cin >> n;
  for ( unsigned int i = 0; i < n; i++ ) {
    cin >> c;
    cin >> p;
    for ( unsigned int j = 0; j < c-1; j++ ) {
      cin >> s;
      if ( s.length() < p.length() )
	p = p.substr(0,s.length());
      for ( unsigned int k = p.length(); k >= 1; k-- )
	if ( s.substr(0,k) != p.substr(0,k) )
	  p = p.substr(0,k-1);
    }
    if ( p != "" )
      cout << p << endl;
    else
      cout << "No Common Prefix" << endl;
  }
  return 0;
}
