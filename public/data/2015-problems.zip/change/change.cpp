#include <iostream>
#include <vector>
#include <cmath>
using namespace std;

int min(int i, int j) {
    return i > j ? j : i;
}

int indexOfLargestLessThan(int lessThan, vector<int>& denoms, int indexMax) {
    for (int i = min(denoms.size()-1, indexMax); i >= 0; i--) {
        if (denoms[i] <= lessThan)
            return i;
    }
    return -1;
}

int findNumWays(int sum, vector<int>& denoms, int indexMax) {
    //cout << sum << endl;
    if (sum == 0)
        return 1;
    int indexLessThanSum = indexOfLargestLessThan(sum, denoms, indexMax);
    //cout << "indexLessThanSum of " << sum << " and " << indexMax << " is " << indexLessThanSum << endl;
    int numComb = 0;
    for (int i = indexLessThanSum; i >= 0; i--) {
        int newSum = sum - denoms[i];
        //cout << denoms[i] << endl;
        numComb += findNumWays(newSum, denoms, i);
    }
    //cout << numComb << endl;
    return numComb;
}

int main() {
    int numCases;
    cin >> numCases;
    for (int i = 1; i <= numCases; i++) {
        int numCoins;
        cin >> numCoins;
        int numSums;
        cin >> numSums;
        vector<int> coinDenoms;
        for (int j = 0; j < numCoins; j++) {
            int d;
            cin >> d;
            coinDenoms.push_back(d);
        }
        vector<int> solutions;
        for (int j = 0; j < numSums; j++) {
            int s;
            cin >> s;
            int toPush = findNumWays(s, coinDenoms, coinDenoms.size());
            //cout << toPush << endl;
            solutions.push_back(toPush);
            //cout << solutions[j] << endl;
        }
        cout << "Case " << i << ":";
        for (int j = 0; j < solutions.size(); j++)
            cout << " " << solutions[j];
        cout << endl;
    }
}
