import java.util.Scanner;

public class echo {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int testCases = in.nextInt();
        for(int i = 0; i < testCases; i++) {
            int echos = in.nextInt();
            in.nextLine();
            String line = in.nextLine();
            for(int j = 0; j < echos; j++) {
                System.out.println(line);
            }
        }
    }
}
