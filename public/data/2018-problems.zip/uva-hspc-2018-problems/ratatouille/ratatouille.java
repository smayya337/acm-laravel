import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class ratatouille {
  public static void main(String[] args) {
    Scanner cin = new Scanner(System.in);

    int numCases = cin.nextInt();

    for (int testCase = 1; testCase <= numCases; testCase++) {
      System.out.printf("Case %d:\n", testCase); // Print header

      int inventorySize = cin.nextInt();
      int numRecipes    = cin.nextInt();

      // First, we must process the inventory data
      HashMap<String, Integer> pantry = readFoodData(inventorySize, cin); // Pantry stores amount of each food

      for (int i = 0; i < numRecipes; i++) {

        // Next, we go through each recipe in order and check if we can make it
        int ingredientCount = cin.nextInt();
        HashMap<String, Integer> ingredientsList = readFoodData(ingredientCount, cin); // amount of each food

        boolean canMake = canMakeRecipe(pantry, ingredientsList);

        if (canMake) {
          useIngredients(pantry, ingredientsList);
          System.out.println("Yes");
        }
        else {
          System.out.println("No");
        }
      }

    }
  }

  private static HashMap<String, Integer> readFoodData(int numFoods, Scanner cin) {
    HashMap<String, Integer> data = new HashMap<>(); // stores inventory food that is read in
    for (int i = 0; i < numFoods; i++) {
      // Grab the input values
      int quantity = cin.nextInt();
      String foodName = cin.nextLine().trim(); // Trim because we don't like whitespace

      data.put(foodName, quantity);
    }

    return data;
  }

  /* 
   * Here, I'm using the Java 8 features of lambdas, streams, and predicates.
   * If you haven't used them before, don't worry --- they're still pretty new and rarely covered in courses.
   * You don't need them, though! This code only loops through every key in `recipe` and checks that
   * recipe.get(key) < pantry.getOrDefault(key, 0) for each key.  The "getOrDefault(s, 0)" means "get the value associated with s, 
   * or 0 if s is not in the hash map."
   */ 
  private static boolean canMakeRecipe(HashMap<String, Integer> pantry, HashMap<String, Integer> recipe) {
    Predicate<String> enoughFood = s -> recipe.get(s) <= pantry.getOrDefault(s, 0);
    return recipe.keySet().stream().allMatch(enoughFood);
  }

  /* Same deal here --- I'm using lambdas and streams to take the pantry hashmap, then subtract the used ingredients from
   * each entry in the map.
   */
  private static void useIngredients(HashMap<String, Integer> pantry, HashMap<String, Integer> recipe) {
    pantry.entrySet().stream()
      .forEach(
        e -> e.setValue(
                        e.getValue() - recipe.getOrDefault(e.getKey(), 0)
                       )
      );
  }
}
