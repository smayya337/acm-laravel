#include <iostream>
#include <stdio.h>
#include <cmath>

using namespace std;

int main(){
 int cases;
 cin >> cases;
 for(int i = 0; i < cases; i++){
   int publicans;
   cin >> publicans;
   double expectedProfit = 0;
   double ratio = pow(2, publicans) / (pow(2, publicans) - 1);
   for(int j = 0; j < publicans; j++){
     int worth;
     cin >> worth;
     expectedProfit += worth * ratio * 0.5;
   } 
   printf("%0.3f", expectedProfit);
 }
}
