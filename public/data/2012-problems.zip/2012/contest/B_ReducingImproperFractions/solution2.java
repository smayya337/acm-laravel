/**Problem: Reducing Improper Fractions
 * Solver: Jonathan DiLorenzo jd9hz@virginia.edu
 * Problem Writers: Allison Light aml9j@virginia.edu, Matthew Hurtz mnh7mc@virginia.edu
 * Time Taken: 8 min
 * Overall Thoughts: Seems fairly reasonable. Very easy, but a couple of interesting
 * corner cases though they may need to be more rigorously defined. 
 * Things to fix: In the input section, specify that the two values will be separated by
 * a space. In the output section, define what should happen if N mod D is 0, where I
 * presumed you should remove the N/D part, but it was unclear.
**/
import java.util.*;
public class solution2
{
	public static void main(String[] args)
	{
    	Scanner in = new Scanner(System.in);
    	int n, d;
    	int numCases = in.nextInt();
    	for(int cas=1;cas<=numCases;cas++)
    	{
        	n = in.nextInt();
        	d = in.nextInt();
        	if (d == 0)
        	{
            	System.out.println("Case " + cas + ": " + "Cannot divide by 0.");
        	}
        	else if (n%d == 0)
        	{
            	System.out.print("Case " + cas + ": " + n/d + "\n");   
        	}
        	else if (n/d == 0)
        	{
            	System.out.print("Case " + cas + ": " + n%d + "/" + d + "\n");   
        	}       	 
        	else
        	{
            	System.out.print("Case " + cas + ": " + n/d + " " + n%d + "/" + d + "\n");          	 
        	}
    	}
}
}
