// Henry Conklin 2018
// Mostly copied the other solutions
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

class miguel {

    // Euclid's algorithm for modular inverse
    public static long modinv(long x, long m) {
        long morig = m;
        long x0 = 1;
        long x1 = 0;
        if (m == 1) return 0;
        while (x > 1) {
            if (m == 0) return 0;
            long k = x / m;
            long temp = m;
            m = x % m;
            x = temp;
            temp = x1;
            x1 = x0 - k * x1;
            x0 = temp;
        }
        return x0 < 0 ? x0 + morig : x0;
    }

    public static boolean isPrime(int n) {
        if (n == 1) return false;
        if (n <= 3) return true;
        if (n % 2 == 0) return false;
        int bound = (int)(Math.round(Math.sqrt(n)));
        for (int i = 3; i <= bound; i+=2) {
            if (n % i == 0) return false;
        }
        return true;
    }

    // Reduce the equations to equations using prime divisors
    // Less specific than original equations but still consistent even if
    // moduli are not coprime
    public static Map<Integer, Integer> reduce(int[] mods, int[] rems) {
        Map<Integer, Integer> res = new HashMap<Integer, Integer>();
        for (int i = 0; i < mods.length; i++) {
            int m = mods[i];
            // Get prime factors
            for (int f = 2; f <= m; f++) {
                // f is a prime factor
                if (m % f == 0 && isPrime(f)) {
                    // if remainder mod prime divisor doesn't match other equations
                    if (res.containsKey(f) && rems[i] % f != res.get(f)) return null;
                    if (!res.containsKey(f)) {
                        res.put(f, rems[i] % f);
                    }
                }
            }
        }
        return res;
    }

    public static int gcd(int a, int b) {
        while (b != 0) {
            int t = b;
            b = a % b;
            a = t;
        }
        return a;
    }

    public static boolean isPossible(int[] mods, int[] rems) {
        for (int i = 0; i < mods.length; i++) {
            for (int j = i+1; j < mods.length; j++) {
                int pairgcd = gcd(mods[i], mods[j]);
                if (rems[i] % pairgcd != rems[j] % pairgcd) return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int ncases = in.nextInt();
        for (int i = 0; i < ncases; i++) {
            int neqs = in.nextInt();
            int[] mods = new int[neqs];
            int[] rems = new int[neqs];
            long N = 1;
            for (int j = 0; j < neqs; j++) {
                rems[j] = in.nextInt();
                mods[j] = in.nextInt();
                N *= mods[j];
            }
//            System.err.println(i);
//            System.err.println(Arrays.toString(mods));
//            System.err.println(Arrays.toString(rems));

            // Check if system is consistent
            if (!isPossible(mods,rems)) {
                System.out.println("Cannot be determined");
                continue;
            }

            // Reduce system to a system of prime moduli
            Map<Integer, Integer> reduced = reduce(mods, rems);
            if (reduced == null) {
                System.out.println("Cannot be determined");
                continue;
            }

            // Find a solution consistent with the reduced equations
            long M = 1;
            for (int m : reduced.keySet()) M *= m;

            boolean works = true;
            long soln = 0;
            for (int m : reduced.keySet()) {
                long b = M/m;
                long binv = modinv(b, m);
                if (binv == 0) {
                    works = false;
                    break;
                }
                soln += reduced.get(m) * b * binv;
                soln %= M;
            }
            if (!works) {
                System.out.println("Cannot be determined");
                continue;
            }

            // Solution matches reduced equations, need to increment
            // until it matches the original equations
            int mx = mods[0];
            for (int j = 0; j < mods.length; j++) mx = Math.max(mods[j], mx);
            while (soln < mx || !consisent(soln, mods, rems)) {
                soln += M;
            }

            System.out.println(soln);
        }
    }

    private static boolean consisent(long soln, int[] mods, int[] rems) {
        for (int i = 0; i < mods.length; i++) {
            if (soln % mods[i] != rems[i]) return false;
        }
        return true;
    }
}