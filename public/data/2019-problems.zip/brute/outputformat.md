Output a single floating point number denoting the probability that Caesar survives. The output should be accurate and truncate to three decimal places. 
