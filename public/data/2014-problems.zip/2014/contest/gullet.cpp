#include <iostream>
#include <string>
using namespace std;

void knapsack(int space, int numItems, int itemVolumes[], int itemCalories[]);

int main() {
    int space;
    cin >> space;
    while(space != 0) {
        int numItems;
        cin >> numItems;
        int itemVolumes[numItems];
        int itemCalories[numItems];
        for(int i = 0; i < numItems; i++) {
            cin >> itemVolumes[i];
            cin >> itemCalories[i];
        }
        knapsack(space, numItems, itemVolumes, itemCalories);
        cin >> space;
    }
}

void knapsack(int space, int numItems, int itemVolumes[], int itemCalories[]) {
    int quantity[space+1][numItems];
    int optimal[space+1][2];
    for(int i = 0; i < numItems; i++) quantity[0][i] = 0;
    optimal[0][0] = 0;
    optimal[0][1] = 0;
    for(int i = 1; i < space+1; i++) {
        int tally = -1;
        optimal[i][0] = optimal[i-1][0];
        optimal[i][1] = optimal[i-1][1];
        for(int j = numItems - 1; j > -1; j--) {
            if (i - itemVolumes[j] < 0
                    || optimal[i-itemVolumes[j]][1] + itemVolumes[j] > space)
                continue;
            if( optimal[i][0] < optimal[i-itemVolumes[j]][0] + itemCalories[j] ) {
                optimal[i][0] = optimal[i-itemVolumes[j]][0] + itemCalories[j];
                optimal[i][1] = optimal[i-itemVolumes[j]][1] + itemVolumes[j];
                tally = j;
            }
        }
        if (tally>-1) {
            for (int j = 0; j < numItems; j++) {
                quantity[i][j] = quantity[i-itemVolumes[tally]][j];
            }
            quantity[i][tally]++;
        } else
            for (int j = 0; j < numItems; j++) {
                quantity[i][j] = quantity[i-1][j];
            }
    }
    for(int i = 0; i < numItems; i++) {
        cout << quantity[space][i];
        if(i<numItems-1)
            cout << " ";
    }
    cout << endl;
}
