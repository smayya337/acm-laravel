import sys

ncases = int(sys.stdin.readline())
for i in range(ncases):
    words = sys.stdin.readline().strip().split(" ")
    nwords = int(words[0])
    words = words[1:]

    outline = ""
    for w in words:
        if w == 'bing':
            outline += 'bong'
        elif w == 'Bing':
            outline += 'Bong'
        elif w == 'BING':
            outline += 'BONG'
        else:
            outline += w

        outline += " "

    print(outline)
        
