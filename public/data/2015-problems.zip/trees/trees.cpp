#include <iostream>
#include <string>
#include <cstdlib>
#include <sstream>

// Because we explicitly reconstruct our tree, we need a node type
typedef struct node {
    node * left;
    node * right;
    int data;
} node;

// A little utility type to make dealing with array segments nicer
typedef struct {
    int * start;
    int length;
} slice;

// Declaring our primary functions
node * buildTree(const slice &prefix, const slice &infix);
std::string printTree(const node * tree);
void deleteTree(const node * tree);

int main(void) {
    std::string input;
    getline(std::cin, input);
    const int cases = atoi(input.c_str());
    for(int x = 0; x < cases; ++x) {
        getline(std::cin, input);
        const int size = atoi(input.c_str());
        int prefix[size];
        int infix[size];

        for(int i = 0; i < size; ++i) {
            std::cin >> input;
            prefix[i] = atoi(input.c_str());
        }

        for(int i = 0; i < size; ++i) {
            std::cin >> input;
            infix[i] = atoi(input.c_str());
        }

        // Clear out the trailing newline
        getline(std::cin, input);

        const slice pre = { prefix, size };
        const slice in = { infix, size };
        std::string postfix = printTree(buildTree(pre, in));
        postfix.erase(postfix.length() - 1);
        std::cout << postfix << std::endl;
    }

    return 0;
}

node * buildTree(const slice &prefix, const slice &infix) {
    if(prefix.length <= 0) return NULL;
    int index = 0;
    // We don't bounds check here because we can safely assume that the infix
    // will always contain the necessary element
    while(infix.start[index] != *prefix.start) ++index;
    node * curr = new node;
    curr->data = *prefix.start;
    const slice curr_pre_left = { prefix.start + 1, index };
    const slice curr_in_left = { infix.start, index };
    const slice curr_pre_right = { prefix.start + 1 + index, prefix.length - index - 1 };
    const slice curr_in_right = { infix.start + index + 1, infix.length - index - 1 };
    curr->left = buildTree(curr_pre_left, curr_in_left);
    curr->right = buildTree(curr_pre_right, curr_in_right);

    return curr;
}

std::string printTree(const node * tree) {
    std::stringstream result;
    if(tree->left) result << printTree(tree->left);
    if(tree->right) result << printTree(tree->right);
    result << tree->data << " ";
    return result.str();
}

void deleteTree(const node * tree) {
    if(tree->left) deleteTree(tree->left);
    if(tree->right) deleteTree(tree->right);
    delete tree;
    tree = NULL;
}
