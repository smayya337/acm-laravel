import java.util.*;
import java.io.*;
import java.text.*;
import java.awt.geom.*;

public class PropertyHurtzManual {
	public static void main(String[] args) {
		Scanner fin = new Scanner(System.in);
		
		while (true) {
			double W = fin.nextDouble();
			double H = fin.nextDouble();
			int N = fin.nextInt();
			
			if ( (W == 0) && (H == 0) && (N == 0)) break;
			
			double totalLand = W*H;
			
			MyArea claimed = new MyArea();
			MyArea disputed = new MyArea(); 
			
			double totalClaimSum = 0.0;
			
			for (int i = 0; i < N; i++) {
				MyRect newAreaRect = new MyRect(fin.nextDouble(), fin.nextDouble(), fin.nextDouble(), fin.nextDouble());
				
				MyArea newlyDisputed = claimed.createIntersection(newAreaRect);
				disputed.addArea(newlyDisputed);
				
				claimed.addRect(newAreaRect);
			}
			
			double claimedLand = claimed.getArea();
			double disputedLand = disputed.getArea();
			
			NumberFormat format = NumberFormat.getInstance();
			format.setMinimumFractionDigits(3);
			format.setMaximumFractionDigits(3);
			format.setGroupingUsed(false);
			
			System.out.println("Disputed: " + format.format(disputedLand));
			System.out.println("Claimed: " + format.format(claimedLand));
			System.out.println("Unclaimed: " + format.format(totalLand-claimedLand));
		}
	}
	
	public static class MyArea {
		private TreeSet<MyRect> includedRects;
		
		public MyArea() {
			includedRects = new TreeSet<MyRect>();
		}
		
		public void addRect(MyRect newRect) {
			TreeSet<MyRect> allNewRects = new TreeSet<MyRect>();
			allNewRects.add(newRect);
			
			doBreakdown(allNewRects);
			
			includedRects.addAll(allNewRects);
		}
		
		public void addArea(MyArea otherArea) {
			for (MyRect tmp : otherArea.includedRects)
				this.addRect(tmp);
		}
		
		private void doBreakdown(TreeSet<MyRect> newRects) {
			boolean foundBreakdown = true;
			
			while (foundBreakdown) {
				foundBreakdown = false;
				
				for (MyRect newRect : newRects) {
					for (MyRect existingRect : includedRects) {
						if (newRect.intersects(existingRect)) {
							foundBreakdown = true;
							
							// Ok we need to create the new rectangles we'll have to deal with
							newRects.remove(newRect);
							
							// Now add in the subcomponents that aren't overlapping
							Rectangle2D.Double intersect = newRect.createIntersection(existingRect);
							
							double[] Xs = new double[4];
							double[] Ys = new double[4];
							
							Xs[0] = Math.min(newRect.getX(), existingRect.getX());
							Xs[1] = intersect.getX();
							Xs[2] = intersect.getX()+intersect.getWidth();
							Xs[3] = Math.max(newRect.getX()+newRect.getWidth(), newRect.getX()+newRect.getWidth());
							
							Ys[0] = Math.min(newRect.getY(), existingRect.getY());
							Ys[1] = intersect.getY();
							Ys[2] = intersect.getY()+intersect.getHeight();
							Ys[3] = Math.max(newRect.getY()+newRect.getHeight(), newRect.getY()+newRect.getHeight());
							
							Arrays.sort(Xs);
							Arrays.sort(Ys);
							
							MyRect n1 = new MyRect(Xs[0], Ys[0], Xs[1]-Xs[0], Ys[1]-Ys[0]);
							if (n1.intersects(newRect) && !n1.intersects(existingRect)) newRects.add(n1);
							
							MyRect n2 = new MyRect(Xs[1], Ys[0], Xs[2]-Xs[1], Ys[1]-Ys[0]);
							if (n2.intersects(newRect) && !n2.intersects(existingRect)) newRects.add(n2);
							
							MyRect n3 = new MyRect(Xs[2], Ys[0], Xs[3]-Xs[2], Ys[1]-Ys[0]);
							if (n3.intersects(newRect) && !n3.intersects(existingRect)) newRects.add(n3);
							
							
							MyRect n4 = new MyRect(Xs[0], Ys[1], Xs[1]-Xs[0], Ys[2]-Ys[1]);
							if (n4.intersects(newRect) && !n4.intersects(existingRect)) newRects.add(n4);
							
							MyRect n5 = new MyRect(Xs[1], Ys[1], Xs[2]-Xs[1], Ys[2]-Ys[1]);
							if (n5.intersects(newRect) && !n5.intersects(existingRect)) newRects.add(n5);
							
							MyRect n6 = new MyRect(Xs[2], Ys[1], Xs[3]-Xs[2], Ys[2]-Ys[1]);
							if (n6.intersects(newRect) && !n6.intersects(existingRect)) newRects.add(n6);
							
							
							
							MyRect n7 = new MyRect(Xs[0], Ys[2], Xs[1]-Xs[0], Ys[3]-Ys[2]);
							if (n7.intersects(newRect) && !n7.intersects(existingRect)) newRects.add(n7);
							
							MyRect n8 = new MyRect(Xs[1], Ys[2], Xs[2]-Xs[1], Ys[3]-Ys[2]);
							if (n8.intersects(newRect) && !n8.intersects(existingRect)) newRects.add(n8);
							
							MyRect n9 = new MyRect(Xs[2], Ys[2], Xs[3]-Xs[2], Ys[3]-Ys[2]);
							if (n9.intersects(newRect) && !n9.intersects(existingRect)) newRects.add(n9);
							
							break;
						}
					}
					if (foundBreakdown) break;
				}
			}
		}
		
		public MyArea createIntersection(MyRect rect) {
			MyArea newArea = new MyArea();
			
			for (MyRect tmp : this.includedRects) {
				if (tmp.intersects(rect)) {
					MyRect intersectRect = tmp.createIntersection2(rect);
					newArea.addRect(intersectRect);
				}
			}
			
			return newArea;
		}
		
		public double getArea() {
			double area = 0;
			
			for (MyRect rect : includedRects) {
				area += rect.getWidth()*rect.getHeight();
			}
			
			return area;
		}
	}
	
	public static class MyRect extends Rectangle2D.Double implements Comparable {
		public MyRect(double x, double y, double w, double h) {
			super(x, y, w, h);
		}
		
		public boolean intersects(MyRect other) {
			return super.intersects(other.getX(), other.getY(), other.getWidth(), other.getHeight());
		}
		
		public MyRect createIntersection(MyRect other) {
			Rectangle2D.Double out = new Rectangle2D.Double(0,0,0,0);
			Rectangle2D.intersect(this, other, out);
			return new MyRect(out.getX(), out.getY(), out.getWidth(), out.getHeight());
		}
		
		public MyRect createIntersection2(MyRect other) {
		
			double[] Xs = new double[4];
			double[] Ys = new double[4];
			
			Xs[0] = this.getX();
			Xs[1] = other.getX();
			Xs[2] = this.getX()+this.getWidth();
			Xs[3] = other.getX()+other.getWidth();
			
			Ys[0] = this.getY();
			Ys[1] = other.getY();
			Ys[2] = this.getY()+this.getHeight();
			Ys[3] = other.getY()+other.getHeight();
			
			Arrays.sort(Xs);
			Arrays.sort(Ys);
			
			MyRect ret = new MyRect(Xs[1], Ys[1], Xs[2]-Xs[1], Ys[2]-Ys[1]);
			return ret;
		}
		
		public int compareTo(Object o) {
			MyRect o2 = (MyRect) o;
			return this.toString().compareTo(o2.toString());
		}
	}
}