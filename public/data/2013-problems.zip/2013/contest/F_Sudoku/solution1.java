import java.util.Scanner;

public class Sudoku2 {

    public static void main (String[] args) 
    {
        Scanner s = new Scanner(System.in);
        
        int n = s.nextInt();
        
	//iterate over each case
        for (int i = 0; i < n; i++)
        {
            System.out.print("Case " + (i + 1) + ": ");
            int[][] board = new int[9][9];
            
	    //read in board
            for (int r = 0; r < 9; r++)
            {
                for (int c = 0; c < 9; c++)
                {
                    board[r][c] = s.nextInt();
                }
            }
            
            
            boolean correctBoard = true;
            
            //Check each row
            for (int r = 0; r < 9; r++)
            {
                boolean[] numbersFound = new boolean[9];
                for (int c = 0; c < 9; c++)
                {
		    //if find the same value again, failure
                    int currNum = board[r][c];
                    if (numbersFound[currNum-1] == true)
                        correctBoard = false;
                    
                    numbersFound[currNum-1] = true;
                }
            }
            
            //Check each column
            for (int c = 0; c < 9; c++)
            {
                boolean[] numbersFound = new boolean[9];
                for (int r = 0; r < 9; r++)
                {
		    //if find the same value again, failure
                    int currNum = board[r][c];
                    if (numbersFound[currNum-1] == true)
                        correctBoard = false;
                    
                    numbersFound[currNum-1] = true;
                }
            }
            
            //Check each block
            for (int r = 0; r < 9; r+=3)//increment by 3s to iterate over blocks
            {
                for (int c = 0; c < 9; c+=3)
                {
                    boolean[] numbersFound = new boolean[9];
                    
                    for (int c2 = 0; c2 < 3; c2++)
                    {
                        for (int r2 = 0; r2 < 3; r2++)
                        {
			    //if find the same value again, failure
                            int currNum = board[r+r2][c+c2];
                            if (numbersFound[currNum-1] == true)
                                correctBoard = false;
                            
                            numbersFound[currNum-1] = true;
                        }
                    }
                }
            }
            
	    //report findings
            if (correctBoard == true)
                System.out.println("CORRECT");
            
            else 
                System.out.println("INCORRECT");
        }
        
    }
        
}

