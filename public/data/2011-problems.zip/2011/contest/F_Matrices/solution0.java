import java.util.*;
public class TriMat
{
	public static void main(String[] args)
	{
		new TriMat();
	}
	public TriMat()
	{
		Scanner in = new Scanner(System.in);
		int N = in.nextInt();
		while(N > 0)
		{
			Map<String,Matrix> matrices = new HashMap<String,Matrix>();
			for(int i = 0; i < N; i++)
			{
				String k = in.next();
				int size = in.nextInt();
				int[][] m = new int[size][size];
				for(int j = 0; j < size; j++)
					for(int l = 0; l <= j; l++)
						m[j][l] = in.nextInt();
				matrices.put(k,new Matrix(m,size));
			}
			
			Stack<String> stack = new Stack<String>();
			String q = in.nextLine();
			q = in.nextLine();
			String[] ex = q.split(" ");
			boolean fail = false;;
			int counter = 0;
			for(int i = 0; i < ex.length; i++)
			{
				
				if(ex[i].equals("+"))
				{
					Matrix b = matrices.get(stack.pop());
					Matrix a = matrices.get(stack.pop());
					counter++;
					String r = "R" + counter + "";
					matrices.put(r,new Matrix(add(a.ints,b.ints,a.size),a.size));
					stack.push(r);
				}
				else if(ex[i].equals("*"))
				{	
					Matrix b = matrices.get(stack.pop());
					Matrix a = matrices.get(stack.pop());
					if(b.size < a.size)
					{
						System.out.println("Invalid Expression");
						fail = true;
						break;
					}
					counter++;
					String r = "R" + counter + "";
					matrices.put(r,new Matrix(multiply(a.ints,b.ints,a.size,b.size),b.size-a.size+1));
					stack.push(r);
				}
				else
					stack.push(ex[i]);
				
			}
			if(!fail)
				print(matrices.get(stack.pop()));
			N = in.nextInt();
		}
	}
	public void print(Matrix k)
	{
		int[][] m = k.ints;
		for(int j = 0; j < k.size; j++)
		{
			for(int l = 0; l <= j; l++)
				System.out.print(m[j][l] + " ");
			System.out.println();
		}
	}
	public int[][] add(int[][] a, int[][] b, int size)
	{
		int[][] c = new int[size][size];
		for(int i = 0; i < size; i++)
			for(int j = 0; j <= i; j++)
				c[i][j] = a[i][j] + b[i][j];
		return c;
	}
	public int[][] multiply(int[][] a, int[][] b, int asize, int bsize)
	{
		int size = bsize - asize + 1;
		int[][] c = new int[size][size];
		for(int i = 0; i < size; i++)
			for(int j = 0; j <= i; j++)
				for(int ai = 0; ai < asize; ai++)
					for(int aj = 0; aj <= ai; aj++)
						c[i][j] += a[ai][aj] * b[ai + i][aj + j];
		return c;
	}
	private class Matrix
	{
		int[][] ints;
		int size;
		public Matrix(int[][] ints, int size)
		{
			this.size = size;
			this.ints = ints;
		}
	}
	
}
