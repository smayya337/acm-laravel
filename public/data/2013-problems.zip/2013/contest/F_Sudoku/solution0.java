import java.util.Scanner;

//solution could also use Set/Hashset

public class Sudoku {
	
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		int cases = scanner.nextInt();

		//iterate over cases
		for (int i = 0; i < cases; i++) {
		    //run the checker in a method
			if (checkSudoku(scanner)) {
				System.out.println("Case " + (i+1) + ": " + "CORRECT");
			}
			else {
				System.out.println("Case " + (i+1) + ": " + "INCORRECT");
			}
		}
		
	}
	
	public static boolean checkSudoku(Scanner scanner) {
		
		int numRows = 9;
		int numCols = 9;
		
		//read in board
		int[][] sudoku = new int[numRows][numCols];
		for (int i = 0; i < numRows; i++) {
			for (int j = 0; j < numCols; j++) {
				sudoku[i][j] = scanner.nextInt();
			}
		}
			
		//check if rows have repeats
		for (int rowNum = 0; rowNum < numRows; rowNum++) {
			for (int i = 0; i < sudoku[rowNum].length; i++) {
				for (int j = i + 1; j < sudoku[rowNum].length; j++) {
					if (sudoku[rowNum][i] == sudoku[rowNum][j]) {
						return false;
					}
				}
			}
		}	
		
		//check if columns have repeats
		for (int colNum = 0; colNum < numCols; colNum++) {
			for (int i = 0; i < sudoku[colNum].length; i++) {
				for (int j = i + 1; j < sudoku[colNum].length; j++) {
					if (sudoku[i][colNum] == sudoku[j][colNum]) {
						return false;
					}
				}
			}
		}
		
		//check if 3x3 boxes have repeats
		int startRow, endRow, startCol, endCol;
		
		//box 1
		startRow = 0;
		endRow = 3;
		startCol = 0;
		endCol = 3;
		for (int i = startRow; i < endRow; i++) {
			for (int j = startCol; j < endCol; j++) {
				for (int m = startRow; m < endRow; m++) {
					for (int n = startCol; n < endCol; n++) {
						if ((sudoku[i][j] == sudoku[m][n]) && (i != m) && (j != n)) {
							return false;
						}
					}
				}
			}
		}
		
		//box 2
		startRow = 0;
		endRow = 3;
		startCol = 3;
		endCol = 6;
		for (int i = startRow; i < endRow; i++) {
			for (int j = startCol; j < endCol; j++) {
				for (int m = startRow; m < endRow; m++) {
					for (int n = startCol; n < endCol; n++) {
						if ((sudoku[i][j] == sudoku[m][n]) && (i != m) && (j != n)) {
							return false;
						}
					}
				}
			}
		}
		
		//box 3
		startRow = 0;
		endRow = 3;
		startCol = 6;
		endCol = 9;
		for (int i = startRow; i < endRow; i++) {
			for (int j = startCol; j < endCol; j++) {
				for (int m = startRow; m < endRow; m++) {
					for (int n = startCol; n < endCol; n++) {
						if ((sudoku[i][j] == sudoku[m][n]) && (i != m) && (j != n)) {
							return false;
						}
					}
				}
			}
		}
		
		//box 4
		startRow = 3;
		endRow = 6;
		startCol = 0;
		endCol = 3;
		for (int i = startRow; i < endRow; i++) {
			for (int j = startCol; j < endCol; j++) {
				for (int m = startRow; m < endRow; m++) {
					for (int n = startCol; n < endCol; n++) {
						if ((sudoku[i][j] == sudoku[m][n]) && (i != m) && (j != n)) {
							return false;
						}
					}
				}
			}
		}
		
		//box 5
		startRow = 3;
		endRow = 6;
		startCol = 3;
		endCol = 6;
		for (int i = startRow; i < endRow; i++) {
			for (int j = startCol; j < endCol; j++) {
				for (int m = startRow; m < endRow; m++) {
					for (int n = startCol; n < endCol; n++) {
						if ((sudoku[i][j] == sudoku[m][n]) && (i != m) && (j != n)) {
							return false;
						}
					}
				}
			}
		}
		
		//box 6
		startRow = 3;
		endRow = 6;
		startCol = 6;
		endCol = 9;
		for (int i = startRow; i < endRow; i++) {
			for (int j = startCol; j < endCol; j++) {
				for (int m = startRow; m < endRow; m++) {
					for (int n = startCol; n < endCol; n++) {
						if ((sudoku[i][j] == sudoku[m][n]) && (i != m) && (j != n)) {
							return false;
						}
					}
				}
			}
		}
		
		//box 7
		startRow = 6;
		endRow = 9;
		startCol = 0;
		endCol = 3;
		for (int i = startRow; i < endRow; i++) {
			for (int j = startCol; j < endCol; j++) {
				for (int m = startRow; m < endRow; m++) {
					for (int n = startCol; n < endCol; n++) {
						if ((sudoku[i][j] == sudoku[m][n]) && (i != m) && (j != n)) {
							return false;
						}
					}
				}
			}
		}
		
		//box 8
		startRow = 6;
		endRow = 9;
		startCol = 3;
		endCol = 6;
		for (int i = startRow; i < endRow; i++) {
			for (int j = startCol; j < endCol; j++) {
				for (int m = startRow; m < endRow; m++) {
					for (int n = startCol; n < endCol; n++) {
						if ((sudoku[i][j] == sudoku[m][n]) && (i != m) && (j != n)) {
							return false;
						}
					}
				}
			}
		}
		
		//box 9
		startRow = 6;
		endRow = 9;
		startCol = 6;
		endCol = 9;
		for (int i = startRow; i < endRow; i++) {
			for (int j = startCol; j < endCol; j++) {
				for (int m = startRow; m < endRow; m++) {
					for (int n = startCol; n < endCol; n++) {
						if ((sudoku[i][j] == sudoku[m][n]) && (i != m) && (j != n)) {
							return false;
						}
					}
				}
			}
		}

		//as failures make the method return, must be a success at this point
		return true;
	}

}

