import java.util.Arrays;
import java.util.Scanner;


public class Sim2048 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int n = s.nextInt();
        for ( int k = 0; k < n; k++ ) {

            int[][] board = new int[4][4];

            for (int i = 0; i < 4; ++i) {
                for (int j = 0; j < 4; ++j) {
                    board[i][j] = s.nextInt();
                }
            }

            String moves = s.next();

            for (char move : moves.toCharArray()) {
                // for (int i = 0; i < board.length; ++i) {
                //     System.out.println(Arrays.toString(board[i]));
                // }
                // System.out.println("--- Going to " + move + "\n");
                doMove(board, move);
            }

            System.out.println(highest(board));
        }
    }

    public static void doMove(int[][] board, char move) {
        if (move == 'U') {
            rotateClockwise(board);
            rotateClockwise(board);
            rotateClockwise(board);
            collapseAllRowsLeft(board);
            rotateClockwise(board);
        } else if (move == 'D') {
            rotateClockwise(board);
            collapseAllRowsLeft(board);
            rotateClockwise(board);
            rotateClockwise(board);
            rotateClockwise(board);
        } else if (move == 'L') {
            collapseAllRowsLeft(board);
        } else { // R
            rotateClockwise(board);
            rotateClockwise(board);
            collapseAllRowsLeft(board);
            rotateClockwise(board);
            rotateClockwise(board);
        }
    }

    public static int highest(int[][] board) {
        int highest = 0;
        for (int i = 0; i < board.length; ++i) {
            for (int j = 0; j < board.length; ++j) {
                if (board[i][j] > highest)
                    highest = board[i][j];
            }
        }
        return highest;
    }

    public static void collapseAllRowsLeft(int[][] board) {
        for (int row = 0; row < board.length; ++row) {
            int[] curRow = board[row];
            collapseRowLeft(board[row]);
        }
    }

    public static void collapseRowLeft(int[] row) {
        collapseZeros(row);
        for (int i = 0; i < row.length - 1; ++i) {
            if (row[i] == row[i+1]) {
                row[i] *= 2;
                row[i+1] = 0;
                collapseZeros(row);
            }
        }
    }

    public static void collapseZeros(int[] row) {
        boolean updated = true;
        while (updated) {
            updated = false;
            for (int i = 0; i < row.length - 1; ++i) {
                if (row[i] == 0) {
                    for (int j = i; j < row.length - 1; ++j) {
                        if (row[j+1] > 0) {
                            updated = true;
                            row[j] = row[j+1];
                            row[j+1] = 0;
                        }
                    }
                    row[row.length - 1] = 0;
                }
            }
        }
    }

    public static void rotateClockwise(int[][] board) {
        int[][] newBoard = new int[board.length][board[0].length];

        for (int i = 0; i < board.length; ++i) {
            for (int j = 0; j < board[0].length; ++j) {
                newBoard[i][j] = board[board.length - j - 1][i];
            }
        }

        // Copy newBoard into board. Can't just set equal, Java passes arrays weird.
        for (int i = 0; i < board.length; ++i) {
            for (int j = 0; j < board[0].length; ++j) {
                board[i][j] = newBoard[i][j];
            }
        }
    }


}
