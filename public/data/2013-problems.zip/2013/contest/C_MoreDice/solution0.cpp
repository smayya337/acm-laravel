// Bloomfield's dice solution, 3-11-13
#include <iostream>
#include <string>
using namespace std;
//hardcode answers
string solutions[] = {
  "", // 0
  "", // 1
  "(1,1)", // 2
  "(1,2)", // 3
  "(1,3)\n(2,2)", // 4
  "(1,4)\n(2,3)", // 5
  "(1,5)\n(2,4)\n(3,3)", // 6
  "(1,6)\n(2,5)\n(3,4)", // 7
  "(2,6)\n(3,5)\n(4,4)", // 8
  "(3,6)\n(4,5)", // 9
  "(4,6)\n(5,5)", // 10
  "(5,6)", // 11
  "(6,6)" // 12
};
int main() {
  int n, x;
  cin >> n;
  //iterate over cases
  for ( int i = 1; i <= n; i++ ) {
    cin >> x;
    //output presolved answers
    cout << "Case " << i << ":\n" << solutions[x] << endl;
  }
}

    
