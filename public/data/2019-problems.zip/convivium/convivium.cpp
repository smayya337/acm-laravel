#include <iostream>
#include <map>
#include <vector>
#include <string>

bool bpm(bool** bpGraph, int from, bool* seen, int* matchR, int len) {
    for (int to = 0; to < len; to++) {
        if (bpGraph[from][to] && !seen[to]) {
            seen[to] = true;
            if (matchR[to] < 0 || bpm(bpGraph, matchR[to], seen, matchR, len)) {
                matchR[to] = from;
                return true;
            }
        }
    }
    return false;
}
int maxBPM(bool** bpGraph, size_t len, int count) {
    int* matchR = new int[len];
    memset(matchR, -1, len);
    int result = 0;
    for (int from = 0; from < count; from++) {
        bool* seen = new bool[len];
        memset(seen, 0, len);
        if (bpm(bpGraph, from, seen, matchR, len)) result++;
    }
    return result;
}
int main(int argc, char** argv) {
    int cases;
    std::cin >> cases;
    for(int caseno = 0; caseno < cases; caseno++) {
        int people;
        std::cin >> people;
        std::map<std::string, std::vector<std::string>> adjList = {};
        std::map<std::string, int> team1 = {};
        std::map<std::string, int> team2 = {};
        size_t distinct1 = 0;
        size_t distinct2 = 0;
        for (int i = 0; i < people; i++) {
            std::string name;
            std::cin >> name;
            if (team1.find(name) == team1.end())
                team1.emplace(name, distinct1++);
            adjList.emplace(name, std::vector<std::string>{});
            int num;
            std::cin >> num;
            for (int j = 0; j < num; j++) {
                std::string p2;
                std::cin >> p2;
                if (team2.find(p2) == team2.end())
                    team2.emplace(p2, distinct2++);
                adjList.at(name).emplace_back(p2);
            }
            std::cout << name << std::endl;
        }
        bool** adjMat = new bool*[distinct1];
        for(unsigned i = 0; i < distinct1; i++){
            adjMat[i] = new bool[distinct1];
            memset(adjMat[i], 0, distinct1);
        }
        for (auto s : adjList) {
            for (const auto& s2 : s.second) {
                adjMat[team1[s.first]][team2[s2]] = true;
            }
        }
        int matching = maxBPM(adjMat, distinct1, distinct1);
        std::cout << matching << std::endl;
    }
}
