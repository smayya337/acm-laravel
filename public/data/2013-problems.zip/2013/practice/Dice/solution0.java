package dice;

import java.util.Scanner;

public class EasyDice {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int d1, d2;
		int times = in.nextInt();
		for (int i = 0; i < times; i++ )
		{
			d1 = in.nextInt();
			d2 = in.nextInt();
			System.out.println("Case " + (i+1) + ": " + (d1+d2));
		}

	}
}
