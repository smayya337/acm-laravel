/*
 * C++ solution to toystory
 *
 * by Aaron Bloomfield, 2018
 */

#include <iostream>
#include <string>
using namespace std;

int main() {
  int n, x;
  string s, t;
  cin >> n;
  for ( int i = 0; i < n; i++ ) {
    cin >> s >> t >> x;
    cout << s << " " << t << " " << (x+1) << endl;
  }
  return 0;
}
