import java.util.*;
public class PassVal
{
	public static void main(String[] args)
	{
		new PassVal();
	}
	public PassVal()
	{
		Scanner in = new Scanner(System.in);
		int N = in.nextInt();
		for(int n = 0; n < N; n++)
		{
			String pass = in.next();
			if(legit(pass))
				System.out.println("Valid Password");
			else
				System.out.println("Invalid Password");
		}
	}
	public boolean legit(String test)
	{
		char[] chtest = test.toCharArray();
		char[] lower = removeNonAndCase(chtest);
		if(chtest.length > 20 || chtest.length < 9)
			return false;
		if(!twoLower(chtest))
			return false;
		if(!twoCapital(chtest))
			return false;	
		if(!oneNum(chtest))
			return false;	
		if(!twoNon(chtest))
			return false;
		if(threeConsec(chtest))
			return false;
		if(isPalindrome(lower))
			return false;
		if(containsSequences(lower))
			return false;
		return true;
	}
	public boolean containsSequences(char[] lower)
	{
		String[] seqs = {"password","virginia","cavalier","code","drowssap","ainigriv","reilavac","edoc"};
		for(int i = 0; i < seqs.length; i++)
			if(containsSequence(lower,seqs[i]))
				return true;
		return false;
	}
	public char[] removeNonAndCase(char[] chtest)
	{
		int counter = 0;
		for(int i = 0; i < chtest.length; i++)
			if(isNonAlphaNum(chtest[i]))
				counter++;
		char[] pal = new char[chtest.length - counter];
		counter = 0;
		for(int i = 0; i < chtest.length; i++)
		{
			if(isNonAlphaNum(chtest[i]))
				counter++;
			else
				pal[i-counter] = chtest[i];
		}
		String non = new String(pal);
		non = non.toLowerCase();
		return non.toCharArray();
	}
	public boolean containsSequence(char[] chtest, String seqstr)
	{
		char[] seq = seqstr.toCharArray();
		int index = 0;
		for(int i = 0; i < chtest.length; i++)
		{
			if(chtest[i] == seq[index])
				index++;
			if(index == seq.length)
				return true;
		}
		return false;
	}
	
	public boolean isPalindrome(char[] chtest)
	{
		for(int i = 0; i < chtest.length/2; i++)
		{
			if(chtest[i] != chtest[chtest.length - i - 1])
				return false;
		}
		return true;
	}
	public boolean threeConsec(char[] chtest)
	{
		int counter = 1;
		char prev = chtest[0];
		for(int i = 1; i < chtest.length; i++)
		{
			if(prev == chtest[i])
				counter++;
			else
			{	
				prev = chtest[i];
				counter = 1;
			}
			if(counter > 2)
				return true;
		}
		return false;
	}
	public boolean twoNon(char[] chtest)
	{
		int counter = 0;
		for(int i = 0; i < chtest.length; i++)
		{
			if(isNonAlphaNum(chtest[i]))
				counter++;
			if(counter > 1)
				return true;
		}
		return false;
	}
	public boolean oneNum(char[] chtest)
	{
		for(int i = 0; i < chtest.length; i++)
			if(isNumber(chtest[i]))
				return true;
		return false;
	}
	public boolean twoCapital(char[] chtest)
	{
		int counter = 0;
		for(int i = 0; i < chtest.length; i++)
		{
			if(isUpperCase(chtest[i]))
				counter++;
			if(counter > 1)
				return true;
		}
		return false;
	}
	public boolean twoLower(char[] chtest)
	{
		int counter = 0;
		for(int i = 0; i < chtest.length; i++)
		{
			if(isLowerCase(chtest[i]))
				counter++;
			if(counter > 1)
				return true;
		}
		return false;
	}
	public boolean isNonAlphaNum(char ch)
	{
		if(!isLetter(ch) && !isNumber(ch))
			return true;
		return false;
	}
	public boolean isNumber(char ch)
	{
		if(ch == '0' || ch == '1' ||
		ch == '2' || ch == '3' ||
		ch == '4' || ch == '5' ||
		ch == '6' || ch == '7' ||
		ch == '8' || ch == '9')
			return true;
		return false;
	}
	public boolean isLetter(char ch)
	{
		if(isLowerCase(ch) || isUpperCase(ch))
			return true;
		return false;
	}
	public boolean isLowerCase(char ch)
	{
		if(ch == 'a' || ch == 'b' ||
		ch == 'c' || ch == 'd' ||
		ch == 'e' || ch == 'f' ||
		ch == 'g' || ch == 'h' ||
		ch == 'i' || ch == 'j' ||
		ch == 'k' || ch == 'l' ||
		ch == 'm' || ch == 'n' ||
		ch == 'o' || ch == 'p' ||
		ch == 'q' || ch == 'r' ||
		ch == 's' || ch == 't' ||
		ch == 'u' || ch == 'v' ||
		ch == 'w' || ch == 'x' ||
		ch == 'y' || ch == 'z')
			return true;
		return false;
	}
	public boolean isUpperCase(char ch)
	{
		if(ch == 'A' || ch == 'B' ||
		ch == 'C' || ch == 'D' ||
		ch == 'E' || ch == 'F' ||
		ch == 'G' || ch == 'H' ||
		ch == 'I' || ch == 'J' ||
		ch == 'K' || ch == 'L' ||
		ch == 'M' || ch == 'N' ||
		ch == 'O' || ch == 'P' ||
		ch == 'Q' || ch == 'R' ||
		ch == 'S' || ch == 'T' ||
		ch == 'U' || ch == 'V' ||
		ch == 'W' || ch == 'X' ||
		ch == 'Y' || ch == 'Z')
			return true;
		return false;
	}
}