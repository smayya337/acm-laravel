Output the number of silver $denarius$ Caesar can expect to pay the winner of the tournament. For example, if Caesar has a 50% chance of losing, output would be "500000".
