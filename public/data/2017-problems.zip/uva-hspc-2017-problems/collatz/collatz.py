# Solves "Collatz Chain Chomp" from the 2017 HSPC at UVa
# Solution by Andrew Norton, 2017

from sys import stdin

# "collatz" is a list where collatz[n] gives the next number
#   in the collatz sequence starting from n
# Note that this is 2**20 long, not 2**10.  This is because 
# Collatz chains can go up for a while before coming back down.
# I determined this number by guessing upper bounds until it worked
# for all starting n between 2 and 2**10
collatz = [ n//2 if n % 2 == 0 else 3*n+1 for n in range(2**20)]

# Prints the whole chain
def print_chain(n):
  while n != 1:
    n = collatz[n]
    print(n, end=' ')
  print()

if __name__ == '__main__':
  # Read in all the lines of input
  data = stdin.read().splitlines()
  data = data[1:] # Ignore the number of cases

  for row in data:
    print_chain(int(row))
