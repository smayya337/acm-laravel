#include <iostream>
#include <string>
#include <cstdlib>
#include <vector>
#include <algorithm>
using namespace std;
#define N 100
#define SEED 4
string types[] = { "Normal", "Fire", "Water", "Electric", "Grass", "Ice", "Fighting", "Poison", "Ground", "Flying", "Psychic", "Bug", "Rock", "Ghost", "Dragon", "Dark", "Steel", "Fairy" }; // size: 18
string pokemons[] = { "Abra", "Alakazam", "Arbok", "Arcanine", "Beedrill", "Bellsprout", "Blastoise", "Bulbasaur", "Butterfree", "Caterpie", "Charizard", "Charmander", "Charmeleon", "Clefable", "Clefairy", "Cloyster", "Dewgong", "Diglett", "Dodrio", "Doduo", "Drowzee", "Dugtrio", "Ekans", "Electrode", "Farfetchd", "Fearow", "Gastly", "Gengar", "Geodude", "Gloom", "Golbat", "Golduck", "Golem", "Graveler", "Grimer", "Growlithe", "Haunter", "Hypno", "Ivysaur", "Jigglypuff", "Kadabra", "Kakuna", "Kingler", "Krabby", "Machamp", "Machoke", "Machop", "Magnemite", "Magneton", "Mankey", "Meowth", "Metapod", "Muk", "Nidoking", "Nidoqueen", "Nidoran♀", "Nidorina", "Nidorino", "Ninetales", "Oddish", "Onix", "Paras", "Parasect", "Persian", "Pidgeot", "Pidgeotto", "Pidgey", "Pikachu", "Poliwag", "Poliwhirl", "Poliwrath", "Ponyta", "Primeape", "Psyduck", "Raichu", "Rapidash", "Raticate", "Rattata", "Sandshrew", "Sandslash", "Seel", "Shellder", "Slowbro", "Slowpoke", "Spearow", "Squirtle", "Tentacool", "Tentacruel", "Venomoth", "Venonat", "Venusaur", "Victreebel", "Vileplume", "Voltorb", "Vulpix", "Wartortle", "Weedle", "Weepinbell", "Wigglytuff", "Zubat" }; // size: 100

int main() {
  cout << N << endl;
  vector<string> vp;
  for ( unsigned int i = 0; i < 100; i++ )
    vp.push_back(pokemons[i]);
  // special cases (5)
  cout << "5\nPikachu Electric\nMagikarp Water\nJolteon Electric\nVaporeon Water\nElectabuz Electric\n";
  cout << "8\nCress Water\nValerie Fairy\nWallace Water\nBlaine Fire\nRoxanne Rock\nBrock Rock\nMalva Fire\nGlacia Ice\n";
  cout << "1\nPikachu Electric\n";
  cout << "2\nPikachu Electric\nMagikarp Electric\n";
  cout << "2\nPikachu Electric\nPikachu Water\n";
  // random cases
  srand(SEED);
  for ( unsigned int i = 5; i < N; i++ ) {
    unsigned int size = rand() % 100 + 1;
    if ( i > N-3 )
      size = 100;
    cout << size << endl;
    random_shuffle(vp.begin(),vp.end());
    for ( unsigned int j = 0; j < size; j++ ) {
      unsigned int which = rand() % 18;
      cout << vp[j] << " " << types[which] << endl;
    }
  }
  return 0;
}
