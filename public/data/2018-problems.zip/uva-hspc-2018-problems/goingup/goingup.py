# Solution to "Cost of Going Up" from the 2018 HSPC
# Solution by Alyson Irizarry, 2018

from sys import stdin


if __name__ == '__main__':
	input = stdin.read().splitlines()
	for row  in input[1:]: # iterate over all lines except the first
		row_split = [int(n) for n in row.split(" ")]
		balloons_needed = row_split[0]
		ballons_per_pack = row_split[1]
		packs_needed = (balloons_needed // ballons_per_pack) 
		
		if ( balloons_needed % ballons_per_pack != 0): # account for "left over" balloons
			packs_needed += 1

		print(packs_needed)
		
