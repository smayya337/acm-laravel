import java.util.Scanner;

public class publicans{
      public static void main(String[] args) throws Exception{
        publicanSolve();
    }
    
    public static void publicanSolve() throws  Exception{
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        for (int i = 0; i < n; i++) {
            int p = scan.nextInt();
            double expected = 0;
            for (int j = 0; j < p; j++) {
                expected += scan.nextDouble()/2.0;
            }
            if(p < 100) expected *= Math.pow(2, p)/(Math.pow(2, p) - 1);
            System.out.printf("%.3f\n", expected);
        }
    }
}
