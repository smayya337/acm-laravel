import java.io.*;
import java.util.*;

//Author: Daniel Epstein
public class solution1 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int numCases = in.nextInt();
		for(int aaa=1;aaa<=numCases;aaa++) {
			int H = in.nextInt();
			int W = in.nextInt();
			int N = in.nextInt();
			Circle[] circles = new Circle[N];
			for(int i=0;i<N;i++) {
				circles[i] = new Circle(in.nextDouble(), in.nextDouble(), in.nextDouble());
			}
			
			LinkedList<Circle> q = new LinkedList<Circle>();
			for(Circle c : circles) {
				if(c.y+c.r >= H) {
					c.visited = true;
					q.add(c);
				}
			}
			
			boolean found = true;
			while(q.size() > 0) {
				Circle c = q.removeFirst();
				if(c.y - c.r <= 0) {
					found = false;
					break;
				}
				//could have made this a graph but this is less efficient and therefore better
				for(Circle d : circles) {
					if(!d.visited && c.intersects(d)) {
						d.visited = true;
						q.add(d);
					}
				}
			}
			System.out.println("Case " + aaa + ": " + (found?"Clear To Go":"Find Another Path"));
		}
	}
}

class Circle {
	public double x;
	public double y;
	public double r;
	public boolean visited = false;
	public Circle(double x, double y, double r) {
		this.x = x;
		this.y = y;
		this.r = r;
	}
	
	public boolean intersects(Circle other) {
		double dX = x - other.x;
		double dY = y - other.y;
		double distSq = dX*dX + dY*dY;
		double rSq = (r+other.r)*(r+other.r);
		return rSq >= distSq;
	}
}