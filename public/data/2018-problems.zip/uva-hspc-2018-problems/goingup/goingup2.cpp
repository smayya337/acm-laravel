// Solves "Cost of Going UP" from the 2018 HSPC at UVa
// Solution by Alyson Irizarry, 2018

#include <iostream>
using namespace std;

int main() {
  unsigned int n, balloons_needed, balloons_per_pack, packs_needed;
  cin >> n;
  for ( int i = 0; i < n; i++ ) {
    cin >> balloons_needed >> balloons_per_pack;
    packs_needed = balloons_needed / balloons_per_pack;
    
    if (balloons_needed % balloons_per_pack) { 
    	packs_needed++;
		}

    cout << packs_needed << endl;
  }
  return 0;
}
