#include <iostream>
#include <string>
#include <cstdlib>
using namespace std;
#define N 100
#define SEED 4
string powerups[] = { "shell", "star", "mushroom", "banana", "bomb", "pow", "heart", "moon", "clock", "fruit" };
int main() {
  cout << N << endl;
  // special cases (4)
  cout << "1 shell\n";
  cout << "1 mushroom\n";
  cout << "5 shell star mushroom shell shell\n";
  cout << "8 banana bomb bomb thunderbolt banana shell mushroom pow\n";
  // random cases
  srand(SEED);
  for ( unsigned int i = 4; i < N; i++ ) {
    unsigned int size = rand() % 100 + 1;
    if ( i > N-3 )
      size = 1000;
    cout << size;
    for ( unsigned int j = 0; j < size; j++ )
      cout << " " << powerups[rand()%10];
    cout << endl;
  }
  return 0;
}
