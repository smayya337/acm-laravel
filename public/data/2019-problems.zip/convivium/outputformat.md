Output the maximum number of distinct targets Caesar's team can hit with their initial food barrage.
