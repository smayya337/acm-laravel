// Solves "Coins" from the 2017 HSPC at UVa
// Solution by Aaron Bloomfield, 2017

#include <iostream>
using namespace std;
int main() {
  unsigned int n, b, m, r;
  cin >> n;
  for ( int i = 0; i < n; i++ ) {
    cin >> b >> m >> r;
    cout << (b*13+m*5+r*462) << endl;
  }
  return 0;
}
