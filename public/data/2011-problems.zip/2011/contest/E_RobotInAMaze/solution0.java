import java.util.*;
public class Maze
{
	public static void main(String[] args)
	{
		new Maze();
	}
	public Maze()
	{
		Scanner in = new Scanner(System.in);
		int N = in.nextInt();
		for(int l = 0; l < N; l++)
		{
			int rows = in.nextInt();
			int columns = in.nextInt();
			int x = 0;
			int y = 0;
			ArrayList<Integer> gx = new ArrayList<Integer>();
			ArrayList<Integer> gy = new ArrayList<Integer>();
			char[][] maze = new char[rows][columns];
			boolean[][] visited = new boolean[rows][columns];
		
			for(int i = 0; i < rows; i++)
			{
				String n = in.next();
				char[] chars = n.toCharArray();
				for(int j = 0; j < columns; j++)
				{
					maze[i][j] = chars[j];
					if(chars[j] == 'G')
					{
						gx.add(j);
						gy.add(i);
					}
					if(chars[j] == 'S')
					{
						x = j;
						y = i;
					}
					visited[i][j] = false;
				}
			}
		
			boolean goal = false;
			PriorityQueue<Node> heap = new PriorityQueue();
			
			addNode(x,y,0,heap,gx,gy,visited);
			
			int path = 0;
			while(!goal && heap.size() > 0)
			{
				Node n = heap.poll();
				
				x = n.x;
				y = n.y;
				visited[y][x] = true;
				//System.out.println("x:" + x + "  y:" + y);
				for(int i = -1; i < 2; i++)
					for(int j = -1; j < 2; j++)
						if((j == 0 || i == 0) &&(i+y) >= 0 && (i+y) < rows && (j+x) >= 0 && (j+x) < columns
						&& maze[y+i][x+j] != 'X' && maze[y+i][x+j] != 'G')
							addNode(j+x,i+y,n.path + 1,heap,gx,gy,visited);
						else if((j == 0 || i == 0) && maze[y+i][x+j] == 'G')
						{
							goal = true;
							path = n.path + 1;
						}
			}
			if(goal)
				System.out.println("Shortest Path: " + path);
			else
				System.out.println("No Exit");
		}
	}

	public void addNode(int x, int y, int path, PriorityQueue<Node> heap, ArrayList<Integer> gx, ArrayList<Integer> gy, boolean[][] visited)
	{
		Node n = new Node(x,y,path + est(x,y,gx,gy),path);
		Node k = null;
		if(heap.contains(n) || visited[y][x] == true)
		{
			//k = heap.remove(n);
		//	if(k.path > n.path)
			//	heap.add(n);
			//else
			//	heap.add(k);
		//	heap.remove(n);
		//	heap.add(n);
		}
		else
			heap.add(n);
	}

	public int est(int x, int  y, ArrayList<Integer> gx, ArrayList<Integer> gy)
	{
		ArrayList<Integer> tests = new ArrayList<Integer>();
		for(int i = 0; i < gx.size(); i++)
		{
			tests.add(Math.abs(gx.get(i) - x) + Math.abs(gy.get(i) - y));
		}

		return Collections.min(tests);
	}
	private class Node implements Comparable
	{
		int x;
		int y;
		int total;
		int path;
		public Node(int x, int y, int total, int path)
		{	
			this.x = x;
			this.y = y;
			this.total = total;
			this.path = path;
		}
		public int compareTo(Object obj)
		{
			Node k = (Node)obj;
			if(k.total > total)
				return -1;
			if(k.total < total)
				return 1;
			return 0;
		}
		public boolean equals(Object obj)
		{
			Node k = (Node)obj;
			if(k.x == x && k.y == y)
				return true;
			return false;
		}
	}
	
}
