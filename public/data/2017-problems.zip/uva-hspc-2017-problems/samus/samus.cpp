// Solves "Samsu Charge" from the 2017 HSPC at UVa
// Solution by Aaron Bloomfield, 2017

#include <iostream>
#include <vector>
#include <map>
#include <sstream>
using namespace std;

vector<unsigned int> c, z;
map<string,unsigned int> memo;

unsigned int recurse(unsigned int pos, unsigned int curc) {
  stringstream key;
  curc += c[pos];
  if ( pos == c.size()-1 )
    return min(curc,z[pos]);
  key.str("");
  key << pos << "-" << curc;
  if ( memo.find(key.str()) != memo.end() )
    return memo[key.str()];
  // to remove memoization, return the max() value on the next line instead of saving it
  memo[key.str()] = max(min(curc,z[pos])+recurse(pos+1,0), // shoot!
			recurse(pos+1,curc)                // wait!
			);
  return memo[key.str()];
}

int main() {
  unsigned int n, s;
  int x;
  cin >> n;
  for ( unsigned int i = 0; i < n; i++ ) {
    c.clear();
    z.clear();
    memo.clear();
    cin >> s;
    for ( unsigned int j = 0; j < s; j++ ) {
      cin >> x;
      z.push_back(x);
    }
    for ( unsigned int j = 0; j < s; j++ ) {
      cin >> x;
      c.push_back(x);
    }
    cout << recurse(0,0) << endl;
  }
  return 0;
}
