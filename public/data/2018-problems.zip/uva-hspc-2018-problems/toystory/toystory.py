import sys

n = int(sys.stdin.readline())
for i in range(n):
  name = sys.stdin.readline().strip().split()
  print(name[0] + " " + name[1] + " " + str(int(name[2])+1))
