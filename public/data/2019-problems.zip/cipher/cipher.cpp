#include<iostream>
#include<string>

char shift(char c, int i) {
  if (c == ' ')
    return c;

  // Else it's lowercase and actually gets shifted
  return (c - 'a' + i) % 26 + 'a';
}

int main() {
  int numCases;
  
  std::cin >> numCases;

  for (int i = 0; i < numCases; i++) {
    int shiftVal;
    std::cin >> shiftVal;

    std::string toDecode;
    getline(std::cin, toDecode); // get rid of trailing line break
    getline(std::cin, toDecode); // actually read in the line


    for (int i = 0; i < toDecode.size(); i++) {
      std::cout << shift(toDecode.at(i), shiftVal);  
    }
    std::cout << std::endl;
    
    
  }
  return 0;
}
