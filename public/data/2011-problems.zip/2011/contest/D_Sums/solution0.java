import java.util.*;
import java.text.*;

public class ArithGeo {
	public static boolean equals(double a, double  b) {
		return (Math.abs(a - b) < 0.00000001);
	}

	public static void main(String[] args) {
		Scanner fin = new Scanner(System.in);
		
		NumberFormat fmt = NumberFormat.getInstance();
		fmt.setMinimumFractionDigits(0);
		fmt.setMaximumFractionDigits(0);
		fmt.setGroupingUsed(false);

		while (true) {
			int n = fin.nextInt();
			if (n == 0) break;
			double a1 = fin.nextDouble();
			double a2 = fin.nextDouble();
			double a3 = fin.nextDouble();

			double r = a2 / a1;
			double d = a2 - a1;

			if (equals(a3, a2+d)) {
				double calcAn = n * (2*a1 + (n - 1)*d) / 2;
				int calcAnInt = (int) Math.round(calcAn);
				//System.out.println("Arithmetic Sum: " + fmt.format(calcAn));
				System.out.println(calcAnInt);
			} else {
				double calcAn = a1 * (Math.pow(r, n) - 1.0) / (r - 1.0);
				int calcAnInt = (int) Math.round(calcAn);
				//System.out.println("Geometric Sum: " + fmt.format(calcAn));
				System.out.println(calcAnInt);
			}
		}
	}
}
