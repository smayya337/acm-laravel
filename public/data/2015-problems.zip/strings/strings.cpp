//Problem 1 - String reversal
//Jay Sebastian (jgs3cd)

//i/o through cin and cout
#include <iostream>
//for strcpy function
#include <cstring>

//in the problem spec we'll give a max possible string length
//put this length + 1 (to include terminating character) here
char buffer[1024];

void reverse(int start, int end) {
    if (end <= start)
        return;

    //indices to keep track of quotation marks
    //q1 matches to q4; q2 to q3
    int q1 = -1;
    int q2 = -1;
    int q3 = -1;
    int q4 = -1;

    int i = start;
    int j = end;
    //make one pass to place the quotation indices
    while (i <= end && buffer[i] != '"')
        i++;
    while (j >= start && buffer[j] != '"')
        j--;
    if (i < j) {
        q1 = i;
        q4 = j;

        i = i+1;
        j = j-1;
        while (i <= end && buffer[i] != '"')
            i++;
        while (j >= start && buffer[j] != '"')
            j--;

        if (i < j) {
            q2 = i;
            q3 = j;
        }

    }
    //std::cout << q1 << " " << q2 << " " << q3 << " " << q4 << "\n";

    //make recursive call if necessary
    if (q2 != -1 && q3 != -1) {
        reverse(q2+1, q3-1);
    }

    //make second pass to reverse the characters
    i = start;
    j = end;
    while (i < j) {
        if (i == q1)
            i = q4 + 1;
        if (j == q4)
            j = q1 - 1;
        if (j <= i)
            break;

        char temp = buffer[i];
        buffer[i] = buffer[j];
        buffer[j] = temp;

        i++;
        j--;
    }
}

int main(int argc, char** argv) {
    int n;
    std::string input;
    std::cin >> n;

    for ( int i = 0; i < n; i++ ) {
        std::cin >> input;
        strcpy(buffer, input.c_str());
        buffer[input.length()] = 0; //terminating character
        reverse(0, input.length() - 1);
        std::cout << buffer << std::endl;
    }

    return 0;
}
