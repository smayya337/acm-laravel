/**
 * input generator for keysort
 *
 * This must be compiled with -std=c++11
 *
 * run with a random seed (via command-line parameter) of 4 to
 * generate the weighted.judge.in file.
 *
 * Written by Aaron Bloomfield, 2018
 */

#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

using namespace std;

// names from https://www.fantasynamegen.com/mixed/short/
string namesx[] = {"Achaklotl", "Alchoy", "Alham", "Am", "Amkruul",
"Amo", "Ana", "Babard", "Bhaiquet", "Biaa", "Biysha", "Buhol",
"Chetli", "Chitlron", "Connha", "Cthohaiss", "Cuafred", "Cuix",
"Da-zurg", "Dinozug", "Doccf'a", "Favallsthenn", "Ferumia",
"Frithtsylh", "Fronsmo", "Gan-hi", "Gotsylh", "Grentin", "Grornna",
"Gruk", "Gueman", "Haagtros", "Hasissh", "Hrunza", "Hunna", "In'o",
"Itsmi", "Izel", "Jamas", "Jire", "Kahudthish", "Kriwyrm", "Krudemi",
"Lalo", "Lanskittar", "Lasbe", "Lia", "Lira", "Lowa", "Lymay", "Mad",
"Mahasne", "Mahlith", "Mahun", "Maiss", "Malorcol", "Mandrarg",
"Mello", "Mopri", "Musba", "Nazgbrass", "Nemar", "Nerax", "Nexpe",
"Onain", "Pas", "Phortsy", "Pintha", "Rakgaz", "Rasyth", "Rounbe",
"Rulus", "Saisslasths", "San", "Sanly", "Satha", "Scoxtsi",
"Sersthly", "Sitong", "Siyssshand", "Sonli", "Sthina", "Tethly",
"Tey", "Tha", "Thantsi", "Thegrim", "Thlyissa", "Thorla",
"Thyldocfrey", "Thysil", "Thyya", "Tlallotl", "Tsthihsiit", "Tsutar",
"Vallsi", "Viadruk", "Waruve", "Yail", "Zargma"};
int names_size = 100; 

int numfixedcases = 5;
const char* fixedcases = R"(3
3 Most_Difficult
1 Least_Difficult
2 Moderately_Difficult
8
721 Sophia's_Room
45 Olivia's_Room
554 Emma's_Room
684 Jackson's_Room
461 Aiden's_Room
1000 Liam's_Room
1 Ava's_Room
293 Noah's_Room
1
1 Number_One
1
50 Number_Fifty
1
100 Number_One_hundred
)";


int main(int argc, char *argv[]) {

  // handle random seed
  int seed = time(NULL);
  if ( argc == 2 )
    sscanf(argv[1],"%d",&seed);
  srand(seed);

  // put the difficulties and door names into a vector for easy
  // shuffling
  vector<string> names;
  vector<int> diffs;
  for ( int i = 0; i < names_size; i++ )
    names.push_back(namesx[i]);
  for ( int i = 0; i < 1000; i++ )
    diffs.push_back(i+1);
  
  // output fixed testcases
  cout << (200+numfixedcases) << "\n" << fixedcases;

  // random test cases:
  for ( int i = 0; i < 200; i++ ) {
    int w = rand() % 90 + 3;
    if ( i == 0 )
      w = 100;
    random_shuffle(names.begin(),names.end());
    random_shuffle(diffs.begin(),diffs.end());
    cout << w << endl;
    for ( int j = 0; j < w; j++ )
      cout << diffs[j] << " " << names[j] << endl;
  }
  return 0;
}

