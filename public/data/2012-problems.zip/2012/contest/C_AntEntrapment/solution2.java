import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Scanner;

/**
 *
 * @author Peter Chapman
 */
public class solution2 {

    public static void main(String[] args) {
        new solution2();
    }
    NumberFormat df = null;
    public solution2(){
        Scanner in = new Scanner(System.in);
        int cases = in.nextInt();
        df = DecimalFormat.getInstance();
        df.setMaximumFractionDigits(10);
        df.setGroupingUsed(false);
        
        for(int i = 1; i <= cases;i++)
            solveCase(i,in);
    }
    
    public void solveCase(int caseNumber,Scanner in){
        int ants = in.nextInt();
        double[][] antPositions = new double[ants][2];
        for(int ant = 0; ant < ants;ant++)
        {
            antPositions[ant][0] = in.nextDouble();
            antPositions[ant][1] = in.nextDouble();
        }
        double lowestX = min(antPositions,0);
        double lowestY = min(antPositions,1);
        double highestX = max(antPositions,0);
        double highestY = max(antPositions,1);
        
        double area = calcArea(lowestX,lowestY,highestX,highestY);
        double perimeter = calcPerimeter(lowestX,lowestY,highestX,highestY);
        
        System.out.println("Case " + caseNumber + ": Area " + area + ", Perimeter " + perimeter);
    }
    
    public double calcArea(double lowestX,double lowestY,double highestX,double highestY){
        return (highestX - lowestX) * (highestY - lowestY);
    }
    
    
    private double calcPerimeter(double lowestX, double lowestY, double highestX, double highestY) {
        return 2*(highestX - lowestX) + 2*(highestY-lowestY);
    }
    
    public double min(double[][] antPositions,int index){
        double min = Double.MAX_VALUE;
        for(double[] d : antPositions)
            min = Math.min(d[index],min);
        
        return min;
    }
    
    public double max(double[][] antPositions,int index){
        double max = -Double.MAX_VALUE;
        for(double[] d : antPositions)
            max = Math.max(d[index],max);
        
        return max;
    }

    
}
