import java.util.Scanner;

public class MoreDice2 {

    public static void main (String[] args) 
    {
        Scanner s = new Scanner(System.in);
        
        int n = s.nextInt();
	//iterate over cases        
        for (int i = 0; i < n; i++)
        {
            System.out.println("Case " + (i + 1) + ":");
            int sum = s.nextInt();

	    //output hardcoded values
            if (sum == 2)
            {
                System.out.println("(1,1)");
            }
            else if (sum == 3)
            {
                System.out.println("(1,2)");
            }
            else if (sum == 4)
            {
                System.out.println("(1,3)");
                System.out.println("(2,2)");
            }
            else if (sum == 5)
            {
                System.out.println("(1,4)");
                System.out.println("(2,3)");
            }
            else if (sum == 6)
            {
                System.out.println("(1,5)");
                System.out.println("(2,4)");
                System.out.println("(3,3)");
            }
            else if (sum == 7)
            {
                System.out.println("(1,6)");
                System.out.println("(2,5)");
                System.out.println("(3,4)");
            }
            else if (sum == 8)
            {
                System.out.println("(2,6)");
                System.out.println("(3,5)");
                System.out.println("(4,4)");
            }
            else if (sum == 9)
            {
                System.out.println("(3,6)");
                System.out.println("(4,5)");
            }
            else if (sum == 10)
            {
                System.out.println("(4,6)");
                System.out.println("(5,5)");
            }
            else if (sum == 11)
            {
                System.out.println("(5,6)");
            }
            else if (sum == 12)
            {
                System.out.println("(6,6)");
            }
        }
    }
}

