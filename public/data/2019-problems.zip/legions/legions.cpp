#include <iostream>
#include <stdio.h>

using namespace std;

int main(){
 int cases;
 cin >> cases;
 for(int i = 0; i < cases; i++){
   int legions;
   cin >> legions;
   printf("%d\n", legions * 1500);
 }
}
