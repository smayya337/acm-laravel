import sys
import codecs # Yup. For some reason this has ROT13 in it.

nCases = int(sys.stdin.readline())

for i in range(nCases):
  s = sys.stdin.readline().strip()
  print(codecs.encode(s, 'rot13'))
