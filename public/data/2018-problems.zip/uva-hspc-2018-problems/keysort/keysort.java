// Solution to "Sorting for Monsters, Inc." from the 2018 HSPC
// Solution by Alyson Irizarry, 2018

import java.util.*;

class keysort {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int nCases = input.nextInt();
        input.nextLine();       
        TreeMap<Integer,String> map = new TreeMap<Integer,String>();  
        
        //iterate over each case
        for (int i = 1; i <= nCases; i++) {
            int nDoors = input.nextInt();
            input.nextLine();   
            for (int j = 0; j  < nDoors; j++) {
                String[] line = input.nextLine().trim().split(" ");
                map.put(Integer.parseInt(line[0]), line[1]);
            }
            System.out.println("Case " + i + ":");
            for (Map.Entry<Integer,String> entry: map.entrySet()){
                System.out.println(entry.getValue());
            } 
            map.clear();
        }
    }
}
