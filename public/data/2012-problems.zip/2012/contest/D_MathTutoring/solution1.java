import java.util.Scanner;


public class solution1 {
	public static void main(String[] args) {
		Scanner fin = new Scanner(System.in);
		
		int numCases = fin.nextInt();
		for(int aaa=1;aaa<=numCases;aaa++) {
			int n = fin.nextInt();
			
			System.out.print("Case " + aaa + ": ");
			
			int[] ara = new int[n+1];
			for (int i = n; i >= 0; i--) ara[i] = fin.nextInt()*i;
			
			int max = 0;
			
			for (int i = 0; i < n+1; i++) if (ara[i] != 0) max = i-1;
			
			System.out.print(max);
			
			for (int i = max+1; i > 0; i--) {
				System.out.print(" " + ara[i]);
			}
			
			System.out.println();
		}
	}
}
