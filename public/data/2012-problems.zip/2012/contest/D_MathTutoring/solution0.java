/**
*Calculus Tutoring
*Chris Cunningham (clc3bn)
*/

import java.util.*;

public class solution3
{
	public static void main(String[] args)
	{
		new solution3();
	}
	
	public solution3()
	{
		Scanner in = new Scanner(System.in);
		int testcases = in.nextInt();
		for (int j = 1; j <= testcases; j++)
		{
			int n = in.nextInt();
			int[] c = new int[n+1];
			
			for(int i = 0; i < c.length; i++)
				c[i] = in.nextInt();
			String s = (n-1)+"";
			for(int i = 0; i < c.length -1; i++)
				s = s + " " + (c[i]*(n-i));
			System.out.println("Case " + j + ": " + s);
		}
		
		
	}
}
