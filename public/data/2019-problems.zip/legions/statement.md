# Legion Roster

Emperor Aurelian has returned from yet another victory against the northern barbarians and wants to have a triumph, or victory parade, through the city. There are legions of soldiers coming from every province in the Empire to celebrate the victory. You are tasked with cooking for the entire army and therefore need to figure out how many soldiers there will be.


Given the number of legions taking part in the parade, how many soldiers will there be?