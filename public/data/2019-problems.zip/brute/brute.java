import java.util.Scanner;
public class brute{
    public static void main(String[] args) throws Exception{
        bruteSolve();
    }

    public static void bruteSolve() throws Exception{
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        for(int i = 0; i < n; i++){
            int r = scan.nextInt();
            int m = scan.nextInt();
            Room[] rooms = new Room[r];
            for (int j = 0; j < r; j++) {
                rooms[j] = new Room(scan.nextDouble(), scan.nextInt() - 1, scan.nextInt() - 1, scan.nextInt() - 1, scan.nextInt() - 1);
            }
            System.out.printf("%.8f", prob(rooms, m, 0, 0));
        }
    }
    public static double prob(Room[] rooms, int m, int cur, int i){
        if (cur >= m) return 1;
        double sum = 0;
        for (int j : rooms[i].connected) {
            sum += prob(rooms, m, cur + 1, j);
        }
        return rooms[i].prob * (sum / 4.0);
    }
    static class Room{
        public double prob;
        public int[] connected;
        public Room(double p, int... rooms){
            connected = rooms;
            prob = p;
        }
    }
}
