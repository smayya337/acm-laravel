The first line of the input will be a single integer, $n \leq 1,000$. There will be $n$ test cases that follow.


The first line of each test case will be the number of contestants, $c=2^m$, where $m \leq 16$. $c$ lines will follow, each with three floating-point values, $0 < r_i, p_i, s_i \leq 1$, $r_i + p_i + s_i = 1$ indicating the probabilities that contestant $i$ will pick rock, paper, or scissors in each match respectively. One more line will follow consisting of three floating-point values $0 \leq r_c, p_c, s_c \leq 1$, $r_c + p_c + s_c = 1$, indicating the probability Caesar will pick rock, paper, or scissors.
