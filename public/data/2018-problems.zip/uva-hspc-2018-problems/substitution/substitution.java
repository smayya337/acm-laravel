// Henry Conklin 2018
import java.util.Scanner;
import java.util.TreeMap;

public class substitution {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int ncases = in.nextInt();
        in.nextLine();
        for (int i = 0; i < ncases; i++) {
            String key = in.nextLine();
            String message = in.nextLine();

            // Build map from encoded characters back to plain text characters
            TreeMap<Character, Character> keyMap = new TreeMap<>();
            for (int j = 0; j < key.length(); j++) {
                keyMap.put(key.charAt(j), (char)('a' + j));
            }

            // Build up the decoded message
            StringBuilder out = new StringBuilder();
            for (int j = 0; j < message.length(); j++) {
                if (message.charAt(j) == ' ')
                    out.append(' ');
                else
                    out.append(keyMap.get(message.charAt(j)));
            }

            System.out.println(out.toString());
        }
    }
}
