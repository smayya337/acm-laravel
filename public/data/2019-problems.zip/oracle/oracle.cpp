#include <iostream>

int main(int argc, char** argv) {
    int cases;
    std::cin >> cases;
    for (int j = 0; j < cases; j++) {
        int readings[10];
        for (int i = 0; i < 10; i++) {
            std::cin >> readings[i];
        }
        int matching = 0;
        for (int i = 0; i < 10; i++) {
            int num;
            std::cin >> num;
            if (num == readings[i])
                matching++;
        }
        if (matching >= 8)
            std::cout << "Oracle" << std::endl;
        else if (matching >= 5)
            std::cout << "Draw" << std::endl;
        else std::cout << "Fraud" << std::endl;
    }
    return 0;
}
