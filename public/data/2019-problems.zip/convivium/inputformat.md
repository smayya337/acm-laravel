The first line of the input will be a single integer, $n \leq 1,000$. There will be $n$ test cases that follow.


The first line of each test case will consist of a single integer $0 < c \leq 5,000$, indicating the number of cuisine combatants on Caesar's team. $c$ lines will follow. Each line will have the food fighter's name, the number of targets they can hit, $0 \leq t \leq n$, and the names of their $t$ targets, each separated by a space. Members of Caesar's team may share names with members of the opposing team, but no two members of the same team will share a name.  All names will be alphanumeric and not have spaces.
