The first line of the input will be a single integer, $n \leq 1,000$. There will be $n$ test cases that follow.


The first line of each test case consists of two integers $0 < x, y \leq 100,000$, the number of sections in the aqueduct network. $x$ lines will follow, each with four integers $i$, $u$, $v$, and $l$ such that $0 \leq i, u, v \leq 100,000, v - u \leq l \leq 100,000$, indicating the ID, starting height, ending height, and length of each aqueduct section, respectively. $y$ more lines will follow, each with two integers $0 \leq h, k \leq 100,000$, indicating that the aqueduct sections with IDs $h$ and $k$ are connected.
