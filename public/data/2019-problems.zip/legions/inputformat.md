The first line of the input will be a single integer, $n \leq 1,000$. There will be $n$ test cases that follow.


Each test case starts with a single integer, $0 < x \leq 200$, the number of legions in the parade. Each legion consists of 1,500 soldiers.
