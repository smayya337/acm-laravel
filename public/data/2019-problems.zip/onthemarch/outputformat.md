Output "March onward!" if the legion can reach Antioch from Rome, "Stay home!" otherwise. Each output should be line separated.
