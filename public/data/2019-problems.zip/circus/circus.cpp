#include <iostream>
#include <map>
#include <vector>
#include <algorithm>

using namespace std;

int main(int argc, char** argv){
    int cases;
    cin >> cases;
    for(int caseno = 0; caseno < cases; caseno++){
        int people;
        cin >> people;
        vector<std::string> names = {};
        map<std::string, double> times = {};
        for(int i = 0; i < people; i++){
            std::string name;
            double time;
            cin >> name >> time;
            names.emplace_back(name);
            times.emplace(name, time);
        }
        std::sort(names.begin(), names.end(), [&times](std::string s1, std::string s2){ return times[s1] < times[s2]; });
        for(auto name : names){
            std::cout << name << std::endl;
        }
    }
}
