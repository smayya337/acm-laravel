import java.util.*;
public class Practice {
    public static void main (String [] args) {
        Scanner stdin = new Scanner(System.in);
        int n = stdin.nextInt();
        for ( int i = 0; i < n; i++ ) {
            int x = stdin.nextInt(), sum = 0;
            for ( int j = 1; j <= x; j++ )
                sum += j;
            System.out.println(sum);
        }
    }
}
