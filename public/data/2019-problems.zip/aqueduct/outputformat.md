For each test case, output the length of the longest path down the aqueduct network as a single integer. Each output should be separated by line.
