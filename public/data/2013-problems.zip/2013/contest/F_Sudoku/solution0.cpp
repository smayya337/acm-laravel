// Bloomfield's Sudoku solution, 3-11-13
#include <iostream>
#include <string>
using namespace std;
int main() {
  int n;

  //get number of cases and iterate over cases
  cin >> n;
  for ( int j = 1; j <= n; j++ ) {
    int board[9][9];
    bool invalid = false;
    // read in board
    for ( int r = 0; r < 9; r++ )
      for ( int c = 0; c < 9; c++ )
	cin >> board[r][c];
    // verify rows
    for ( int r = 0; r < 9; r++ ) {
      int count[] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
      for ( int c = 0; c < 9; c++ )
	count[board[r][c]]++;
      for ( int i = 1; i <= 9; i++ )
	if ( count[i] != 1 )
	  invalid = true;
    }
    // verify cols
    for ( int c = 0; c < 9; c++ ) {
      int count[] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
      for ( int r = 0; r < 9; r++ )
	count[board[r][c]]++;
      for ( int i = 1; i <= 9; i++ )
	if ( count[i] != 1 )
	  invalid = true;
    }
    // verify 3x3 boxes
    for ( int x = 0; x < 3; x++ )
      for ( int y = 0; y < 3; y++ ) {
	int count[] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
	for ( int x1 = x*3; x1 < (x+1)*3; x1++ )
	  for ( int y1 = y*3; y1 < (y+1)*3; y1++ )
	    count[board[x1][y1]]++;
	for ( int i = 1; i <= 9; i++ )
	  if ( count[i] != 1 )
	    invalid = true;
      }

    //report success using ternary
    cout << "Case " << j << ": " << ((invalid)?"INCORRECT":"CORRECT") << endl;
  }
}

    
