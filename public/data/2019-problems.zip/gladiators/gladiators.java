import java.util.*;

public class Gladiators {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int cases = sc.nextInt();
        for(int caseno = 0; caseno < cases; caseno++) {
            int gladiators = sc.nextInt();
            ArrayList<Gladiator> list = new ArrayList<>();
            for (int i = 0; i < gladiators; i++) {
                list.add(new Gladiator(sc.nextDouble(), sc.nextDouble(), sc.nextDouble()));
            }
            while (list.size() > 1) {
                ArrayList<Gladiator> newList = new ArrayList<>();
                for (int i = 0; i < list.size(); i += 2) {
                    newList.add(list.get(i).match(list.get(i + 1)));
                }
                list = newList;
            }
            System.out.println((int) Math.round(1000000 * list.get(0).computeChance(new Gladiator(sc.nextDouble(), sc.nextDouble(), sc.nextDouble()))));
        }
    }

    static class Gladiator {
        double rock, paper, scissors;
        public Gladiator(double rock, double paper, double scissors){
            this.rock = rock;
            this.paper = paper;
            this.scissors = scissors;
        }
        public double computeChance(Gladiator d){
            return (rock * d.scissors + paper * d.rock + scissors * d.paper) / (1 - (rock * d.rock + paper * d.paper + scissors * d.scissors));
        }
        public Gladiator match(Gladiator d){
            double chanceOfWinning = computeChance(d);
            return new Gladiator(chanceOfWinning * rock + (1 - chanceOfWinning) * d.rock,
                    chanceOfWinning * paper + (1 - chanceOfWinning) * d.paper, chanceOfWinning * scissors + (1 - chanceOfWinning) * d.scissors);
        }
    }
}
