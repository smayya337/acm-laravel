import math
import random
import miguel

def p(n):
    if n % 2 == 0 and n > 2: return False
    return all(n % i for i in range(3, int(math.sqrt(n)) + 1, 2))

mxx = 2147483647

pr = [i for i in range(3,100) if p(i)]
o = ""
w = []
n = 100
d = 10
o += str(n+10)
i = 0
mx = mxx
while True:
    mx -= random.randint(1,10000)
    e = random.randint(2,20)
    mm = 1
    m = random.sample(pr, e)
    for k in m: mm *= k
    if mm > mxx: continue
    o += "\n" + str(e)
    r = [mx%j for j in m]
    o += "\n" + "\n".join([str(r[j]) + " " + str(m[j]) for j in range(e)])
    #print(m,r)
    w.append(miguel.crt(r, m))
    i += 1
    if i == n: break

i = 0
mx = mxx
while True:
    mx -= random.randint(1,10000)
    e = random.randint(2,20)
    mm = 1

    m = random.sample(range(4,80), e)
    r = [random.randint(1,m[j]-1) for j in range(e)]
    for k in m: mm *= k
    if mm > mxx: continue
    out = miguel.crt(r,m)
    if out == "Cannot be determined":
        o += "\n" + str(e)
        o += "\n" + "\n".join([str(r[j]) + " " + str(m[j]) for j in range(e)])
        w.append("Cannot be determined")
        i += 1
        if i == d: break

with open("miguel.judge.in", "w+") as f: f.write(o)
with open("miguel.judge.out", "w+") as f: f.write("\n".join([str(i) for i in w]))
