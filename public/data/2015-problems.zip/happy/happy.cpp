#include <iostream>
#include <stdio.h>
#include <string>
using namespace std;

int iter (int x) {
    int total = 0;
    while (x != 0) {
        int t = x%100;
        total += t*t;
        x /= 100;
    }
    return total;
}

int main() {
    int N, x;
    cin >> N;
    for (int i=0; i<N; i++) {
        cin >> x;
        for (int k=0; k<1000; k++) {
            if (x < 100) {
                if (x >= 50) printf("QUASI-HAPPY: %i\n", k);
                else if (x < 50) printf("QUASI-SAD: %i\n", k);
                goto cont;
            } else x = iter(x);
        }
        cout << "LONG" << endl;
cont:
        ;
    }
    return 0;
}
