package test;

import java.util.Scanner;

public class babel {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        while(true) {
            long c = in.nextInt();
            long w = in.nextInt();
            long l = in.nextInt();
            long p = in.nextInt();
            if(c == 0 && w == 0 && l == 0 && p == 0)
                break;
            System.out.println((long)Math.pow(c, w * l * p));
        }
    }
}
