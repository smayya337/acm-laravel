The first line of the input will be a single integer, $n \leq 1,000$. There will be $n$ test cases that follow.


The first line of each test case will consist of a single integer, $c < 10,000$, the number of competitors. $c$ lines will follow, each with a string $m$, the alphanumeric name of a competitor, and $t < 10,000$, a floating-point time value of when the competitor finished. $m$ and $t$ are separated by a single space character.
