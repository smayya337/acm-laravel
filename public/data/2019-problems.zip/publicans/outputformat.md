Each test case should contain a single floating point number denoting the average taxes paid, accurate and truncated to three decimal places.
