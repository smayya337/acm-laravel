/* Matthew Hurtz
 * Grading Exams
 * Verified for Judging Data on 2.25.12
 */

import java.util.Scanner;

public class solution4 {
	public static void main(String[] args) {
		Scanner fin = new Scanner(System.in);
		
		int CS = fin.nextInt();
		for (int c = 0; c < CS; c++) {
			int L = fin.nextInt();
			
			String strKey = fin.next();
			String strAns = fin.next();
			
			int answers_incorrect = 0;
			
			for (int i = 0; i < L; i++) {
				if (strKey.charAt(i) != strAns.charAt(i)) answers_incorrect++;
			}
			
			System.out.println("Case " + (c+1) + ": " + answers_incorrect);
		}
	}

}
