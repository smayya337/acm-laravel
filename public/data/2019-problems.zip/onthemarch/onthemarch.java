import java.util.*;

public class OnTheMarch {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int cases = sc.nextInt();
        for (int caseno = 0; caseno < cases; caseno++) {
            int height = sc.nextInt();
            int width = sc.nextInt();
            int[][] map = new int[height][width];
            boolean[][] visited = new boolean[height][width];
            int rX, rY = rX = -1;
            sc.nextLine();
            for (int i = 0; i < height; i++) {
                String line = sc.nextLine();
                for (int j = 0; j < width; j++) {
                    char c = line.charAt(j);
                    if (c == 'R') {
                        map[i][j] = 0;
                        rX = j;
                        rY = i;
                    }
                    if (c == 'A')
                        map[i][j] = -3;
                    if (c == 'O')
                        map[i][j] = 1;
                    if (c == 'X')
                        map[i][j] = -1;
                }
            }
            if (dfs(rX, rY, map, visited))
                System.out.println("March onward!");
            else System.out.println("Stay home!");
        }
    }

    /// A BFS would be the better choice here, but we wanted teams to be able to solve with either,
    /// so we wrote our solution using a DFS.
    public static boolean dfs(int x, int y, int[][] map, boolean[][] visited){
        if(map[y][x] == -3)
            return true;
        if(visited[y][x]) return false;
        visited[y][x] = true;
        if(x != 0 && !visited[y][x - 1] && map[y][x - 1] != -1 && dfs(x - 1, y, map, visited))
            return true;
        if(x != map[y].length - 1 && !visited[y][x + 1] && map[y][x + 1] != -1 && dfs(x + 1, y, map, visited))
            return true;
        if(y != 0 && !visited[y - 1][x] && map[y - 1][x] != -1 && dfs(x, y - 1, map, visited))
            return true;
        if(y != map.length - 1 && !visited[y + 1][x] && map[y + 1][x] != -1 && dfs(x, y + 1, map, visited))
            return true;
        return false;
    }
}
