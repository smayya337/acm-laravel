# Aqueduct Rider

Water parks can be a lot of fun, right? The Roman children sure would have thought so! Unfortunately, they didn't have any proper water parks, so instead they used aqueducts.
 
Aqueducts make long, interweaving paths all throughout Rome. Since aqueducts are constantly splitting and combining, there are millions of possible ways to get to the bottom of an aqueduct. The path they take can be drastically different depending on which branches they slide down. While the number of paths down is numerous, it is not infinite; once you go down a portion of the aqueduct, you can never go back up and there is no path to get to the start of that segment.

Your task is to help the Roman hero Hercules in finding the longest path down an aqueduct network so he can tell the children of Rome.
