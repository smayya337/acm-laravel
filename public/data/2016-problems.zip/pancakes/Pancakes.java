import java.util.*;

/*
 * Reference Java solution for HSPC problem "Pancakes"
 *
 * This is a repackaged version of the Towers of Hanoi problem; as such
 * there *is* a closed form solution that can be used.  However, if one
 * is unfamiliar with that solution, a dynamic-programming formulation 
 * can be derived.  This file presents both possibilities.
 */
public class Pancakes {
  private static final int CLOSED_FORM = 0;
  private static final int DYN_PROGRAM = 1;

  // Change this variable to select solution method
  private static final int METHOD = CLOSED_FORM;

  public static void main(String[] args) {
    Scanner cin = new Scanner(System.in);

    int numTests = cin.nextInt();

    // Loop over all testcases
    for (int i = 0; i < numTests; i++) {
      int numPancakes = cin.nextInt();

      long requiredSteps = -1;
      if (METHOD == CLOSED_FORM)
        requiredSteps = solveWithClosedForm(numPancakes);
      else if (METHOD == DYN_PROGRAM)
        requiredSteps = solveWithDP(numPancakes);


      // Print out the solution
      System.out.printf("Case %d: %d\n", i+1, requiredSteps); 
    }
  }


  /*
   * It can be shown that the required number of motions is given by
   *                       2**numPancakes - 1
   * This allows a super-fast computation (especially if you use
   * shifts instead of Math.pow().
   */
  private static long solveWithClosedForm(int numPancakes) {
    return (long)Math.pow(2, numPancakes) - 1;

    // Note: an even faster solution would be to use shifts as below:
    //       return (1 << numPancakes) - 1;
  }


  /*
   * We can also solve this with dynamic programming.
   * 
   * To move a stack of n pancakes from plate A to plate C, we move the 
   * top n-1 pancakes to plate B.  (This takes requiredMovements[n-1]
   * motions.)  We then move that n-th pancake from A to C (taking one 
   * motion).  Finally, we move the n-1 pancakes from B to C, taking
   * requiredMovements[n-1] motions again.
   *
   * In total, this gives us the relationship:
   *          requiredMovements[n] = 2*requiredMovements[n-1] + 1
   */
  private static long solveWithDP(int numPancakes) {
    long[] requiredMovements = new long[numPancakes+1]; // Make a dp table

    requiredMovements[0] = 0; // There's 0 motions needed to move 0 pancakes.

    for (int i = 1; i < requiredMovements.length; i++) 
      requiredMovements[i] = 2*requiredMovements[i-1] + 1;

    return requiredMovements[numPancakes];
  }
}
