#include <iostream>
#include <string>
#include <cstdlib>
using namespace std;
#define N 100
#define SEED 4
int main() {
  cout << N << endl;
  // special cases (3)
  cout << "4\n1 5 5 1\n1 3 4 2\n";
  cout << "6\n1 0 2 3 4 2\n1 1 1 1 1 1\n";
  cout << "6\n2 3 94 3 4 8\n3 4 3 2 12 2\n";
  // random cases
  srand(SEED);
  for ( unsigned int i = 3; i < N; i++ ) {
    unsigned int size = rand() % 50 + 1;
    if ( i > N-3 )
      size = 1000;
    cout << size << endl;
    for ( unsigned int j = 0; j < size; j++ ) {
      cout << rand()%10;
      if ( j != size-1 )
	cout << " ";
    }
    cout << endl;
    for ( unsigned int j = 0; j < size; j++ ) {
      cout << rand()%10;
      if ( j != size-1 )
	cout << " ";
    }
    cout << endl;
  }
  return 0;
}
