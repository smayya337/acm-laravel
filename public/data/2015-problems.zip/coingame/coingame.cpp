#include<algorithm> // std::swap
#include<iostream>  // std::cout
#include<string>    // for manipulating board config strings
using namespace std;

class Matrix {
private:
    int** array;
    int rows, cols;

    //Replace r1 with (r1 xor r2)
    void xorRow(int r1, int r2) {
        for (int i = 0; i < cols; i++)
            array[r1][i] ^= array[r2][i];
    }

    //False iff row says (0 == 1)
    bool isValidRow(int r) {
        int rowSum = 0;
        for (int i = 0; i < cols-1; i++)
            rowSum += array[r][i];

        return !(rowSum == 0 && array[r][cols-1] == 1);
    }

public:
    Matrix(int r=1, int c=1) {
        //Save rows/cols:
        rows = r;
        cols = c;

        //Allocate a 2d array
        array = new int*[r];
        for (int i = 0; i < r; i++) {
            array[i] = new int[c];
            for (int j = 0; j < c; j++)
                array[i][j] = 0;
        }
    }

    ~Matrix() {
        delete[] array; //Should recursively deallocate--right?
    }

    void setRow(int rowNum, int* rowCont, int rowLength) {
        for (int i = 0; i < rowLength; i++)
            array[rowNum][i] = rowCont[i];
    }

    void setCol(int colNum, int* colCont, int colLength) {
        for (int i = 0; i < colLength; i++)
            array[i][colNum] = colCont[i];
    }

    void swapRows(int r1, int r2) {
        for (int i = 0; i < cols; i++)
            swap(array[r1][i], array[r2][i]);
    }

    int& at(int r, int c) {
        int& retVal = array[r][c];
        return retVal;
    }

    void rref() {
        int currRow = 0;
        for (int currPivot = 0; currPivot < min(cols, rows); currPivot++) {
            //Bring the first row with a pivot in the currPivot
            //  column up to the currRow.
            int swapRow = -1;
            for (int sRow = currRow; sRow < rows && swapRow == -1; sRow++) {
                if (array[sRow][currPivot] == 1)
                    swapRow = sRow;
            }
            if (swapRow == -1) continue;

            swapRows(currRow, swapRow);

            //Now, xor every other row with this one
            for (int j = 0; j < rows; j++) {
                if (currRow==j || array[j][currPivot] == 0)
                    continue;
                xorRow(j, currRow);
            }

            currRow++;
        }
    }

    bool isValid() {
        bool retVal = true;
        for (int i = 0; i < rows && retVal; i++)
            retVal &= isValidRow(i);

        return retVal;
    }

    void print() {
        for (int r = 0; r < rows; r++) {
            cout << "[";
            for (int c = 0; c < cols-1; c++)
                cout << array[r][c] << " ";
            cout << "| " << array[r][cols-1] << "]" << endl;
        }
    }
};

int main() {
    int N, L, M;

    cin >> N;

    for (int testNum = 0; testNum < N; testNum++) {
        cin >> L >> M;

        //Each column is a move, plus the board config for augmented
        Matrix m(L, M+1);

        //Read board configuration
        string startConfig;
        cin >> startConfig;
        for (int i = 0; i < startConfig.size(); i++)
            m.at(i, M) = (startConfig[i] == 'H' ? 0 : 1);

        //Read in the moves
        for (int moveNum = 0; moveNum < M; moveNum++) {
            string move;
            cin >> move;
            for (int i = 0; i < move.size(); i++)
                m.at(i, moveNum) = (move[i] == 'F' ? 1 : 0);
        }

        //Now do rref and check if valid.
        m.rref();
        cout << (m.isValid() ? "CAN BE SOLVED" : "CANNOT BE SOLVED") << endl;
    }
}
