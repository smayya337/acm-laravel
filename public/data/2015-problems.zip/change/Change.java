import java.util.*;

public class Change {
    public static void main(String[] args) {
        Scanner cin = new Scanner(System.in);

        int N = cin.nextInt();
        for (int testNum = 0; testNum < N; testNum++) {
            //Get input
            int D = cin.nextInt();
            int T = cin.nextInt();
            int[] denom = new int[D];
            int[] tests = new int[T];
            int maxTestAmt = 0;

            for (int i = 0; i < D; i++)
                denom[i] = cin.nextInt();

            for (int i = 0; i < T; i++) {
                tests[i] = cin.nextInt();
                maxTestAmt = Math.max(maxTestAmt, tests[i]);
            }

            //System.out.printf("Have read D=%d, T=%d\ndenom[]=%s, tests=%s\n", D, T, Arrays.toString(denom), Arrays.toString(tests));

            //Generate memo
            int[] ways = generateMemo(denom, maxTestAmt);

            //Find requests
            for (int i = 0; i < T; i++)
                tests[i] = ways[tests[i]];

            //Output
            System.out.printf("Case %d:", testNum+1);
            for (int i = 0; i < T; i++)
                System.out.printf(" %d", tests[i]);
            System.out.println();
        }
    }

    //Denom is increasing:
    private static int[] generateMemo(int[] denom, int maxChange) {
        //memo[i][j] holds number of ways to make j cents with coin denom[i] as the minimal coin.
        int[][] memo = new int[denom.length][maxChange+1];

        memo[denom.length-1][0] = 1; //one way to make 0 cents with maximal coin
        //(that helps with avoiding special cases later on...)

        memo[0][1] = 1; //one way to make 1 cent with a penny

        for (int change = 2; change <= maxChange; change++) {
            for (int currCoin = 0; currCoin < denom.length; currCoin++) { //Outer two loops for 2d DP

                //memo[currCoin][change] = SUM(memo[i][change-denom[currCoin]]):
                for (int i = currCoin; i < denom.length; i++) {
                    memo[currCoin][change] += safeArrayAccess(memo[i],change - denom[currCoin]);
                }
            }
        }

        //Sum up the "columns" to have O(1) access of # of ways
        int[] ways = new int[maxChange+1];
        for (int coin = 0; coin < denom.length; coin++)
            for (int change = 0; change < ways.length; change++)
                ways[change] += memo[coin][change];
        return ways;
    }

    //Accesses array, ignores negative indices
    private static int safeArrayAccess(int[] array, int index) {
        if (index < 0)
            return 0;
        return array[index];
    }
}
