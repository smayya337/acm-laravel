// Solution to "Cars Ranking" from the 2018 HSPC
// Solution by Alyson Irizarry, 2018

import java.util.*;

class weighted {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int nCases = input.nextInt();
        input.nextLine();       
        TreeMap<String,Integer> scores = new TreeMap<String,Integer>();  
        
        //iterate over each case
        for (int i = 1; i <= nCases; i++) {
            String season = input.nextLine();
            
            //add the cars
            int nCars = input.nextInt();
            input.nextLine();
            for (int j = 0; j  < nCars; j++) {
                scores.put(input.nextLine(), 0);
            }

            //update the scores
            int nRaces = input.nextInt();
            input.nextLine();
            for (int j = 0; j < nRaces; j++){
                String[] line = input.nextLine().trim().split(" ");
                scores.put(line[2], (scores.get(line[2]) + Integer.parseInt(line[1])));
                scores.put(line[3], (scores.get(line[3]) + Integer.parseInt(line[1])/2));
                scores.put(line[4], (scores.get(line[4]) + Integer.parseInt(line[1])/4));
            }

            System.out.println(season + ":");
            for (Map.Entry<String,Integer> entry: scores.entrySet()){
                System.out.println(entry.getKey() + " " + entry.getValue());
            } 
            scores.clear();
        }
    }
}