#include <iostream>
#include <string>
using namespace std;


int main() {
    string s;
    while (getline(cin, s)) {
        if(s=="END")
            break;
        for (string::iterator rit=--s.end(); rit != s.begin()-1; --rit)
            cout << *rit;
        cout << endl;
    }
    return 0;
}
