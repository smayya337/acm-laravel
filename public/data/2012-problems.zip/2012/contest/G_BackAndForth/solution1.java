/**
*Back and Forth Solution
*Chris Cunningham clc3bn@virginia.edu
*/


import java.util.*;
public class solution1
{
	public static void main(String[] args)
	{
		new solution1();
	}
	public solution1()
	{
		Scanner in = new Scanner(System.in);
		int Prob = in.nextInt();
		for(int prob = 0; prob < Prob; prob++)
		{
			int M = in.nextInt();
			int N = in.nextInt();
			int P = in.nextInt();
			Player[] players = new Player[P];
			for(int i = 0; i < P; i++)
			{
				players[i] = new Player(in.next(),
					in.nextInt(),in.nextInt(),in.next());
			}
			int steps = in.nextInt();
			for(int t = 0; t < steps; t++)
			{
				for(int i = 0; i < P; i++)
				{
					movePlayer(players[i],M,N);
				//	System.out.println("t: " + t + " " +  players[i].x + " " + 
				//		players[i].y + " " + players[i].dir + " " + players[i].name);
				}
				resolve(players);
			}
			
			ArrayList<Player> close = new ArrayList<Player>();
			double minDist = -1;
			for(int i = 1; i < P; i++)
			{
				if(minDist == -1 || dist(players[0],players[i]) < minDist)
				{
					minDist = dist(players[0],players[i]);
					close.clear();
					close.add(players[i]);
				}
				if(dist(players[0],players[i]) == minDist)
				{
					close.add(players[i]);
				}
			}
			int minLength = -1;
			int min = 0;
			for(int i = 0; i < close.size(); i++)
			{
				if(minLength == -1 || close.get(i).name.length() < minLength)
				{
					min = i;
					minLength = close.get(i).name.length();
				}
			}
			System.out.println("Case " + (prob + 1) + ": " +close.get(min).name);
		}
	}

	public double dist(Player one, Player two)
	{
		return Math.sqrt(Math.pow(one.x-two.x,2) + Math.pow(one.y-two.y,2));
	}

	public void resolve(Player[] p)
	{
		for(Player pl : p)
			pl.checked = false;
		for(int i = 0; i < p.length - 1; i++)
		{
			
			if(p[i].checked)
				continue;
			ArrayList<Integer> is = new ArrayList<Integer>();
			p[i].checked = true;
			is.add(i);
			int tempx = p[i].x;
			int tempy = p[i].y;
			for(int j = i + 1; j < p.length; j++)
			{
				if(p[j].checked)
					continue;
				if(p[j].x == p[i].x && p[j].y == p[i].y)
				{
					p[j].checked = true;
					is.add(j);
				}
			}
			if(is.size() == 2)
			{
				int min = is.get(0);
				int max = is.get(1);
				if(p[min].name.length() > p[max].name.length())
				{
					max = is.get(0);
					min = is.get(1);
				}	
				String tempdir = p[min].dir;
				p[min].dir = p[max].dir;
				reversePlayer(p[min]);
				p[max].dir = tempdir;
			}
			else if(is.size() > 2)
			{
				for(Integer ind : is)
				{
					reversePlayer(p[ind]);
				}
			}
			if(is.size()  > 1)
			{
		//		System.out.println(is.size());
			}
		}
	}
	
	public void reversePlayer(Player p)
	{
		if(p.dir.equals("N"))
		{
			p.dir = "S";
		}
		else if(p.dir.equals("E"))
		{
			p.dir = "W";
		}
		else if(p.dir.equals("S"))
		{
			p.dir = "N";
		}
		else if(p.dir.equals("W"))
		{
			p.dir = "E";
		}
	}

	public void movePlayer(Player p,int W, int H)
	{
		if(p.dir.equals("N"))
		{
			if(p.y == H - 1)
			{
				reversePlayer(p);
				p.y = p.y - 1;
			}
			else
				p.y = p.y + 1;
		}
		else if(p.dir.equals("E"))
		{
			if(p.x == W - 1)
			{
				reversePlayer(p);
				p.x = p.x - 1;
			}			
			else
				p.x = p.x + 1;
		}
		else if(p.dir.equals("S"))
		{
			if(p.y == 0)
			{
				reversePlayer(p);
				p.y = p.y + 1;
			}
			else
				p.y = p.y - 1;
		}
		else if(p.dir.equals("W"))
		{
			if(p.x == 0)
			{
				reversePlayer(p);
				p.x = p.x + 1;
			}
			else
				p.x = p.x - 1;
		}
	}

	class Player
	{
		public String name;
		public int x;
		public int y;
		public String dir;
		public boolean checked = false;	
		public Player(String name, int x, int y, String dir)
		{
			this.name = name;
			this.x = x;
			this.y = y;
			this.dir = dir;
		}
	}

}
