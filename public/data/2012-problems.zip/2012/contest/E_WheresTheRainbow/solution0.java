/*
 * solved by Jonathan DiLorenzo
*/

import java.util.*;
public class solution3
{
	public static void main(String[] args)
	{
	    Scanner in = new Scanner(System.in);
	    int cases = in.nextInt();
	    double h,angle,d;
	    for (int i = 1; i <= cases;i++)
		{
		    h = in.nextDouble();
		    angle = in.nextDouble();
		    d = Math.abs(h/Math.tan(angle/180*Math.PI)-h);
		    System.out.println("Case " + i + ": " + d);
		}
	}
}
