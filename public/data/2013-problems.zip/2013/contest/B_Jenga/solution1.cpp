// Bloomfield's Jenga solution, 3-11-13
#include <iostream>
#include <string>
using namespace std;
int main() {
  int n, h;
  string s;
  cin >> n;
  for ( int i = 1; i <= n; i++ ) {
    cin >> h;
    bool fallen = false;
    for ( int j = 0; j < h; j++ ) {
      cin >> s;
      if ( (s == "000") || (s == "001") || (s == "100") )
	fallen = true;
    }
    cout << "Case " << i << ": " << ((fallen)?"Fallen":"Standing") << endl;
  }

}
