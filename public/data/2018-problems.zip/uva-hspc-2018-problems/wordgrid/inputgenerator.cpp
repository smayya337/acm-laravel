/**
 * input generator for wordgrid
 *
 * This must be compiled with -std=c++11
 *
 * run with a random seed (via command-line parameter) of 4 to
 * generate the wordgrid.judge.in file.
 *
 * The words below intentionally don't have the letter 'z' in it.  To
 * ensure that any word does not accidentally appear elsewhere in the
 * grid file, any character in the grid that has the first letter of
 * the word being searched for will be changed to 'z'.  Furthermore,
 * none of the words are palindromes (as they could be found in either
 * direction).
 *
 * Written by Aaron Bloomfield, 2018
 */

#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <fstream>

using namespace std;

string dirs[] = { "n", "ne", "e", "se", "s", "sw", "w", "nw" };

// a bunch of random words from the ispell dictionary, none of which
// contain 'z' and none of which are palindromes
string thewords[] = {"pfennig", "unalienability", "frolicking", "recta",
"symptomatology", "bushmen", "hieing", "sublunary", "dessicate",
"gooier", "nonconservative", "macrosimulation", "unamused",
"bevelling", "jitterbugging", "unwaivering", "herself", "squattest",
"debugged", "precollege", "atrophic", "jutted", "indisputably",
"stratospheric", "gambolled", "vivo", "northeastern", "hirsute",
"petted", "sox", "mononuclear", "dodecahedra", "collinearity",
"hyperemic", "gadding", "fanning", "diatomic", "herbaceous",
"radioastronomy", "fieldstone", "matriarchs", "impartation",
"enthalpy", "podcast", "tyrannous", "dilithium", "rescaling",
"caudal", "snuck"};
int thewords_size = 49;

int numrandomcases = 100;

int numfixedcases = 14;
const char* fixedcases = R"(5 4
dnemoxoxxxxxrxxxxxyx
nemo
5 4
dnemoxoxxxxxrxxxxxyx
dory
5 4
dnemoxoxxxxxrxxxxxyx
marlin
3 3
axxxaaaaa
xxx
2 2
abcd
ab
2 2
abcd
xy
5 5
abcdefghijklmnopqrstuvwxy
wrmhc
5 5
abcdefghijklmnopqrstuvwxy
uqmie
5 5
abcdefghijklmnopqrstuvwxy
klmno
5 5
abcdefghijklmnopqrstuvwxy
agmsy
5 5
abcdefghijklmnopqrstuvwxy
chmrw
5 5
abcdefghijklmnopqrstuvwxy
eimqu
5 5
abcdefghijklmnopqrstuvwxy
onmlk
5 5
abcdefghijklmnopqrstuvwxy
ysmga
)";

const char* fixedcases_ans = R"(1 0 e
0 0 se
not found
not found
0 0 e
not found
2 4 n
0 4 ne
0 2 e
0 0 se
2 0 s
4 0 sw
4 2 w
4 4 nw
)";

int main(int argc, char *argv[]) {
  // answer file
  ofstream fout;
  fout.open("answer.out");
  fout << fixedcases_ans;
  
  // handle random seed
  int seed = time(NULL);
  if ( argc == 2 )
    sscanf(argv[1],"%d",&seed);
  srand(seed);

  // create list of letters
  vector<char> grid;
  for ( int i = 0; i < 100*100; i++ )
    grid.push_back(rand() % 26 + 'a');

  // create list of words
  vector<string> words;
  for ( int i = 0; i < thewords_size; i++ )
    words.push_back(string(thewords[i]));

  cout << (numrandomcases+numfixedcases) << "\n" << fixedcases;
  for ( int i = 0; i < numrandomcases; i++ ) {
    // determine and write grid size
    int w = rand() % 98 + 3;
    int h = rand() % 98 + 3;
    if ( i == 0 )
      w = h = 100;
    cout << w << " " << h << endl;
    // determine word
    string word = words[rand()%words.size()];
    // determine grid
    char thisgrid[100][100];
    random_shuffle(grid.begin(), grid.end());
    int j = 0;
    for ( int y = 0; y < h; y++ )
      for ( int x = 0; x < w; x++ ) {
	if ( grid[j] == word[0] )
	  thisgrid[x][y] = 'z';
	else
	  thisgrid[x][y] = grid[j];
	j++;
      }
    // possibly place word in grid
    bool found = true;
    int posx, posy, x, y, d;
    d = rand() % 8;
    posx = x = rand() % w;
    posy = y = rand() % h;
    for ( int j = 0; j < word.length(); j++ ) {
      if ( (x < 0) || (y < 0) || (x >= w) || (y >= h) ) {
	found = false;
	break;
      }
      thisgrid[x][y] = word[j];
      switch (d) {
      case 0: y--; break; // n
      case 1: y--; x++; break; // ne
      case 2: x++; break; // e
      case 3: x++; y++; break; // se
      case 4: y++; break; // s
      case 5: y++; x--; break; // sw
      case 6: x--; break; // w
      case 7: x--; y--; break; // nw
      }
    }
    // output grid
    for ( int y = 0; y < h; y++ )
      for ( int x = 0; x < w; x++ )
	cout << thisgrid[x][y];
    cout << "\n" << word << endl;
    // answer
    if ( !found )
      //fout << "Case " << (numfixedcases+i+1) << ": not found" << endl;
      fout << "not found" << endl;
    else
      //fout << "Case " << (numfixedcases+i+1) << ": " << posx << " " << posy << " " << dirs[d] << endl;
      fout << posx << " " << posy << " " << dirs[d] << endl;
  }

  fout.close();
  return 0;
}


