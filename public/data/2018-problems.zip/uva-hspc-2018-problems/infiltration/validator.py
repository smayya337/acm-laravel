# Henry Conklin 2018
# Significant portion copied from python solution by Marina Sanusi, 2018

# Usage: validator.py <judge infile> <contestant outfile> <judge outfile> <destination results file>
import sys
import re


# is a minimum dominating set
def min_dom_set(nodes, graph):
    nodes_covered = set()
    for node in nodes:
        nodes_covered.update(graph[node])
        nodes_covered.add(node)
    if len(nodes_covered) == len(graph):
        return True
    else:
        return False


# convert binary string input to nodes
def bs_to_nodes(bs):
    nodes = []
    for i, char in enumerate(bs):
        if char == '1':
            nodes.append(i + 1)
    return nodes

out_line_format = re.compile(r'Case ([0-9]+):(( +[0-9]+)+)')
def get_answer_list(f):
    line = f.readline().strip()

    # Check that the output line is formatted correctly
    match = out_line_format.match(line)
    if match is None:
        raise ValueError()

    casenum = int(match.group(1))

    # Parse out answer list
    answer = match.group(2).strip()
    answer = answer.split(" ")
    answer = list(map(int, answer))

    return casenum, answer[0], answer[1:]



if __name__ == "__main__":
    fin, fout, ans, res = sys.argv[1:]
    result = 'No - Wrong answer'

    with open(fin) as inFile:
        with open(fout) as outFile:
            with open(ans) as ansFile:

                try:
                    n = int(inFile.readline())

                    for i in range(n):
                        c = int(inFile.readline())
                        b_strings = []
                        graph = {}
                        for j in range(c):
                            bs = inFile.readline()
                            graph[j + 1] = bs_to_nodes(bs)

                        # Read from contestant answer
                        casenum, ncells, cells = get_answer_list(outFile)
                        # Read from judge answer
                        jcasenum, jncells, jcells = get_answer_list(ansFile)

                        # Number of cells wrong
                        if ncells != len(cells) or ncells != jncells:
                            print("Case {} bad: wrong number of cells".format(i+1))
                            raise ValueError()

                        # Cells do not cover
                        if not min_dom_set(cells, graph):
                            print("Case {} bad: cells do not cover".format(i+1))
                            raise ValueError()

                        print("Case {} good".format(i+1))

                    # Made it through all input without raising an error
                    result = 'Yes'

                except (IOError, ValueError) as e:
                    result = 'No - Wrong answer'

                if outFile.read().strip() != '':
                    result = 'No - Wrong answer'

    outstr = '<?xml version="1.0"?>\n<result outcome="{0}" security="{1}"> {0} </result>\n'.format(result, res)
    with open(res, 'w') as resFile:
        resFile.write(outstr)
    print(outstr)
