import java.util.*;
import java.io.*;
import java.text.*;

public class HelloJudge {
	public static void main(String[] args) {
		Scanner fin = new Scanner(System.in);

		int N = fin.nextInt();

		for (int i = 1; i <= N; i++) {
			System.out.println("Hello World, Judge " + i + "!");
		}
	}
}
