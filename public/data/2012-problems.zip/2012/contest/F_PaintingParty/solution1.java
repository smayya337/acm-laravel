/** Problem: Painting Party
* Solver: Chris Cunningham clc3bn@virginia.edu
* Problem Writers: Dan Epstein dae5y@virginia.edu Jonathan DiLorenzo jd9hz@virginia.edu
* Time Taken: 10-15 min
* Overall Thoughts: Good Problem
* Things to fix: Maybe add a line between output cases
**/

import java.util.*;
import java.text.*;
public class solution1
{
	public static void main(String[] args)
	{
		new solution1();
	}
	
	public solution1()
	{
		Scanner in = new Scanner(System.in);
		int cases = in.nextInt();
		for(int c = 0; c < cases; c++)
		{
			int N = in.nextInt();
			int M = in.nextInt();
			char[][] wall = new char[N][N];
			for(int i = 0; i < N; i++)
				for(int j = 0; j < N; j++)
					wall[i][j] = '.';
			for(int count = 0; count < M; count++)
			{
				String type = in.next();
				int x = in.nextInt();
				int y = in.nextInt();
				int w = in.nextInt();
				int h = in.nextInt();
				char[] chs = (in.next().toCharArray());
				char ch = chs[0];
				
				for(int i = x; i < x + w; i++)
				{
					for(int j = y; j < y + h; j++)
					{
						if(type.equals("Empty") && 
						(i != x && i != (x + w - 1) && j != y && j != (y + h - 1)))
							continue;
						wall[i-1][j-1] = ch;
					}
				}
				
			}
			System.out.println("Case " + (c + 1) + ":");
			for(int i = N - 1; i >= 0; i--)
			{
				for(int j = 0; j < N; j++)
					System.out.print(wall[j][i]);
				System.out.println();
			}
		}
	}
}
