// Solves "Jmp Mario" from the 2017 HSPC at UVa
// Solution by Joseph Tobin, 2017

import java.util.*;

public class jmp {
	public static void main(String arg[]) {

		Scanner cin = new Scanner(System.in);

	    // Iterate over each case
	    int numCases = cin.nextInt();

	    for(int currCase = 0; currCase <  numCases; currCase++ ) {

	    	int numSteps = cin.nextInt();

	    	int[] steps = new int[numSteps];

	    	//scan ahead

	    	for(int i = 0; i < numSteps ; i++ ) {
	    		steps[i] = cin.nextInt();
	    	}

	    	boolean possible = true;

	    	//check to see if it's possible to run
	    	for(int i =0; i < numSteps -1; i++) {
	    		if(steps[i+1] - steps[i] > 2 ) {
	    			possible = false;
	    		}
	    	}

	    	System.out.print("Case " + (currCase + 1) + ":");
	    	if(possible) {
	    		for(int i =0; i < numSteps -1; i++) {
	    			System.out.print(" ");
	    			int diff = steps[i+1] - steps[i];
	    			if(diff == 2) {
	    				System.out.print("double jump");
	    			}
	    			else if(diff == 1) {
	    				System.out.print("jump");
	    			}
	    			else {
	    				System.out.print("run");
	    			}
	    		}
	    	}
	    	else {
	    		System.out.print(" not traversable");
	    	}

	    	System.out.println();
	    }


	}
}
