#include <iostream>
#include <cmath>
using namespace std;

int main() {
    while(true) {
        int x;
        cin >> x;
        int y;
        cin >> y;
        if(x == 0 && y == 0)
            break;
        cout << (int) round(atan2(y, x) * 180 / 3.14159265358979) << endl;
    }
    return 0;
}
