#include <iostream>
#include <queue>

using namespace std;

int main() {
    int w = 0;
    int h = 0;
    while(cin.good()) {
        cin >> w >> h;
        char mirkwood[h][w];
        queue<int> spiders;
        for ( int i = 0; i < h; i++ ) {
            for ( int j = 0; j < w; j++ ) {
                cin >> mirkwood[i][j];
                if (mirkwood[i][j] == 'S') {
                    spiders.push(i*w+j);
                }
            }
        }
        while ( !spiders.empty() ) {
            int pos = spiders.front();
            spiders.pop();
            int y = pos / w;
            int x = pos % w;
            if ( x > 0  && mirkwood[y][x-1]  == 'T' ) {
                mirkwood[y][x-1] = 'S';
                spiders.push(y*w+x-1);
            }
            if ( y > 0 && mirkwood[y-1][x] == 'T' ) {
                mirkwood[y-1][x] = 'S';
                spiders.push((y-1)*w+x);
            }
            if ( y < (h-1) && mirkwood[y+1][x] == 'T' ) {
                mirkwood[y+1][x] = 'S';
                spiders.push((y+1)*w+x);
            }
            if ( x < (w-1) && mirkwood[y][x+1] == 'T' ) {
                mirkwood[y][x+1] = 'S';
                spiders.push(y*w+x+1);
            }
        }
        for ( int i = 0; i < h; i++ ) {
            for ( int j = 0; j < w; j++ ) {
                cout << mirkwood[i][j];
            }
            cout << endl;
        }
    }
    return 0;
}
