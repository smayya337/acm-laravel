import sys

ncases = int(sys.stdin.readline())
for i in range(1,ncases+1):
    ndoors = int(sys.stdin.readline())
    doors = dict()
    for j in range(ndoors):
        diff, name = sys.stdin.readline().strip().split(" ") 
        diff = int(diff)
        doors[name] = diff

    sdoors = sorted(doors, key=lambda x: doors[x])
    print("Case {:d}:".format(i))
    for d in sdoors:
        print(d)

