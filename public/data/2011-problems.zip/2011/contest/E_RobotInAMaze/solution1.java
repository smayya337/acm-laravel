// By Henderson
import java.util.*;

public class Robot {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int numGrids = scanner.nextInt();
        for (int g = 0; g < numGrids; g++) {
            int rows = scanner.nextInt();
            int columns = scanner.nextInt();
            scanner.nextLine();
            char[][] grid = new char[rows][columns];
            for (int i = 0; i < rows; i++) {
                String line = scanner.nextLine();
                for (int j = 0; j < columns; j++) {
                    grid[i][j] = line.charAt(j);
                }
            }
            
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < columns; j++) {
                    if (grid[i][j] == 'S') {
                        boolean[][] visited = new boolean[rows][columns];
                        LinkedList<Pair> queue = new LinkedList<Pair>();
                        Pair start = new Pair(i, j, 0);
                        visited[i][j] = true;
                        queue.offerLast(start);
                        boolean impossible = true;

                        while (!queue.isEmpty()) {
                            Pair curr = queue.pop();
                            int a = curr.row;
                            int b = curr.col;
                            int time = curr.time;
                            if (grid[a][b] == 'G') {
                                System.out.println("Shortest Path: " + time);
                                impossible = false;
                                break;
                            }
                            //up
                            if (a-1 >=0) {
                                if ( (grid[a-1][b] != 'X') && (!visited[a-1][b]) ) {
                                    Pair next = new Pair(a-1, b, time+1);
                                    queue.offerLast(next);
                                    visited[a-1][b] = true;
                                }
                            }
                            //down
                            if (a+1 < rows) {
                                if ( (grid[a+1][b] != 'X') && (!visited[a+1][b]) ) {
                                    Pair next = new Pair(a+1, b, time+1);
                                    queue.offerLast(next);
                                    visited[a+1][b] = true;
                                }
                            }
                            //left
                            if (b-1 >= 0) {
                                if ( (grid[a][b-1] != 'X') && (!visited[a][b-1]) ) {
                                    Pair next = new Pair(a, b-1, time+1);
                                    queue.offerLast(next);
                                    visited[a][b-1] = true;
                                }
                            }
                            //right
                            if (b+1 < columns) {
                                if ( (grid[a][b+1] != 'X') && (!visited[a][b+1]) ) {
                                    Pair next = new Pair(a, b+1, time+1);
                                    queue.offerLast(next);
                                    visited[a][b+1] = true;
                                }
                            }
                        }

                        if (impossible) System.out.println("No Exit");
                    }
                }
            }

        }
    }

}

class Pair {
    public int row;
    public int col;
    public int time;
    Pair(int i, int j, int t) {
        row = i;
        col = j;
        time = t;
    }
}
