import sys

test_cases = int(sys.stdin.readline())
for _ in range(test_cases):
    names = int(sys.stdin.readline())
    standings = [ sys.stdin.readline().strip().split() for _ in range(names)]
    for name, _ in sorted(standings, key=lambda s: float(s[1])):
        print(name)
