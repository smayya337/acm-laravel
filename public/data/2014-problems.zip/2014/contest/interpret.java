import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class interpret {

    static HashMap<String, Integer> lblStore = new HashMap<String, Integer>();
    static HashMap<String, Integer> varStore = new HashMap<String, Integer>();

    public static int getValue(String command) {
        try {
            return Integer.parseInt(command); // if constants are being passed
            // in
        } catch (IllegalArgumentException e) {
            if(command.contains("[")) {		// check for arrays
                String arg = command.substring(command.indexOf("[") + 1, command.lastIndexOf("]"));
                command = command.replaceFirst(arg, getValue(arg) + "");
            }
            return varStore.get(command);
        }
    }

    public static void interpret(String[] program) {
        String[] program_lines = program;
        for (int i = 0; i < program_lines.length; i++) { // preprocessor loop -
            // find labels
            program_lines[i] = program_lines[i].trim();
            if (program_lines[i].startsWith("sad")) {
                lblStore.put(program_lines[i].split(" ")[1], i);
            }
        }
        int program_counter = 0;
        while (true) {
            String line = program_lines[program_counter];
            String[] command = line.split(" ");
            // System.out.println(line);
            if (command[0].equals("arth")) {
                String label = command[1];
                program_counter = lblStore.get(label) - 1; // Off by one because
                // we're
                // incrementing at
                // the end
            } else if (command[0].equals("pen")) {
                String var1 = command[1];
                String var2 = command[2];
                String label = command[3];
                if (getValue(var1) < getValue(var2)) {
                    program_counter = lblStore.get(label) - 1;
                }
            } else if (command[0].equals("muindor")) {
                String var1 = command[1];
                String var2 = command[2];
                String label = command[3];
                if (getValue(var1) == getValue(var2)) {
                    program_counter = lblStore.get(label) - 1;
                }
            } else if (command[0].equals("sad")) {
                // nop - (n) - no operation.
                // Ex: On the pipeline stall, it just injected nop.
            } else if (command[0].equals("tangado")) {
                String var = command[1];
                varStore.put(var, 0);
            } else if (command[0].equals("ost")) {
                String var = command[1];
                int size = Integer.parseInt(command[2]);
                for (int i = 0; i < size; i++) {
                    varStore.put(var + "[" + i + "]", 0);
                }
            } else if (command[0].equals("teithant")) {
                for(int i = 1; i < command.length; i++) {
                    if ( i == 1 && i == command.length-1) {
                        System.out.println(command[i].substring(1, command[i].length() - 1));
                    } else if(i == 1)
                        System.out.print(command[i].substring(1) + " ");
                    else if ( i == command.length - 1) {
                        System.out.println(command[i].substring(0, command[i].length() - 1));
                    } else
                        System.out.print(command[i] + " ");
                }
            } else if (command[0].equals("canad")) {
                String var = command[1];
                System.out.println(getValue(var));
            } else if (command[0].equals("anno")) {
                String var1 = command[1];
                String var2 = command[2];
                int val = getValue(var2);
                varStore.put(var1, val);
            } else if (command[0].equals("aderthad")) {
                String var1 = command[1];
                String var2 = command[2];
                int val = getValue(var1) + getValue(var2);
                varStore.put(var1, val);
            } else if (command[0].equals("adlanna")) {
                String var1 = command[1];
                String var2 = command[2];
                int val = getValue(var1) / getValue(var2);
                varStore.put(var1, val);
            } else if (command[0].equals("adlegi")) {
                String var1 = command[1];
                String var2 = command[2];
                int val = getValue(var1) - getValue(var2);
                varStore.put(var1, val);
            } else if (command[0].equals("athrado")) {
                String var1 = command[1];
                String var2 = command[2];
                int val = getValue(var1) * getValue(var2);
                varStore.put(var1, val);
            } else if (command[0].equals("awarthad")) {
                System.exit(0);
            }
            program_counter++;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<String> program = new ArrayList<String>();
        while (sc.hasNextLine()) {
            String line = sc.nextLine().trim();
            if (line.equals("END"))
                break;
            program.add(line);
        }
        String[] program_lines = new String[program.size()];		// convert to an array because we wrote this code like that originally
        for(int i = 0; i < program.size(); i++) {					// # embarrassing
            program_lines[i] = program.get(i);						// oh well
        }
        interpret(program_lines);
    }

}
