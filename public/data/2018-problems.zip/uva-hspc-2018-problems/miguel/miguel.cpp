/*
 * C++ solution to Miguel
 *
 * by Marina Sanusi, 2018
 */

#include <iostream>
#include <stdio.h>
#include <vector>
#include <map>
#include <cmath>

using namespace std;

long inv(int r, int m) {
    long m0 = m, t, q;
    long x0 = 0, x1 = 1;

    if (m == 1)
       return 0;

    while (r > 1) {
        if (m == 0) return -1;
        q = r / m;
        t = m;
        m = r % m, r = t;
        t = x0;
        x0 = x1 - q * x0;
        x1 = t;
    }
    if (x1 < 0)
       x1 += m0;
    return x1;
}

bool isPrime(long n) {
    if (n == 1) return false;
    if (n <= 3) return true;
    if (n % 2 == 0) return false;
    int bound = lround(sqrt(n));
    for (int i = 3; i <= bound; i+=2) {
        if (n % i == 0) return false;
    }
    return true;
}

map<long,long>* reduce(const vector<long>& mods, const vector<long>& rems) {
    map<long, long>* res = new map<long,long>;
    for (int i = 0; i < mods.size(); i++) {
        int m = mods[i];
        // Get prime factors
        for (int f = 2; f <= m; f++) {
            // f is a prime factor
            if (m % f == 0 && isPrime(f)) {
                // if remainder mod prime divisor doesn't match other equations
                if (res->count(f) && rems[i] % f != res->at(f)) {
                    delete res;    
                    return nullptr;
                }
                if (!res->count(f)) {
                    res->insert(make_pair(f, rems[i] % f));
                }
            }
        }
    }
    return res;
}

bool consistent(long soln, const vector<long>& mods, const vector<long>& rems) {
    for (int i = 0; i < mods.size(); i++) {
        if (soln % mods[i] != rems[i]) return false;
    }
    return true;
}

long gcd(long a, long b) {
    while (b != 0) {
        long t = b;
        b = a % b;
        a = t;
    }
    return a;
}

bool isPossible(const vector<long>& mods, const vector<long>& rems) {
    for (int i = 0; i < mods.size(); i++) {
        for (int j = i+1; j < mods.size(); j++) {
            int pairgcd = gcd(mods[i], mods[j]);
            if (rems[i] % pairgcd != rems[j] % pairgcd) return false;
        }
    }
    return true;
}

int main() {
  long n;
  cin >> n;
  for (long i = 0; i < n; i++) {
    long e;
    vector<long> ms;
    vector<long> rs;
    vector<long> ys;
    cin >> e;
    long N = 1;
    for (long j = 0; j < e; j++) {
      long m,r;
      cin >> r;
      cin >> m;
      N *= m;
      ms.push_back(m);
      rs.push_back(r);
    }

    if (!isPossible(ms,rs)) {
        cout << "Cannot be determined" << endl;
        continue;
    }

    map<long,long>* reduced = reduce(ms,rs);
    long M = 1;
    for (auto it = reduced->begin(); it != reduced->end(); ++it) {
        M *= it->first;
    }
    
    bool works = true;
    long soln = 0;
    for (auto it = reduced->begin(); it != reduced->end(); ++it) {
        long b = M/it->first;
        long binv = inv(b, it->first);
        if (binv <= 0) {
            works = false;
            break;
        }

        soln += it->second * b * binv;
        soln %= M;
    }
    if (!works) {
        cout << "Cannot be determined" << endl;
        continue;
    }

    int mx = ms[0];
    for (int j = 1; j < ms.size(); j++) mx = mx > ms[j] ? mx : ms[j];
    while (soln < mx || !consistent(soln, ms, rs)) soln += M;
    cout << soln << endl;

    delete reduced;
  }
}
