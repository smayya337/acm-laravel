// Solves "Samsu Charge" from the 2017 HSPC at UVa
// Solution by Joseph Tobin, 2017

import java.util.*;

/*
 * Main concept: Sorting (it's a whole lot easier with the Comparable class in Java)
 */

public class samus {
  public static void main(String[] args) {
    Scanner cin = new Scanner(System.in);

    // Iterate over each case
    int numCases = cin.nextInt();
    for (int currCase = 0; currCase < numCases; currCase++) {
      int numSteps = cin.nextInt();
      int[] ans = new int[numSteps];

      int[] z = new int[numSteps];
      int[] c = new int[numSteps];

      //Read in Z
      for(int i = 0; i < numSteps; i++) {
        z[i] = cin.nextInt();
      }

      //Read in C
      for(int i = 0; i < numSteps; i++) {
        c[i] = cin.nextInt();
      }

      if(ans.length > 0) {
        ans[0] = min(z[0], c[0]);
        //System.out.println(ans[0]);
      }

      for(int i = 1; i < numSteps; i ++) {

        int max = 0;
        int sum = 0;

        for(int j = i-1; j > -1; j--) {
          sum += c[j+1];
          
          max = max(max, (ans[j] + min(z[i], sum)));
        }

        ans[i]= max(max, min(z[i], sum + c[0]) );

        //System.out.println(max);
        
      }

      System.out.println(ans[numSteps -1]);


    }

  }

  public static int max(int a, int b) {
    return (a >= b) ? a : b;
  }

  public static int min(int a, int b) {
    return (a <= b) ? a : b;
  }


}
