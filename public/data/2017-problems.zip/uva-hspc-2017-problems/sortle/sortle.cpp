// Solves "Sortle!" from the 2017 HSPC at UVa
// Solution by Aaron Bloomfield, 2017

#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <algorithm>
using namespace std;
int main() {
  unsigned int n, s;
  string p, t;
  cin >> n;
  for ( unsigned int i = 0; i < n; i++ ) {
    map<string,vector<string> > m;
    cout << "Case " << (i+1) << ":" << endl;
    cin >> s;
    for ( unsigned int j = 0; j < s; j++ ) {
      cin >> p >> t;
      if ( m.find(t) == m.end() )
	m[t] = vector<string>();
      m[t].push_back(p);
    }
    for ( map<string,vector<string> >::iterator it = m.begin(); it != m.end(); it++ ) {
      sort(it->second.begin(),it->second.end());
      for ( vector<string>::iterator it2 = it->second.begin(); it2 != it->second.end(); it2++ )
	cout << *it2 << " " << it->first << endl;
    }
  }
  return 0;
}
