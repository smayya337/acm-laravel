import sys

##
# Solution to substitution by apn4za
# 
# Basic idea: create a dictionary mapping the shuffled character
# back to its original value.  Then, apply that mapping to every 
# character in the string
##

alpha = 'abcdefghijklmnopqrstuvwxyz'

# Creates a dictionary/map from {shuffled_letter : normal_letter}
def decoder_map(shuffled_alphabet):
  return dict(zip(shuffled_alphabet, alpha))
  

if __name__ == '__main__':
  nCases = int(sys.stdin.readline())

  for i in range(nCases):
    shuffled_alpha = sys.stdin.readline().strip()
    m = decoder_map(shuffled_alpha)

    s = sys.stdin.readline().strip()

    decoded = ''.join(map(lambda c : m.get(c, ' '), s))

    print(decoded)
