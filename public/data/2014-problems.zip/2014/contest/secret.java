import java.util.*;

public class secret {
    public static void main(String[] args) {
        Scanner io = new Scanner(System.in);
        while (io.hasNextLine()) {
            String line = io.nextLine();
            if(line.equals("END"))
                break;
            for (int i = line.length()-1; i >= 0; i--)
                System.out.print(line.charAt(i));
            System.out.println();
        }
    }
};
