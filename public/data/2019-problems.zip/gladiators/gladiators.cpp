#include <iostream>
#include <vector>
#include <cmath>

class Gladiator {
public:
    double rock, paper, scissors;
    Gladiator(double rock, double paper, double scissors) :
        rock{ rock }, paper{ paper }, scissors{ scissors }{}

    double computeChance(Gladiator d){
        return (rock * d.scissors + paper * d.rock + scissors * d.paper) / (1 - (rock * d.rock + paper * d.paper + scissors * d.scissors));
    }
    Gladiator match(Gladiator d){
        double chanceOfWinning = computeChance(d);
        return Gladiator(chanceOfWinning * rock + (1 - chanceOfWinning) * d.rock,
                             chanceOfWinning * paper + (1 - chanceOfWinning) * d.paper, chanceOfWinning * scissors + (1 - chanceOfWinning) * d.scissors);
    }
};

int main(int argc, char** argv){
    int cases;
    std::cin >> cases;
    for(int caseno = 0; caseno < cases; caseno++) {
        int gladiators;
        std::cin >> gladiators;
        std::vector<Gladiator> list = {};
        for (int i = 0; i < gladiators; i++) {
            double rock, paper, scissors;
            std::cin >> rock >> paper >> scissors;
            list.emplace_back(Gladiator(rock, paper, scissors));
        }
        while (list.size() > 1) {
            std::vector<Gladiator> newList = {};
            for (int i = 0; i < list.size(); i += 2) {
                newList.emplace_back(list[i].match(list[i + 1]));
            }
            list = newList;
        }
        double rock, paper, scissors;
        std::cin >> rock >> paper >> scissors;
        std::cout << lround(1000000.0 * list[0].computeChance({ rock, paper, scissors })) << std::endl;
    }
}
