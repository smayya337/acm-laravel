import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class spawn {

    public static void main(String[] args) {
        int w = 0, h = 0;
        Scanner keyboard = new Scanner(System.in);
        while (keyboard.hasNext()) {
            w = keyboard.nextInt();
            h = keyboard.nextInt();
            if(w==0 && h==0)
                break;
            char[][] mirkwood = new char[h][w];
            Queue<Integer> spiders = new LinkedList<Integer>();
            keyboard.nextLine();
            for (int i = 0; i < h; i++) {
                mirkwood[i] = keyboard.nextLine().toCharArray();
                for (int j = 0; j < w; j++) {
                    if (mirkwood[i][j] == 'S')
                        spiders.add(i * w + j);
                }
            }
            while (!spiders.isEmpty()) {
                int pos = spiders.poll();
                int y = pos / w;
                int x = pos % w;
                if (x > 0 && mirkwood[y][x - 1] == 'T') {
                    mirkwood[y][x - 1] = 'S';
                    spiders.add(y * w + x - 1);
                }
                if (y > 0 && mirkwood[y - 1][x] == 'T') {
                    mirkwood[y - 1][x] = 'S';
                    spiders.add((y - 1) * w + x);
                }
                if (y < (h - 1) && mirkwood[y + 1][x] == 'T') {
                    mirkwood[y + 1][x] = 'S';
                    spiders.add((y + 1) * w + x);
                }
                if (x < (w - 1) && mirkwood[y][x + 1] == 'T') {
                    mirkwood[y][x + 1] = 'S';
                    spiders.add(y * w + x + 1);
                }
            }
            for (int i = 0; i < h; i++) {
                System.out.println(mirkwood[i]);
            }
        }
        keyboard.close();
    }
}
