import java.util.*;

public class armory {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int testcases = in.nextInt();
        for (int i = 0; i < testcases; ++i) {
            Testcase test = new Testcase(in);
            int result = match(test);
            System.out.println(result);
        }
    }

    private static int match(Testcase test) {
        final List<WeaponPair> orderedW = test.weapons;
        Collections.sort(orderedW);
        List<String> soldiers = test.preferences;
        Collections.sort(soldiers, new Comparator<String>() {
            public int compare(String s1, String s2) {
                int index = 0;
                while(index < s2.length() && (s1.charAt(index) == s2.charAt(index))) {
                    ++index;
                }
                if (index >= s2.length()) {
                    return 0;
                }
                int s1i = 0;
                int s2i = 0;
                for(int i = 0; i < orderedW.size(); ++i) {
                    if (orderedW.get(i).weaponType.equals(s1.substring(index, index + 1))) {
                        s1i = i;
                    } else if (orderedW.get(i).weaponType.equals(s2.substring(index, index + 1))) {
                        s2i = i;
                    }
                }
                if(s1i > s2i) {
                    return 1;
                } else {
                    return -1;
                }
            }
        });
        int penalty = 0;
        for(String soldier : soldiers) {
            int cost = -1;
            for (int i = 0; i < soldier.length(); ++i) {
                for (int j = 0; j < orderedW.size(); ++j) {
                    if(soldier.substring(i, i+1).equals(orderedW.get(j).weaponType)) {
                        if(orderedW.get(j).weaponCount > 0) {
                            cost = i;
                            orderedW.get(j).takeWeapon();
                        }
                    }
                }
                if (cost > -1) {
                    penalty += cost;
                    break;
                }
            }
        }
        return penalty;
    }

    private static class Testcase {
        public List<WeaponPair> weapons;
        public List<String> preferences;

        public Testcase(Scanner in) {
            int numWeapons = in.nextInt();
            int numSoldiers = in.nextInt();
            weapons = new ArrayList<WeaponPair>(numWeapons);
            preferences = new ArrayList<String>();
            for (int i = 0; i < numWeapons; ++i) {
                String weapon = in.next();
                int num = in.nextInt();
                weapons.add(new WeaponPair(weapon, num));
            }
            for (int i = 0; i < numSoldiers; ++i) {
                String preference = in.next();
                preferences.add(preference);
            }
        }
    }

    private static class WeaponPair implements Comparable<WeaponPair> {
        public String weaponType;
        public int weaponCount;
        public WeaponPair(String type, int count) {
            weaponType = type;
            weaponCount = count;
        }

        @Override
        public int compareTo(WeaponPair w) {
            if (weaponCount < w.weaponCount) {
                return -1;
            } else if (weaponCount > w.weaponCount) {
                return 1;
            }
            return 0;
        }

        public void takeWeapon() {
            --weaponCount;
        }
    }
}