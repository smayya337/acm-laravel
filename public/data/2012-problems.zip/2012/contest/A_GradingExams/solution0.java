import java.util.Scanner;

public class solution2 {

	public static void main(String[] args) {
    	int numProblems;
    	Scanner in = new Scanner(System.in);
    	numProblems = in.nextInt();

    	for (int p = 1; p <= numProblems; p++) {
        	int numChars;
        	numChars = in.nextInt();
        	String answersGiven = in.next();
        	String answerKey = in.next();
        	int distance = 0;

        	for (int c = 0; c < numChars; c++) {
            	if (answersGiven.charAt(c) != answerKey.charAt(c)) {
                	distance++;
            	}
        	}
        	System.out.print("Case " + p + ":" + " " + distance + "\n");
    	}
	}
    
    
}
