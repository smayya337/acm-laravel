import java.util.Scanner;

public class Gradabase {

    public static void main (String[] args) 
    {
        Scanner s = new Scanner(System.in);
        
        int n = s.nextInt();
	//iterate over cases
        for (int i = 0; i < n; i++)
        {
            System.out.println("Case " + (i+1) + ":");

	    //iterate over students
            int m = s.nextInt();
            for (int j = 0; j < m; j++)
            {
                int currGrade = s.nextInt();
                int nextGrade = currGrade + 1;//increment
                if (nextGrade <= 6)//print if not graduated
                {
                    System.out.println(nextGrade);
                }
            }
        }
    }

}

