#Python solution to ratatouille
#Marina Sanusi, 2018
# made to fail by Andrew for testing purposes

import sys

n = int(sys.stdin.readline())

for case in range(n):
    ingredients = {}

    firstline = sys.stdin.readline().strip().split()
    I = int(firstline[0])
    R = int(firstline[1])

    for i in range(I):
      ingredient = sys.stdin.readline().strip().split() 

      if ingredient[1] in ingredients:
        ingredients[ingredient[1]] += int(ingredient[0])
      else:
        ingredients[ingredient[1]] = int(ingredient[0])

    print ("Case " + str(case+1) + ":")
    for r in range(R):
      recipe = {}
      can_make = True
      num_ing = int(sys.stdin.readline().strip())

      for ni in range(num_ing):
        ingredient = sys.stdin.readline().strip().split() 
        recipe[ingredient[1]] = int(ingredient[0])

        if not ingredient[1] in ingredients or ingredients[ingredient[1]]-int(ingredient[0]) < 0:
          can_make = False

      # The mistake: 
      for ingredient in recipe:
        ingredients[ingredient] = ingredients.get(ingredient, 0) - recipe[ingredient]

      if can_make:
        print("Yes")
      else:
        print("No")


