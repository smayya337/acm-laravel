#include <iostream>
using namespace std;

int main() {
    int testCases;
    cin >> testCases;
    for(int i = 0; i < testCases; i++) {
        int echos;
        cin >> echos;
        string line;
        getline(cin,line); // eat the end of the line that the number was on
        getline(cin,line); // read the line into line
        for(int j = 0; j < echos; j++) {
            cout << line << endl;
        }
    }
    return 0;
}
