#include <cstdio>
#include <cmath>
#include <iostream>
using namespace std;

int main() {
    int t;
    cin >> t;

    for(int itr = 0; itr < t; itr++) {
        int n, m, p;
        cin >> m >> n >> p;

        int *costs = new int[m];
        int *orders = new int[m];

        // Get the costs of each item.
        for(int i = 0; i < m; i++) {
            cin >> costs[i];
            orders[i] = 0;
        }

        // Determine how much each thing is ordered.
        for(int i = 0; i < n; i++) {
            int order;
            cin >> order;

            orders[order-1]++;
        }

        // Take the dot product.
        int total = 0;
        for(int i = 0; i < m; i++) {
            total += costs[i]*orders[i];
        }

        // Add in the tip.
        total += (int)ceil(total*p*1.0/100);

        printf("Case %d: $%d.%02d\n", itr+1, total/100, total%100);
    }
}
