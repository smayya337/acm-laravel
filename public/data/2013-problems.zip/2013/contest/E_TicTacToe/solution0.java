import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class SolveTicTacToe {
	public static void main(String[] args) throws FileNotFoundException{
		Scanner scan = new  Scanner(System.in);
		int numberGames = scan.nextInt();
		//read in the number of games
		//iterate through the games
		for(int game=1; game <= numberGames; game++){
			//for each game:
			//read the board into a 2D array
			//read my character
			//find the two instances of my character, find the relationship between them
			//place the last character
			//print out the board
			char[][] board = new char[][]{
					{'-','-','-'},
					{'-','-','-'},
					{'-','-','-'}
				};
			for(int i = 0; i < 3; i++){
					board[i] = scan.next().toCharArray();
			}
			char myChar = scan.next().toCharArray()[0];
			
			//find the instances of myChar in the board
			int firstCharx = -1, secondCharx = -1, firstChary = -1, secondChary = -1;
			for(int x = 0; x < 3; x++){
				for(int y = 0; y<3; y++){
					if(board[x][y] == myChar){
						if(firstCharx == -1){
							firstCharx = x;
							firstChary = y;
						}else{
							secondCharx = x;
							secondChary = y;
						}
					}
				}
			}
			int thirdCharx, thirdChary;
			//figure out where the last move goes
			if(firstCharx == secondCharx){
				//then the three characters all lie in the same x plane
				thirdCharx = firstCharx;
			}else{
				//if they don't equal, then the x values are on the diagonal, none of them will be equal
				if(firstCharx != 0 && secondCharx != 0){
					thirdCharx = 0;
				}else if(firstCharx != 1 && secondCharx != 1){
					thirdCharx = 1;
				}else{
					thirdCharx = 2;
				}
			}
			if(firstChary == secondChary){
				//then the three characters all lie in the same x plane
				thirdChary = firstChary;
			}else{
				//if they don't equal, then the x values are on the diagonal, none of them will be equal
				if(firstChary != 0 && secondChary != 0){
					thirdChary = 0;
				}else if(firstChary != 1 && secondChary != 1){
					thirdChary = 1;
				}else{
					thirdChary = 2;
				}
			}
			board[thirdCharx][thirdChary] = myChar;

			//output the solved board			
			System.out.println("Case " + game + ":");
			System.out.println(board[0][0] + "" + board[0][1] + "" + board[0][2]);
			System.out.println(board[1][0] + "" + board[1][1] + "" + board[1][2]);
			System.out.println(board[2][0] + "" + board[2][1] + "" + board[2][2]);
		}
	}
}
