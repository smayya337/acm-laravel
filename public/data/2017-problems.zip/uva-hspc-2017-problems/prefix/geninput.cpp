#include <iostream>
#include <string>
#include <cstdlib>
#include <sstream>
using namespace std;
#define N 100
#define SEED 4
char chars[52];

string str_of_len(unsigned int len) {
  stringstream str;
  for ( unsigned int i = 0; i < len; i++ )
    str << chars[rand()%52];
  return str.str();
}

int main() {
  cout << N << endl;
  for ( unsigned int i = 0; i < 26; i++ ) {
    chars[i] = 'A'+i;
    chars[i+26] = 'a'+i;
  }
  // special cases (4)
  cout << "1\nHSPC\n";
  cout << "6\nMario\nMarina\nMartin\nMary\nMarth\nMarcus\n";
  cout << "8\nMario\nMarina\nMartin\nMary\nMarth\nMarcus\nMatthew\nMakefile\n";
  cout << "9\nMario\nMarina\nMartin\nMary\nMarth\nMarcus\nMatthew\nMakefile\nHSPC\n";
  // random cases
  srand(SEED);
  for ( unsigned int i = 4; i < N; i++ ) {
    unsigned int size = rand() % 10;
    string prefix = str_of_len(size);
    cerr << prefix << endl;
    unsigned int count = rand() % 50 + 1;
    if ( i > N-3 )
      count = 1000;
    cout << count << endl;
    for ( unsigned int j = 0; j < count; j++ ) {
      unsigned int slen = rand()%10;
      if ( (size == 0) && (slen == 0) )
	slen = 1;
      cout << prefix << str_of_len(slen) << endl;
    }
  }
  return 0;
}
