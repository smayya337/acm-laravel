// Solution to "Cost of Going Up" from the 2018 HSPC
// Solution by Alyson Irizarry, 2018

import java.util.*;

class goingup {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int nCases = input.nextInt();
        input.nextLine();
        
        //iterate over each case
        for (int i = 0; i < nCases; i++) {
            String[] line = input.nextLine().trim().split(" ");
            int balloons_needed = Integer.parseInt(line[0]);
            int ballons_per_pack = Integer.parseInt(line[1]);
            int packs_needed = balloons_needed / ballons_per_pack;
            if (balloons_needed % ballons_per_pack != 0){
                packs_needed += 1;
            }

            System.out.println(packs_needed);
        }
    }

}
