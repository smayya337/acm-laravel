/**
* Solver: Daniel Epstein
*/

import java.io.*;
import java.util.*;

public class solution3 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int numCases = in.nextInt();
		for(int aaa=1;aaa<=numCases;aaa++) {
			int N = in.nextInt();
			char[][] buffer = new char[N][N];
			for(int i=0;i<N;i++)
				for(int j=0;j<N;j++)
					buffer[i][j] = '.';
			int M = in.nextInt();
			for(int q=0;q<M;q++) {
				String type = in.next();
				int X, Y, W, H;
				X = in.nextInt();
				Y = in.nextInt();
				W = in.nextInt();
				H = in.nextInt();
				char color = in.next().charAt(0);
				if(type.equals("Filled")) {
					for(int i=X-1;i<X-1+W;i++)
						for(int j=Y-1;j<Y-1+H;j++)
							buffer[i][j] = color;
				} else {
					for(int i=X-1;i<X-1+W;i++) {
						buffer[i][Y-1] = color;
						buffer[i][Y-2+H] = color;
					}
					for(int j=Y-1;j<Y-1+H;j++) {
						buffer[X-1][j] = color;
						buffer[X-2+W][j] = color;
					}
				}
			}
			System.out.println("Case " + aaa + ":");
			for(int j=N-1;j>=0;j--) {
				for(int i=0;i<N;i++)
					System.out.print(buffer[i][j]);
				System.out.println();
			}
		}
	}
}
