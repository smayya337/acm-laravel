import java.util.*;
import java.text.*;
public class InterestChris
{
	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
		double m1 = in.nextDouble();
		double m2;
		double m3;
		int n;
		while(m1 > 0)
		{
			m2 = in.nextDouble();
			m3  = in.nextDouble();
			n = in.nextInt();
			double a;
			double b;
			double c;
			double d;
			a = m1;
			b = m2;
			c = m3;
			if(n > 3)
			{
				for(int i = 3; i < n; i++)
				{
					d = c;
					c = b*a/c;
					a = b;
					b = d;
					c = Math.round(100.0*c)/100.0;
					
				}
			}
			NumberFormat format = NumberFormat.getInstance();
			format.setMinimumFractionDigits(2);
			format.setMaximumFractionDigits(2);
			format.setGroupingUsed(true);
			if(n == 1)
				System.out.println("Month " + n + " cost: $" + format.format(m1));
			if(n == 2)
				System.out.println("Month " + n + " cost: $" + format.format(m2));
			if(n == 3)
				System.out.println("Month " + n + " cost: $" + format.format(m3));
			if(n > 3)
				System.out.println("Month " + n + " cost: $" + format.format(c));
			m1 = in.nextDouble();	
		}
	}
}
