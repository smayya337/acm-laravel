#include <stdio.h>
#include <stdlib.h>

int main() {
	int i;
	int ncases;
	scanf(" %i ",&ncases);
	for(i=0;i<ncases;i++) {
		int ncrepes;
		int j;
		scanf(" %i ",&ncrepes);
		int color[ncrepes];
		int x[ncrepes];
		int y[ncrepes];
		int r[ncrepes];
		for(j=0;j<ncrepes;j++) {
			color[j] = j;
			int k;
			scanf(" %i %i %i ",&x[j], &y[j], &r[j]);
			for(k=0;k<j;k++) {
				// now we're going to look and see if we intersect any crepes that we already laid down
				double distsq = (x[j]-(double)x[k])*(x[j]-x[k]) + (y[j]-(double)y[k])*(y[j]-y[k]);
				double rsumsq = (r[j] + (double)r[k])*(r[j]+r[k]);
				if(rsumsq >= distsq) {
					//if we _do_ intersect a crepe, color it and everything that shares its color with our color
					if(color[k] != j) {
						int op = color[k];
						int m;
						for(m=0;m<j;m++) {
							if(color[m] == op) {
								color[m] = j;
							}
						}
					}
				}
			}
		}
		int colorsused[ncrepes];
		for(j=0;j<ncrepes;j++) {
			colorsused[j] = 0;
		}
		for(j=0;j<ncrepes;j++) {
			colorsused[color[j]]++;
		}
		int ncolorsused = 0;
		for(j=0;j<ncrepes;j++) {
			if(colorsused[j] != 0) {
				ncolorsused++;
			}
		}
		printf("Case %i: %i\n",(i+1),ncolorsused);
	}
}
