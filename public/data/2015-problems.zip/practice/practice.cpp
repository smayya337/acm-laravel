#include <iostream>
using namespace std;
int main() {
    int n, i;
    cin >> n;
    while ( n-- > 0 ) {
        cin >> i;
        cout << i*(i+1)/2 << endl;
    }
    return 0;
}
