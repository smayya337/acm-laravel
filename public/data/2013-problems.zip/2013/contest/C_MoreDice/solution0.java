
import java.util.Scanner;

public class HarderDice {
	public static void main(String[] args) {
		int numDice = 2;
		Scanner in = new Scanner(System.in);

		//iterate over cases
		int numTests = in.nextInt();
		for (int i = 0; i < numTests; i++)
		{
			System.out.println("Case " + (i+1) + ":");
			//call recursive dice solver
			diceSolver(numDice, in.nextInt(), "(", 1);
		}
	}
	
	public static void diceSolver(int dice, int sum, String str, int min)
	{
	    if (dice == 1)//base case
		{
		    if (sum >= min)
			{
			    //output buffered string
			    System.out.println(str + sum + ")");				
			}
		}
		else
		{
		    dice--;//make recursive call
			for (int i = min; i < 7; i++)
			{
			    //simplify case before recursing
				if (sum-i >= dice && (sum-i)/dice <= 6)
				{
					diceSolver(dice, sum-i, str+i+",", i);
				}
			}
		}
	}

}
