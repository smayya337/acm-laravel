# Solution to "N Queens" (ants) for HSPC 2018 @ UVA
# By Roman Bohuk, 2018

import sys

n = int(sys.stdin.readline())

def f(n):
    if n==0 or n==1: return n
    return n + 5*n*f(n//2)

for i in range(n):
    print(f(int(sys.stdin.readline())))


