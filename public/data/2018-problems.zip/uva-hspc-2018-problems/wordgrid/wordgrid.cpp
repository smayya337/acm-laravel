/*
 * C++ solution to wordgrid
 *
 * by Aaron Bloomfield, 2018
 */

#include <iostream>
#include <string>
using namespace std;

char grid[100][100];
string dirs[] = { "n", "ne", "e", "se", "s", "sw", "w", "nw" };

bool foundWordInGrid (int x, int y, int w, int h, int d, string s) {
  string result;
  int l = 0;
  //cout << "\t at (" << x << "," << y << "): ";
  while ( l < s.length() ) {
    if ( (x < 0) || (y < 0) || (x >= w) || (y >= h) )
      break;
    result += grid[x][y];
    switch (d) {
    case 0: y--; break; // n
    case 1: y--; x++; break; // ne
    case 2: x++; break; // e
    case 3: x++; y++; break; // se
    case 4: y++; break; // s
    case 5: y++; x--; break; // sw
    case 6: x--; break; // w
    case 7: x--; y--; break; // nw
    }
    if ( result.length() == s.length() )
      break;
  }
  //cout << "comparing '" << result << "' and '" << s << "' in dir " << dirs[d] << endl;
  return result == s;
}

int main() {
  int h, w, n;
  string s;

  cin >> n;
  for ( int i = 0; i < n; i++ ) {
    // read in grid and word
    cin >> w >> h;
    for ( int y = 0; y < h; y++ )
      for ( int x = 0; x < w; x++ )
	cin >> grid[x][y];
    cin >> s;
    // search for word
    bool found = false;
    for ( int x = 0; x < w; x++ )
      for ( int y = 0; y < h; y++ )
	for ( int d = 0; d < 8; d++ )
	  if ( foundWordInGrid(x, y, w, h, d, s) ) {
	    found = true;
	    //cout << "Case " << (i+1) << ": " << x << " " << y << " " << dirs[d] << endl;
	    cout << x << " " << y << " " << dirs[d] << endl;
	  }
    if ( !found )
      //cout << "Case " << (i+1) << ": not found" << endl;
      cout << "not found" << endl;
  }
  return 0;
}
