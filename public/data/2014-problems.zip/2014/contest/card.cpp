#include <iostream>
using namespace std;
int main() {
    int g, x;
    string n;
    cin >> x;
    for ( int i = 0; i < x; i++ ) {
        cin >> n >> g;
        if ( g <= 59 )
            cout << n << " F" << endl;
        else if ( g <= 66 )
            cout << n << " D" << endl;
        else if ( g <= 69 )
            cout << n << " D+" << endl;
        else if ( g <= 76 )
            cout << n << " C" << endl;
        else if ( g <= 79 )
            cout << n << " C+" << endl;
        else if ( g <= 86 )
            cout << n << " B" << endl;
        else if ( g <= 89 )
            cout << n << " B+" << endl;
        else if ( g <= 96 )
            cout << n << " A" << endl;
        else
            cout << n << " A+" << endl;
    }
    return 0;
}
