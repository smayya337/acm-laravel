#include <iostream>
#include <algorithm>
#include <vector>
#include <string>

using namespace std;

struct weapon {
    string name;
    int count;
};

vector<weapon> sortedWeapons;

class Testcase {
public:
    vector<weapon> weapons;
    vector<string> soldiers;
    Testcase();
    void sortSoldiers();
    void sortWeapons();
private:
};

Testcase::Testcase() {
    int numWeapons, numSoldiers;
    cin >> numWeapons;
    cin >> numSoldiers;
    string preference;
    weapon temp;
    for (int i = 0; i < numWeapons; ++i) {
        cin >> temp.name;
        cin >> temp.count;
        weapons.push_back(temp);
    }
    for (int i = 0; i < numSoldiers; ++i) {
        cin >> preference;
        soldiers.push_back(preference);
    }
}

bool compareWeapon(weapon w1, weapon w2) {
    return w1.count < w2.count;
}
void Testcase::sortWeapons() {
    sort(weapons.begin(), weapons.end(), compareWeapon);
    sortedWeapons = weapons;
}

bool compareSoldiers(string s1, string s2) {
    int index = 0;
    while(index < s2.length() && (s1[index] == s2[index])) {
        ++index;
    }
    if (index >= s2.length()) {
        return true;
    }
    int s1i = 0;
    int s2i = 0;
    for(int i = 0; i < sortedWeapons.size(); ++i) {
        if (sortedWeapons[i].name.compare(s1.substr(index, 1)) == 0) {
            s1i = i;
        } else if (sortedWeapons[i].name.compare(s2.substr(index, 1)) == 0) {
            s2i = i;
        }
    }
    if(s1i > s2i) {
        return 1;
    } else {
        return -1;
    }
}

void Testcase::sortSoldiers() {
    sort(soldiers.begin(), soldiers.end(), compareSoldiers);
}

void takeWeapon(weapon &w) {
    --w.count;
}

int match(Testcase * test) {
    test->sortWeapons();
    vector<weapon> orderedW(test->weapons);
    test->sortSoldiers();
    vector<string> soldiers(test->soldiers);
    int penalty = 0;
    for (int x = 0; x < soldiers.size(); ++x) {
        string soldier = soldiers[x];
        int cost = -1;
        for (int i = 0; i < soldier.size(); ++i) {
            for (int j = 0; j < orderedW.size(); ++j) {
                if(soldier.substr(i, 1).compare(orderedW[j].name) == 0) {
                    if(orderedW[j].count > 0) {
                        cost = i;
                        takeWeapon(orderedW[j]);
                    }
                }
            }
            if (cost > -1) {
                penalty += cost;
                break;
            }
        }
    }
    return penalty;
}

int main(void) {
    int testcases;
    cin >> testcases;
    for (int i = 0; i < testcases; ++i) {
        Testcase test;
        int result = match(&test);
        cout << result << endl;
    }
}