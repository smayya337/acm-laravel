import java.util.Scanner;


public class Strings {

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int n = s.nextInt();
        s.nextLine(); // eat up the newline on the previous line

        for ( int i = 0; i < n; i++ ) {
            String str = s.nextLine();
            System.out.println(reverse(str, true));
        }
    }

    public static String reverse(String str, boolean actuallyReverse) {
        int firstIndex = str.indexOf("\"");
        int lastIndex = str.lastIndexOf("\"");

        if (firstIndex != -1 && firstIndex != lastIndex) {
            String a = str.substring(0, firstIndex);
            int aL = a.length();
            String b = str.substring(lastIndex + 1);
            int bL = b.length();

            String rev;
            if (actuallyReverse) {
                rev = (new StringBuilder(b).reverse().toString()) + (new StringBuilder(a).reverse().toString());
            } else {
                rev = a + b;
            }

            return rev.substring(0, aL) + "\"" + reverse(str.substring(firstIndex + 1, lastIndex), !actuallyReverse) + "\"" + rev.substring(aL);
        } else {
            // No more quotes, just return.
            return actuallyReverse ? (new StringBuilder(str).reverse().toString()) : str;
        }
    }
}
