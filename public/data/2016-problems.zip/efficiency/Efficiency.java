import java.util.*;

/*
 * Since x velocity (and thus the x contribution to energy) is constant,
 * we are trying to minimize the y velocity of the obejct when it lands.
 * Thus, there are only two cases:
 *    y_0 > 0:
 *      In this case, we want to launch the projectile up so the apex of its 
 *      parabolic arc is at the target location (so v_y at that time is 0).
 *    y_0 <= 0:
 *      In this case, we want to launch the projectile horizontally (so we
 *      do not contribute any more than we must to v_y) with the minimum required
 *      force to get the projectile x_0 units away before it falls past y_0.
 */
public class Efficiency {
  private static final double gravity = 9.81; //m/s^2
  
  public static void main(String[] args) {
    Scanner cin = new Scanner(System.in);

    int testCases = cin.nextInt();

    for (int i = 0; i < testCases; i++) {
      double mass    = cin.nextDouble();
      double targetX = cin.nextDouble(), targetY = cin.nextDouble();
    
      double theta, v;
      if (targetY > 0) {
        // We need a parabola that can reach a total height of targetY.
        // v_y^2 = v_{0y}^2 - 2g(y-y0)
        // 0 = v_{0y}^2 - 2g(targetY)
        // v_0y = sqrt(2g*targetY)
        double v0y = Math.sqrt(2*gravity*targetY);

        // Time for object to reach zero vertical velocity:
        // v_y = -gt + v_0y
        // gt = v_0y --> t = v_0y/(*g)
        double t   = v0y / gravity;
        double v0x = targetX / t;

        theta = (180 / Math.PI) * Math.atan2(v0y, v0x);
        v     = Math.hypot(v0y, v0x);
      }
      else {
        // Solving kinematic equation for time
        // 0 = -1/2 gt^2 - targetY
        // so... t = sqrt(-2targetY/(g))
        // This is ok since targetY <= 0
        // (Time for object to fall targetY meters)
        double t   = Math.sqrt(-2*targetY / gravity);
        double v0x = targetX / t;

        theta = 0;
        v     = v0x;
      }


      System.out.printf("Case %d: %.2f %.2f\n", i+1, v, theta);

    }

  }


}
