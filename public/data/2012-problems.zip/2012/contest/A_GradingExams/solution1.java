/**
*Grading Exams
*Chris Cunningham (clc3bn)
*/

import java.util.*;

public class solution3
{
	public static void main(String[] args)
	{
		new solution3();
	}
	
	public solution3()
	{
		Scanner in = new Scanner(System.in);
		int testCases = in.nextInt();
		for(int tcase = 1; tcase <= testCases; tcase++)
		{
			int L = in.nextInt();
			String key = in.next();
			String stud = in.next();
			int counter = 0;
			for(int i = 0; i < L; i++)
				if(key.charAt(i) != stud.charAt(i))
					counter++;
			System.out.println("Case " + tcase + ": " + counter);
		}
		
		
	}
}
