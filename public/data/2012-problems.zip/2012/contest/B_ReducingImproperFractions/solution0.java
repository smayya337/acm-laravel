/**
*Reducing Improper Fractions
*Chris Cunningham (clc3bn)
*/

import java.util.*;

public class solution3
{
	public static void main(String[] args)
	{
		new solution3();
	}
	
	public solution3()
	{
		Scanner in = new Scanner(System.in);
		int numCases = in.nextInt();
		for(int aaa=1;aaa<=numCases;aaa++)
		{
			int N = in.nextInt();
			int D = in.nextInt();
			System.out.print("Case " + aaa + ": ");
			if(N > D && N%D != 0)
				System.out.println((N/D) + " " + (N%D) + "/" + D);
			else if(N>D)
				System.out.println((N/D));
			else if(N<=D && N%D != 0)
				System.out.println((N%D) + "/" + D);
			else System.out.println(0);
		}

	}
}
