import java.util.*;

public class Trees {
    public static void main(String args[]) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        for ( int j = 0; j < n; j++ ) {
            int v = in.nextInt();
            int[] prefix = new int[v];
            int[] infix = new int[v];
            for (int i=0; i<v; i++)
                prefix[i] = in.nextInt();
            for (int i=0; i<v; i++)
                infix[i] = in.nextInt();
            TreeNode root = getSubtree(prefix, 0, v, infix, 0, v);
            String str = sprintPostfix(root);
            System.out.println(str.trim());
        }
    }

    public static String sprintPostfix(TreeNode node) {
        if (node == null) return "";
        return sprintPostfix(node.left) + sprintPostfix(node.right) + node.value + " ";
    }

    public static TreeNode getSubtree(int[] prefix, int ps, int pe, int[] infix, int is, int ie) {
        // base case
        if (pe <= ps) return null;

        // Root node is in start of prefix section
        int val = prefix[ps];
        TreeNode node = new TreeNode(val);
        // Get where in the infix section it is.
        int ind = -1;
        for (int i=is; i<ie; i++) {
            if (infix[i] == val) {
                ind = i;
                break;
            }
        }

        int leftn = ind - is;
        int rightn = ie - ind;
        TreeNode left = getSubtree(prefix, ps+1, ps+1+leftn, infix, is, ind);
        TreeNode right = getSubtree(prefix, ps+1+leftn, pe, infix, ind+1, ie);
        node.left = left;
        node.right = right;
        return node;

    }
}

class TreeNode {
    public int value;
    public TreeNode left;
    public TreeNode right;
    public TreeNode(int value) {
        this.value = value;
    }
}
