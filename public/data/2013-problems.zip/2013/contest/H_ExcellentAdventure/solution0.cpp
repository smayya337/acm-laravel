// Bloomfield's excellent adventure solution, 3-12-13
#include <iostream>
#include <string>
#include <vector>
#include <limits.h>

using namespace std;

struct fun {
  string city;
  int fun;
};

struct road {
  string from;
  string to;
  int dist;
};

vector<fun> funs;
vector<road> roads;
vector<string> itinerary;
string destination;
string itinerary_string;
int itinerary_fun;

//lookup the fun amount for a city
int getfun (string city) {
  for ( vector<fun>::iterator it = funs.begin(); it != funs.end(); it++ )
    if ( (*it).city == city )
      return (*it).fun;
  return 0;
}

//check if a city has been visited
bool already_visited (string city) {
  for ( vector<string>::iterator it = itinerary.begin(); it != itinerary.end(); it++ )
    if ( *it == city )
      return true;
  return false;
}

//recursively generate solutions
void recursion (int distance, int fun) { // yes, this is brute force.
  // are we out of gas?
  if ( distance < 0 )
    return;
  // are we at the destination city?
  if ( itinerary[itinerary.size()-1] == destination )
    if ( fun > itinerary_fun ) {
      itinerary_string = "";
      for ( vector<string>::iterator it = itinerary.begin(); it != itinerary.end(); it++ )
	itinerary_string += " " + *it;
      itinerary_fun = fun;
    }
  // either way, consider all outgoing paths
  string current_city = itinerary[itinerary.size()-1];
  itinerary.reserve(itinerary.size()+1);
  for ( vector<road>::iterator it = roads.begin(); it != roads.end(); it++ )
    if ( current_city == (*it).from ) {
      int newfun = fun + ((already_visited((*it).to))?0:getfun((*it).to));
      itinerary.push_back((*it).to);
      recursion(distance-((*it).dist), newfun);
      itinerary.pop_back();
    }
}

int main() {
  int n, x;
  string s, t;

  // read fun locations
  cin >> n;
  for ( int i = 0; i < n; i++ ) {
    cin >> s;
    cin >> x;
    fun f{s,x}; // C++11 initialization syntax; throws a warning
    funs.push_back(f);
  }

  // read roads
  cin >> n;
  for ( int i = 0; i < n; i++ ) {
    cin >> s;
    cin >> t;
    cin >> x;
    road r1{s,t,x}; // C++11 initialization syntax; throws a warning
    roads.push_back(r1);
    road r2{t,s,x}; // C++11 initialization syntax; throws a warning
    roads.push_back(r2);
  }

  // read trips
  cin >> n;
  for ( int i = 1; i <= n; i++ ) {
    string start;
    cin >> start;
    itinerary.clear();
    itinerary_fun = INT_MIN;
    itinerary.push_back(start);
    cin >> destination;
    int dist;
    cin >> dist;
    recursion(dist,getfun(start));
    if ( itinerary_fun == INT_MIN )
      cout << "Case " << i << ": Not possible" << endl;
    else
      cout << "Case " << i << ":" << itinerary_string << " " << itinerary_fun << endl;
  }
}
