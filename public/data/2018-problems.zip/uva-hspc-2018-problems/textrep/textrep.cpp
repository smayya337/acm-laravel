/*
 * C++ solution to textrep
 *
 * by Aaron Bloomfield, 2018
 */

#include <iostream>
#include <string>
using namespace std;

int main() {
  int n, c;
  cin >> n;
  for ( int i = 0; i < n; i++ ) {
    cin >> c;
    for ( int j = 0; j < c; j++ ) {
      string word;
      cin >> word;
      if ( word == "bing" )
	cout << "bong ";
      else if ( word == "Bing" )
	cout << "Bong ";
      else if ( word == "BING" )
	cout << "BONG ";
      else
	cout << word << " ";
    }
    cout << endl;
  }
  return 0;
}
