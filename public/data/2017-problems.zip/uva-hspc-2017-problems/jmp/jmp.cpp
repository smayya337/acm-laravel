// Solves "Jmp Mario" from the 2017 HSPC at UVa
// Solution by Aaron Bloomfield, 2017

#include <iostream>
#include <sstream>
using namespace std;
int main() {
  int n, s, p, c;
  cin >> n;
  for ( int i = 0; i < n; i++ ) {
    cout << "Case " << (i+1) << ":";
    stringstream str;
    cin >> s >> p;
    s--;
    bool bad = false;
    for ( ; s > 0; s-- ) {
      cin >> c;
      if ( p >= c )
	str << " run";
      else if ( p+1 == c )
	str << " jump";
      else if ( p+2 == c )
	str << " double jump";
      else
	bad = true;
      p = c;
    }
    if ( bad )
      cout << " not traversable" << endl;
    else
      cout << str.str() << endl;
  }
  return 0;
}
