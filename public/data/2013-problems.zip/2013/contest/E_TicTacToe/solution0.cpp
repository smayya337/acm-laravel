// Bloomfield's tic-tac-toe solution, 3-11-13
#include <iostream>
#include <string>
using namespace std;

//checks if setting a certain spot would mean victory
bool winningboard (char b[3][3], char which, int row, int col) {
  char board[3][3];
  for ( int i = 0; i < 3; i++ )
    for ( int j = 0; j < 3; j++ )
      board[i][j] = b[i][j];
  board[row][col] = which;
  for ( int r = 0; r < 3; r++ )
    if ( (board[r][0] == which) && (board[r][1] == which) && (board[r][2] == which) )
      return true;
  for ( int c = 0; c < 3; c++ )
    if ( (board[0][c] == which) && (board[1][c] == which) && (board[2][c] == which) )
      return true;
  if ( (board[0][0] == which) && (board[1][1] == which) && (board[2][2] == which) )
    return true;
  if ( (board[0][2] == which) && (board[1][1] == which) && (board[2][0] == which) )
    return true;
  return false;
}

//print the board as a solution
void outputboard(char board[3][3], int c) {
  cout << "Case " << c << ":" << endl;
  for ( int r = 0; r < 3; r++ ) {
    for ( int c = 0; c < 3; c++ )
      cout << board[r][c];
    cout << endl;
  }
}

int main() {
  int n;
  string s;

  //iterate over cases
  cin >> n;
  for ( int z = 1; z <= n; z++ ) {
    //read in board
    char board[3][3];
    for ( int i = 0; i < 3; i++ ) {
      cin >> s;
      for ( int j = 0; j < 3; j++ )
	board[i][j] = s[j];
    }
    char which;//get the team
    cin >> which;

    //for each spot, check if filling that wins the game
    for ( int r = 0; r < 3; r++ )
      for ( int c = 0; c < 3; c++ )
	if ( winningboard(board,which,r,c) ) {
	  board[r][c] = which;
	  outputboard(board,z);
	  board[r][c] = '-';
	}

  }
}

    
