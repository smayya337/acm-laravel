// Solution to "Inside Out" from the 2018 HSPC
// Solution by Alyson Irizarry, 2018

import java.util.*;

class textrep {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int nCases = input.nextInt();
        input.nextLine();       
        
        //iterate over each case
        for (int i = 0; i < nCases; i++) {
            String[] line = input.nextLine().trim().split(" ");
            int nWords = Integer.parseInt(line[0]);
            //iterate over words
            for (int j = 1; j <= nWords; j++) {
                if(line[j].equals("bing")){
                    System.out.print("bong ");
                } else if (line[j].equals("Bing")) {
                    System.out.print("Bong ");
                } else if (line[j].equals("BING")) {
                    System.out.print("BONG ");
                } else {
                    System.out.print(line[j]+ " ");
                }
            }
            System.out.println();
        }
    }
}