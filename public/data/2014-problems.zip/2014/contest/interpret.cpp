#include <iostream>
#include <map>
#include <vector>
#include <string.h>
#include <sstream>
#include <algorithm>
#include <string>
#include <iterator>
using namespace std;

map<string,int> variables;
map<string,vector<int> > arrays;
map<string,int> labels;
vector<string> commands;

// Get a variable, given a [var] expression
int getvarval(string line) {
    int bracpos = line.find('[');
    if(bracpos != -1) {
        int closepos = line.find_last_of(']');
        return arrays[line.substr(0,bracpos)][getvarval(line.substr(bracpos+1,closepos-bracpos-1))];
    } else if (isdigit(line[0])) {
        char* temp;
        return strtol(line.c_str(),&temp,10);
    } else {
        return variables[line];
    }
}

// Set a variable, given a [var] expression and the value
void setvarval(string line, int val) {
    int bracpos = line.find('[');
    if(bracpos != -1) {
        int closepos = line.find_last_of(']');
        arrays[line.substr(0,bracpos)][getvarval(line.substr(bracpos+1,closepos-bracpos-1))]=val;
    } else if (isdigit(line[0])) {
        //can't set constants!
    } else {
        variables[line]=val;
    }
}

int main() {
    int pos=0;
    // Precompute the label table
    while(true) {
        string line;
        getline(cin,line);
        commands.push_back(line);
        if(line=="END") //reached the end of input
            break;
        //if a label, recognize that
        const char* st = line.c_str();
        if(strstr(st,"sad")==st) {
            istringstream iss(line);
            iss >> line >> line;
            labels[line]=pos;
        }
        pos++;
    }
    pos=0;
    // Step through the commands
    while(true) {
        string line = commands[pos++];
        string line2;
        istringstream iss(line);
        iss >> line;
        if(line=="arth") {
            iss >> line;
            pos=labels[line];
        } else if (line=="pen") {
            iss >> line >> line2;
            if(getvarval(line) < getvarval(line2)) {
                iss >> line;
                pos=labels[line];
            }
        } else if (line=="muindor") {
            iss >> line >> line2;
            if(getvarval(line) == getvarval(line2)) {
                iss >> line;
                pos=labels[line];
            }
        } else if (line=="sad") {
            //Already handled
        } else if (line=="tangado") {
            iss >> line;
            setvarval(line,0);
        } else if (line=="ost") {
            iss >> line >> line2;
            vector<int> newarr(getvarval(line2),0);
            arrays[line] = newarr;
        } else if (line=="teithant") {
            getline(iss,line);
            cout << line.substr(line.find('"')+1,line.find_last_of('"')-line.find('"')-1) << endl;
        } else if (line=="canad") {
            iss >> line;
            cout << getvarval(line) << endl;
        } else if (line=="anno") {
            iss >> line >> line2;
            setvarval(line,getvarval(line2));
        } else if (line=="aderthad") {
            iss >> line >> line2;
            setvarval(line,getvarval(line) + getvarval(line2));
        } else if (line=="adlanna") {
            iss >> line >> line2;
            setvarval(line,getvarval(line) / getvarval(line2));
        } else if (line=="adlegi") {
            iss >> line >> line2;
            setvarval(line,getvarval(line) - getvarval(line2));
        } else if (line=="athrado") {
            iss >> line >> line2;
            setvarval(line,getvarval(line) * getvarval(line2));
        } else if (line=="awarthad") {
            break;
        }
    }
    return 0;
}
