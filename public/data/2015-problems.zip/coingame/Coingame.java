import java.util.*;

class Coingame {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int N = in.nextInt();
        while (N-- != 0) {
            int l = in.nextInt();
            int m = in.nextInt();
            in.nextLine();
            String line = in.nextLine();

            int[] start = parseLine(line, l);
            int[][] mat = new int[l][m+1];
            for (int i=0; i<m; i++) {
                String move = in.nextLine();
                int[] tmp = parseLine(move, l);
                for (int j=0; j<l; j++) mat[j][i] = tmp[j];
            }
            for (int j=0; j<l; j++) mat[j][m] = start[j];

            boolean ans = rowReduceMod2(mat, l, m);
            System.out.println(ans ? "CAN BE SOLVED" : "CANNOT BE SOLVED");
        }
    }

    public static int[] parseLine(String line, int l) {
        int arr[] = new int[l];
        for (int i=0; i<l; i++) {
            if (line.charAt(i) == 'T' || line.charAt(i) == 'F') arr[i] = 1;
            if (line.charAt(i) == 'H' || line.charAt(i) == 'S') arr[i] = 0;
        }
        return arr;
    }

    public static boolean rowReduceMod2(int[][] A, int rows, int cols) {
        boolean ans = true;
        // Gauss elimination
        int x=0, y=0;
        for (; y<cols && x < rows; y++, x++) {
            // Put a 1 in the diagonal if possible
            if (A[x][y] == 0)
                for (int x2=x+1; x2<rows; x2++)
                    if (A[x2][y] == 1) {
                        swapRow(A, x2, x);
                        break;
                    }
            // No pivot
            if (A[x][y] == 0) {
                x--;
                continue;
            }

            for (int x2=x+1; x2<rows; x2++)
                if (A[x2][y] == 1) addRow(A, x2, x);
        }

        // Check that the rest of the rows have 0s in the final term
        // We don't care about any of the other rows because we can
        // eliminate the upper right triangle and just set pivots to
        // the right answer
        for (int i = x; i<rows; i++) {
            if (A[i][cols] == 1) return false;
        }
        return true;

    }

    // A[i] = A[j] and vice versa
    public static void swapRow(int[][] A, int i, int j) {
        int[] tmp = A[i];
        A[i] = A[j];
        A[j] = tmp;
    }

    // A[i] = A[i] + A[j]
    // Note we don't need to multiply ever because mod 2s
    public static void addRow(int[][] A, int i, int j) {
        for (int y=0; y<A[i].length; y++)
            A[i][y] = (A[i][y] + A[j][y])%2;
    }
}
