import java.util.*;
import java.math.BigInteger;
public class IntFlipChris
{
	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
		long a = in.nextLong();
		while(a >= 0)
		{
			BigInteger b = BigInteger.valueOf(a);
			int[] k = new int[32];
			for(int i = 0; i < k.length;i++)
				k[i] = 0;
			int m = b.getLowestSetBit();

			while(m >= 0)
			{
				k[m] = 1;
				b = b.clearBit(m);
				m = b.getLowestSetBit();
			}
			//System.out.print("k");
			//for(int i = 0; i < 32; i++)
			//		System.out.print(k[i]);
			//System.out.println();
			
			for(int i = 0; i < 16; i++)
			{
				int temp = k[31-i];
				k[31-i] = k[i];
				k[i] = temp;
			}
			long total = 0;
			for(int i = 0; i < 32; i++)
				total += k[i]*Math.pow(2,i);
			System.out.println(total);
			
			a = in.nextInt();
		}
	}
}
