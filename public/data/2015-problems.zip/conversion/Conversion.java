import java.text.DecimalFormat;
import java.util.Scanner;

public class Conversion {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int numTrials = Integer.parseInt(s.nextLine());
		DecimalFormat df = new DecimalFormat("0.00");

		for (int i = 0; i < numTrials; ++i) {
			String cur = s.nextLine();
			double val = Double.parseDouble(s.nextLine());

			if (cur.equals("f")) {
				System.out.println(df.format((5.0/9.0)*(val - 32)));
			} else {	// cur is "c"
				System.out.println(df.format((9.0/5.0)*val + 32));
			}
		}

	}
}