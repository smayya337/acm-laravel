UVa HSPC 2017 Problem Set
=========================

The problem set can be found online at
http://acm.cs.virginia.edu/hspc.php.  The directory names herein can
generally be inferred from the problem names; the exception 
is that the "High Scores!" problem is in the prefix/ directory.

Each directory contains:
- sample input and output (*.sample.in/out)
- judging input and output (*.judge.in/out)
- solutions in C++, Java, and Python

Some directories contain a geninput.cpp, which was used to generate
the judging input (when run on an Ubuntu 16.04 64-bit system, it
should -- in theory -- generate the exact same input as the *.judge.in
file).

The puzzle problem does not have a Python solution.  This problem was
adapted from an ICPC problem ("Theta Puzzle" from
http://acmgnyr.org/year2009/problems.shtml).  The problem text and the
input/output specifications remain the same; only the flavor text was
changed.  The solutions that we included are adapted from that
problem.

Typing `make` (or `make verify`) will test each of the problems: both
of the I/O sets (both sample and judging) will be run with each of the
solutions.  Any differences will be printed to the screen, so if you
don't see any output (other than the progress indicators), it means
everything verifies.  On a Ubuntu 16.04 64-bit system, it verifies
properly.
