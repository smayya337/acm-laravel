import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;


public class solution2 {
	public static void main(String[] args) {
		Scanner fin = new Scanner(System.in);
		
		int N = fin.nextInt();
		
		for (int n = 1; n <= N; n++) {
			fin.nextInt();
			int X = fin.nextInt();
			int Y = fin.nextInt();
			
			HashMap<Integer, Node> nodeMap = new HashMap<Integer, Node>();
			
			int M = fin.nextInt();
			for (int m = 0; m < M; m++) {
				int f = fin.nextInt();
				int s = fin.nextInt();
				double w = fin.nextDouble();
				
				Node fNode = nodeMap.get(f);
				if (fNode == null) {
					fNode = new Node(f);
					nodeMap.put(f, fNode);
				}
				
				Node sNode = nodeMap.get(s);
				if (sNode == null) {
					sNode = new Node(s);
					nodeMap.put(s, sNode);
				}
				
				if(fNode.edges.containsKey(s)) {
					Edge e = fNode.edges.get(s);
					e.weight = Math.max(e.weight, w);
				} else {
					fNode.edges.put(s, new Edge(sNode, w));
				}
			}
			
			
			Node start = nodeMap.get(X);
			Node end = nodeMap.get(Y);
			if (start == null || end == null) System.err.println("Error in input.");
			
			start.setDist(1);
			System.out.println("Case " + n + ": " + end.distTo);
		}
	}
}

class Node {
	HashMap<Integer, Edge> edges = new HashMap<Integer, Edge>();
	
	double distTo = 0;
	
	int num;
	public Node(int num) { this.num = num; }
	
	void setDist(double dist) {
		if (this.distTo > dist) return;
		
		this.distTo = dist;
		
		for (Integer i : edges.keySet()) {
			Edge e = edges.get(i);
			e.to.setDist(e.weight*this.distTo);
		}
	}
}

class Edge {
	Node to;
	double weight;
	
	public Edge(Node to, double weight) { this.to = to; this.weight = weight; }
}
