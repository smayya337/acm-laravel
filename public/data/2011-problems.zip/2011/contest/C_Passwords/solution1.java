// UVA HSPC 2011
// Problem C: Password Validation
// Author: Kristine Collins (krc2p)

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PasswordValidation {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		while (in.hasNextLine()) {
			int cases = Integer.parseInt(in.nextLine());

			for (int i = 0; i < cases; i++) {
				String password = in.nextLine();
				if (isVaild(password))
					System.out.println("Valid Password");
				else
					System.out.println("Invalid Password");
			}
		}
	}

	public static boolean isVaild(String pass) {

		char[] c = pass.toCharArray();
		String regEx = "((?=.*\\d)(?=.*[a-z].*[a-z])(?=.*[A-Z].*[A-Z])(?=.*[! @ # $ % ^ & * . , ; / ?].*[! @ # $ % ^ & * . , ; / ?]).{9,20})";
		Pattern p = Pattern.compile(regEx);
		Matcher m = p.matcher(pass);

		if (consecutive(c) || palidrome(c) || containsSubstring(c)
				|| !m.matches())
			return false;

		return true;

	}

	public static boolean containsSubstring(char[] c) {
		String tmp = new String(c);
		c = tmp.toLowerCase().toCharArray();
		int index = 0;
		String[] seq = { "password", "virginia", "cavalier", "code", "drowssap", "ainigriv", "reilavac", "edoc"};

		for (int j = 0; j < seq.length; j++) {
			char[] sequence = seq[j].toCharArray();
			index = 0;
			for (int i = 0; i < c.length; i++) {
				if (c[i] == sequence[index]) {
					index++;
					if (index == sequence.length) return true;
				}
			}
			if (index == c.length)
				return true;
		}
		return false;
	}

	public static boolean palidrome(char[] c) {
		for (int i = 0; i < c.length / 2; i++) {
			if (c[i] != c[c.length - i - 1])
				return false;
		}
		return true;
	}

	public static boolean consecutive(char[] c) {
		int numbConsec = 0;
		for (int i = 1; i < c.length; i++) {
			if (c[i] == c[i - 1])
			{
				numbConsec++;
				if(numbConsec >= 3){
				 return true;
				 }
			}
			else
				numbConsec = 0;
		}

			return false;
	}
}
