// Solution to "Toy Story" from the 2018 HSPC
// Solution by Alyson Irizarry, 2018

import java.util.*;

class toystory {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int nCases = input.nextInt();
        input.nextLine();
       
        //iterate over each case
        for (int i = 0; i < nCases; i++) {
            String[] line = input.nextLine().trim().split(" ");
            System.out.println(line[0] + " " + line[1] + " " + (Integer.parseInt(line[2]) + 1));
        }
    }

}
