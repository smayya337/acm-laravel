/**
 * input generator for weighted
 *
 * run with a random seed (via command-line parameter) of 4 to
 * generate the weighted.judge.in file
 *
 * Written by Aaron Bloomfield, 2018
 */

#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <vector>
#include <algorithm>
#include <sstream>

using namespace std;

int main(int argc, char *argv[]) {

  // handle random seed
  int seed = time(NULL);
  if ( argc == 2 )
    sscanf(argv[1],"%d",&seed);
  srand(seed);
  
  cout << 102 << endl;
  // sample test case:
  cout << "2005_Season\n4\nLightning_McQueen\nStrip_Weathers\nChick_Hicks\nSlowy_McSlowFace\n3\nGlen_Ellyn 200 Lightning_McQueen Strip_Weathers Chick_Hicks\nDinoco_400 240 Lightning_McQueen Strip_Weathers Chick_Hicks\nPiston_Cup 300 Chick_Hicks Strip_Weathers Lightning_McQueen" << endl;
  // null test case:
  cout << "NULL_Season\n4\nLightning_McQueen\nStrip_Weathers\nChick_Hicks\nSlowy_McSlowFace\n3\nGlen_Ellyn 0 Lightning_McQueen Strip_Weathers Chick_Hicks\nDinoco_400 0 Lightning_McQueen Strip_Weathers Chick_Hicks\nPiston_Cup 0 Chick_Hicks Strip_Weathers Lightning_McQueen" << endl;

  // random test case:
  for ( int i = 0; i < 100; i++ ) {
    vector<string> cars, races;
    cars.clear();
    cout << "Season_" << i << endl;
    // output racers
    int c = rand() % 48 + 3;
    cout << c << endl;
    for ( int j = 0; j < c; j++ ) {
      stringstream carname;
      carname << "Car_" << j;
      cars.push_back(carname.str());
      cout << carname.str() << endl;
    }
    // output races
    int r = rand() % 99 + 2;
    cout << r << endl;
    for ( int j = 0; j < r; j++ ) {
      random_shuffle(cars.begin(),cars.end());
      cout << "Race_" << j << " " << (rand() % 100 + 1) << " "
	   << cars[0] << " " << cars[1] << " " << cars[2] << endl;
    }
  }
  return 0;
}
