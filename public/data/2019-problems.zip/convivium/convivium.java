import java.util.*;

public class Convivium {
    public static boolean bpm(boolean[][] bpGraph, int from, boolean[] seen, int[] matchR) {
        for (int to = 0; to < bpGraph[0].length; to++) {
            if (bpGraph[from][to] && !seen[to]) {
                seen[to] = true;
                if (matchR[to] < 0 || bpm(bpGraph, matchR[to], seen, matchR)) {
                    matchR[to] = from;
                    return true;
                }
            }
        }
        return false;
    }
    public static int maxBPM(boolean[][] bpGraph) {
        int[] matchR = new int[bpGraph[0].length];
        Arrays.fill(matchR, -1);
        int result = 0;
        for (int from = 0; from < bpGraph.length; from++) {
            boolean[] seen = new boolean[bpGraph[0].length];
            if (bpm(bpGraph, from, seen, matchR)) result++;
        }
        return result;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int cases = sc.nextInt();
        for(int caseno = 0; caseno < cases; caseno++) {
            int people = sc.nextInt();
            HashMap<String, ArrayList<String>> adjList = new HashMap<>();
            HashMap<String, Integer> team1 = new HashMap<>();
            HashMap<String, Integer> team2 = new HashMap<>();
            int distinct1 = 0;
            int distinct2 = 0;
            for (int i = 0; i < people; i++) {
                String name = sc.next();
                if (!team1.containsKey(name))
                    team1.put(name, distinct1++);
                adjList.put(name, new ArrayList<>());
                int num = sc.nextInt();
                for (int j = 0; j < num; j++) {
                    String p2 = sc.next();
                    if (!team2.containsKey(p2))
                        team2.put(p2, distinct2++);
                    adjList.get(name).add(p2);
                }
            }
            boolean[][] adjMat = new boolean[distinct1][distinct1];
            for (String s : adjList.keySet()) {
                for (String s2 : adjList.get(s)) {
                    adjMat[team1.get(s)][team2.get(s2)] = true;
                }
            }
            int matching = maxBPM(adjMat);
            System.out.println(matching);
        }
    }
}
