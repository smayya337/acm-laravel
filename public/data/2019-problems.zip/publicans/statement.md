# Pesky Publicans

Tax collectors in the Roman empire, called $publicans$, are not well perceived, and for good reason. However, they are necessary for the running of the empire. Your job is to estimate how much money Rome will receive in taxes. Not everyone pays, but at least one person is guaranteed to pay. The trouble is you can never really know who will and won't pay.

Given a list of what citizens would pay if they did pay taxes, output the average of all possible sums of taxes received.
