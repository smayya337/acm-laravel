# Solves "Sortle!" from the 2017 HSPC at UVa
# Solution by Marina Sanusi, 2017

from sys import stdin

if __name__ == '__main__':
  data = stdin.read().splitlines()
  n = int(data[0])
  i = 1
  for case in range(n):
    t = int(data[i])
    i += 1
    talent = {}
    talents = []

    for _ in range(t):
      person = data[i].split(" ")
      i += 1
      if person[1] in talent:
        talent[person[1]].append(person[0])
      else:
        talent[person[1]] = [person[0]]
        talents.append(person[1])

    talents.sort()
    print("Case " + str(case+1) + ":")

    for tal in talents:
      people = talent[tal]
      people.sort()
      print("\n".join(p + " " + tal for p in people))


