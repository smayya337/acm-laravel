#include <iostream>
#include <string>
using namespace std;

int main(int argc, char* argv[])
{
  int times;

  cin >> times;

  for(int i = 1; i <= times; i++)
    {
      cout << "Case " << i << ": ";      
      int x, y;
      cin >> x;
      cin >> y;
      x += y; 
      cout << x << "\n";
    }

  return 0;
}
