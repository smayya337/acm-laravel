import java.io.*;
import java.util.*;

public class solution3 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int numCases = in.nextInt();
		for(int aaa=1; aaa<=numCases;aaa++) {
			int numPoints = in.nextInt();
			double minX = Double.MAX_VALUE;
			double minY = Double.MAX_VALUE;
			double maxX = -Double.MAX_VALUE;
			double maxY = -Double.MAX_VALUE;
			for(int a=0;a<numPoints;a++) {
				double x = in.nextDouble();
				double y = in.nextDouble();
				minX = Math.min(minX, x);
				minY = Math.min(minY, y);
				maxX = Math.max(maxX, x);
				maxY = Math.max(maxY, y);
			}
			double area = (maxX - minX) * (maxY - minY);
			double perimeter = 2*(maxX - minX) + 2*(maxY - minY);
			System.out.println("Case " + aaa + ": Area " + area + ", Perimeter " + perimeter);
		}
	}
}
