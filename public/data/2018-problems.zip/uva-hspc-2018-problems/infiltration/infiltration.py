# Python Solution for Infiltration
# Marina Sanusi, 2018

import sys
from itertools import combinations

# return num nodes it dominates
def dominates(graph, n):
  if n in graph:
    return len(graph[n])
  else:
    return 0

# is a minimum dominating set
def min_dom_set(nodes, graph):
  nodes_covered = set()
  for node in nodes:
    nodes_covered.update(graph[node])
    nodes_covered.add(node)
  if len(nodes_covered) == len(graph):
    return True
  else:
    return False

# convert binary string input to nodes
def bs_to_nodes(bs):
  nodes = []
  for i, char in enumerate(bs):
    if char == '1': 
      nodes.append(i+1)
  return nodes
  
if __name__ == "__main__":
  n = int(sys.stdin.readline())

  for i in range(n):
    c = int(sys.stdin.readline())
    b_strings = []
    graph = {}
    for j in range(c):
      bs = sys.stdin.readline()
      graph[j+1] = bs_to_nodes(bs)

    # We can prove that a greedy algorithm always produces a dominating set of size at most 6
    # So that's our upper bound

    found_ans = False
    for j in range(6):
      if found_ans: break
      node_combinations = combinations(graph, j+1)
      for nc in node_combinations:
        if min_dom_set(nc, graph):
          print("Case " + str(i+1) + ": " + str(len(nc)) + " " + " ".join([str(x) for x in nc]))
          found_ans = True
          break
