/*
 * C++ solution to weighted
 *
 * by Aaron Bloomfield, 2018
 */

#include <iostream>
#include <string>
#include <map>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
  int n, r, c, score;
  string season, car, race, first, second, third;
  vector<string> cars;
  map<string,int> scores;
  
  cin >> n;
  for ( int i = 0; i < n; i++ ) {
    // read season:
    cin >> season;
    // read in cars
    cin >> c;
    for ( int j = 0; j < c; j++ ) {
      cin >> car;
      scores[car] = 0;
      cars.push_back(car);
    }
    sort(cars.begin(), cars.end());
    // read in races
    cin >> r;
    for ( int j = 0; j < r; j++ ) {
      cin >> race >> score >> first >> second >> third;
      scores[first] += score;
      scores[second] += score/2;
      scores[third] += score/4;
    }
    // output results
    cout << season << ":" << endl;
    for ( string car: cars )
      cout << car << " " << scores[car] << endl;
    // clear containers
    cars.clear();
    scores.clear();
  }
  return 0;
}
