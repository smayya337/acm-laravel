#include <iostream>

using namespace std;

int safe(int n, int p, int q, int j, int k);

int main() {
    int n;
    int p;
    int q;
    int j;
    int k;
    while (cin.good()) {
        cin >> n >> p >> q >> j >> k;
        if(n==0 && p ==0 && q == 0 && j ==0 && k ==0)
            break;
        cout << safe(n,p,q,j,k) << endl;
    }
}

int safe(int n, int p, int q, int j, int k) {
    if ( j < 0 || j >= n)
        return 0;
    if ( k == 0 && j >= p && j <= q ) return 1;
    else if (k == 0) return 0;
    else return safe(n,p,q,j+1,k-1) + safe(n,p,q,j-1,k-1);
}
