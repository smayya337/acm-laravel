# Casino Romale

It's a showdown in the Coliseum! The Roman Empire's finest warriors have flocked to the city of Rome for the world's first official rock, paper, scissors tournament. The excitement is palpable; even the townsfolk and farmers are getting into it! The emperor himself has said that he will play against the winner of the tournament, and if the emperor loses, he will pay the winner 1 million silver $denarius$. 

While this is great fun for nearly everyone involved, the treasurer isn't so happy about it. Not only is it a needless expense, it's also uncertain. To make his life a bit easier, why don't you find the expected value of the pay out, rounded to the nearest silver denarius? For example, if the winner of the tournament would beat the emperor 9 times out of 10, then the expected pay out is 900,000 silver denarii.

To make your job easier, scouters have determined the probability that each contestant will play rock, paper, or scissors. For example, if a given contestant's chances are 0.25, 0.5, and 0.25 respectively, then each round, they may choose either rock, paper, or scissors, but they are twice as likely to pick rock as paper or scissors. 

The tournament works as follows. Contestant 1 first goes against Contestant 2, Contestant 3 goes against Contestant 4, and so on. Then the winner of 1 vs 2 moves on to go against the winner of 3 vs 4, winner of 5 vs 6 moves on to go against the winner of 7 vs 8, and so on. Then the winner of 1, 2, 3, and 4 goes against the winner of 5, 6, 7, and 8. It continues like this until there is only one contestant remaining, who then goes against Caesar.
