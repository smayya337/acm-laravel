# Solves "Kirby Your Enthusiasm" from the 2017 HSPC at UVa
# Solution by Andrew Norton, 2017

from sys import stdin

if __name__ == '__main__':
  data = stdin.read().splitlines()[1:] # ignore first line

  line_num = 0 # Iterate over all the lines
  while line_num < len(data):
    num_actions = int(data[line_num])
    line_num += 1

    # A list of the actions for this particular testcase
    action_block = data[line_num:line_num + num_actions]

    curr_character = 'Kirby'  # holds the current character value of kirby
    for action_row in action_block:
      action = action_row.split()
      if action[0] == 'copy' and curr_character == 'Kirby':
        curr_character = action[1] # copy in the character
      elif action[0] == 'release':
        curr_character = 'Kirby'   # release the kirby clone

    print(curr_character)
    line_num += num_actions
