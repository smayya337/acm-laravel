// Solves "Collatz Chain Chomp" from the 2017 HSPC at UVa
// Solution by Aaron Bloomfield, 2017

#include <iostream>
using namespace std;
int main() {
  int n, x;
  cin >> n;
  for ( int i = 0; i < n; i++ ) {
    cin >> x;
    while ( x != 1 ) {
      if ( x % 2 == 0 )
	x /= 2;
      else
	x = 3*x+1;
      cout << x << " ";
    }
    cout << endl;
  }
  return 1;
}
