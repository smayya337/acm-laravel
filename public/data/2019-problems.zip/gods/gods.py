import sys

if __name__ == '__main__':
    test_cases = int(sys.stdin.readline())
    for _ in range(test_cases):
        gq = sys.stdin.readline()
        g = int(gq.split()[0])
        q = int(gq.split()[1])

        occupations = {}
        for _ in range(g):
            god, occ = sys.stdin.readline().split()
            occupations[god] = occ
        
        for _ in range(q):
            print(occupations[sys.stdin.readline().strip()])
