#include <iostream>
#include <vector>
using namespace std;

struct Crepe {
    long long x;
    long long y;
    long long r;
    bool seen;
    vector<int> adjacent;

    Crepe() {
        x = 0;
        y = 0;
        r = 0;
        seen = false;
    }

    Crepe(long long x, long long y, long long r) {
        this->x = x;
        this->y = y;
        this->r = r;
        
        seen = false;
    }

    bool intersects(const Crepe &other) const {
        return (x-other.x)*(x-other.x) + (y-other.y)*(y-other.y) <= (r+other.r)*(r+other.r);
    }

    void fill(Crepe *crepes) {
        seen = true;
        for(vector<int>::iterator it = adjacent.begin(); it != adjacent.end(); it++) {
            if(!crepes[*it].seen) {
                crepes[*it].fill(crepes);
            }
        }
    }
};

int main() {
    // Get the number test cases.
    int t;
    cin >> t;

    for(int itr = 0; itr < t; itr++) {
        // Get the number of crepes.
        int n;
        cin >> n;

        Crepe *crepes = new Crepe[n];

        // Read in the positions.
        for(int i = 0; i < n; i++) {
            long long x, y, r;
            cin >> x >> y >> r;

            crepes[i].x = x;
            crepes[i].y = y;
            crepes[i].r = r;
        }

        // Calculate intersections.
        for(int i = 0; i < n; i++) {
            for(int j = i+1; j < n; j++) {
                if(crepes[i].intersects(crepes[j])) {
                    crepes[i].adjacent.push_back(j);
                    crepes[j].adjacent.push_back(i);
                }
            }
        }

        // Compute the number of connected components.
        int groups = 0;
        for(int i = 0; i < n; i++) {
            if(!crepes[i].seen) {
                groups += 1;
                crepes[i].fill(crepes);
            }
        }

        cout << "Case " << itr+1 << ": " << groups << endl;

        delete[] crepes;
    }
}
