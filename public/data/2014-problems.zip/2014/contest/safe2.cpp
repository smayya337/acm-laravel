#include <iostream>
#include <map>
#include <utility>

using namespace std;

int safe(int n, int p, int q, int j, int k, map<pair<int,int>,int>* cache);

int main() {
    int n, p, q, j, k;
    while (cin.good()) {
        cin >> n >> p >> q >> j >> k;
        if(n==0)
            break;
        map<pair<int,int>,int> cache;
        cout << safe(n,p,q,j,k,&cache) << endl;
    }
}

int safe(int n, int p, int q, int j, int k, map<pair<int,int>,int>* cache) {
    if ( j < 0 || j >=n) return 0;
    if ( k == 0 && j >= p && j <= q ) return 1;
    if (k == 0) return 0;
    pair<int,int> pp(j,k);
    if(cache->find(pp) == cache->end()) {
        (*cache)[pp]=safe(n,p,q,j+1,k-1,cache) + safe(n,p,q,j-1,k-1,cache);
    }
    return (*cache)[pp];
}
