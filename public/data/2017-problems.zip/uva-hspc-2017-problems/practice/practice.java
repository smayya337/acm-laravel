// Solves "Practice" from the 2017 HSPC at UVa
// Solution by Joseph Tobin, 2017

import java.util.*;

public class practice {
  public static void main(String[] args) {
    Scanner kb = new Scanner(System.in);

    // Iterate over each case
    int numCases = kb.nextInt();
    for (int currCase = 0; currCase < numCases; currCase++) {
      int num = kb.nextInt();
      System.out.println(num * num);
      }
    }
}

