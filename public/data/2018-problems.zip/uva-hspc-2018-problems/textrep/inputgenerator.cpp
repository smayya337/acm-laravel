/**
 * input generator for textrep
 *
 * This must be compiled with -std=c++11
 *
 * run with a random seed (via command-line parameter) of 4 to
 * generate the weighted.judge.in file.
 *
 * This program takes, via stdin, a dictionary of words.  This can be
 * generated from the ispell dictionary on an Ubuntu 16.04 system as
 * follows:
 *
 * gzip -dc /usr/share/ispell/american.med+.mwl.gz | cut -f 1 -d / | konwert utf8-ascii | grep -v \? | ./input
 *
 * Written by Aaron Bloomfield, 2018
 */

#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <vector>
#include <algorithm>
#include <sstream>
#include <string>

using namespace std;

// words with "bing" in them, as per the ispell dictionary
string bingwords[] = {"absorbing", "backstabbing", "beachcombing",
"bibbing", "bing", "binge", "bingeing", "Bingham", "Binghamton",
"bingo", "blabbing", "blobbing", "bobbing", "cabbing", "clubbing",
"confabbing", "crabbing", "cribbing", "dabbing", "disturbing",
"drubbing", "dubbing", "fibbing", "flubbing", "fobbing", "gabbing",
"gobbing", "grabbing", "grubbing", "harbinger", "hobbing",
"hobnobbing", "jabbing", "jibbing", "jobbing", "lobbing", "mobbing",
"nabbing", "nightclubbing", "nonperturbing", "numbing", "plumbing",
"prefabbing", "rehabbing", "ribbing", "robbing", "rubbing",
"scabbing", "scrubbing", "slabbing", "snubbing", "sobbing",
"stabbing", "stubbing", "subbing", "subscribing", "swabbing",
"tabbing", "throbbing", "tubing", "webbing"};
int bingwords_size = 61;

string bings[] = {"bing", "Bing", "BING"};
int bings_size = 3;

int numfixedcases = 8;
const char* fixedcases = R"(2 Bing Bong
4 Bing Bong likes Riley
8 Spelled in lower case is bing bing bong
9 Do not replace the last 4 letters of gabbing
3 No names here
16 bing binG biNg biNG bIng bInG bINg bING Bing BinG BiNg BiNG BIng BInG BINg BING
61 absorbing backstabbing beachcombing bibbing bing binge bingeing Bingham Binghamton bingo blabbing blobbing bobbing cabbing clubbing confabbing crabbing cribbing dabbing disturbing drubbing dubbing fibbing flubbing fobbing gabbing gobbing grabbing grubbing harbinger hobbing hobnobbing jabbing jibbing jobbing lobbing mobbing nabbing nightclubbing nonperturbing numbing plumbing prefabbing rehabbing ribbing robbing rubbing scabbing scrubbing slabbing snubbing sobbing stabbing stubbing subbing subscribing swabbing tabbing throbbing tubing webbing
1 one
)";


int main(int argc, char *argv[]) {

  // handle random seed
  int seed = time(NULL);
  if ( argc == 2 )
    sscanf(argv[1],"%d",&seed);
  srand(seed);

  // read in dictionary
  vector<string> dict;
  string word;
  while ( cin.good() ) {
    cin >> word;
    if ( word == "" )
      continue;
    dict.push_back(word);
  }
  
  // output fixed testcases
  cout << (1000+numfixedcases) << "\n" << fixedcases;
  
  // random test cases:
  for ( int i = 0; i < 1000; i++ ) {
    int w = rand() % 90 + 3;
    cout << w << " ";
    for ( int j = 0; j < w; j++ ) {
      int which = rand() % 100;
      if ( which < 10 )
	cout << bingwords[rand() % bingwords_size];
      else if ( which < 20 )
	cout << bings[rand() % bings_size];
      else
	cout << dict[rand() % dict.size()];
      if ( j != w-1 )
	cout << " ";
    }
    cout << endl;
  }
  return 0;
}


