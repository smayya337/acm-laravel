import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int cases = sc.nextInt();
        for (int j = 0; j < cases; j++) {
            int[] readings = new int[10];
            for (int i = 0; i < 10; i++) {
                readings[i] = sc.nextInt();
            }
            int matching = 0;
            for (int i = 0; i < 10; i++) {
                if (sc.nextInt() == readings[i])
                    matching++;
            }
            if (matching >= 8)
                System.out.println("Oracle");
            else if (matching >= 5)
                System.out.println("Draw");
            else System.out.println("Fraud");
        }
    }
}
