// Solves "High Scores!" from the 2017 HSPC at UVa
// Solution by Joseph Tobin, 2017

import java.util.*;

public class prefix {
	public static void main(String args[]) {

		Scanner cin = new Scanner(System.in);

	    // Iterate over each case
	    int numCases = cin.nextInt();

	    for(int currCase = 0; currCase <  numCases; currCase++ ) {

	    	int numNames = cin.nextInt();
	    	String base = cin.next();

	    	for(int i = 0; i < numNames-1; i++) {
	    		String comp = cin.next();
	    		for(int j = 0; j < Math.min(base.length(), comp.length()); j++) {

	    			if(base.substring(j, j+1).equals(comp.substring(j, j + 1))) {

	    			}
	    			else {
	    				base = base.substring(0, j);
	    			}
	    		}
	    	}

	    	if(base.length() == 0) {
	    		System.out.println("No Common Prefix");
	    	}
	    	else {
	    		System.out.println(base);
	    	}
	    	



	    }


	}
}
