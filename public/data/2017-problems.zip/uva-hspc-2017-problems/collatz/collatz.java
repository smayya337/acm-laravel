// Solves "Collatz Chain Chomp" from the 2017 HSPC at UVa
// Solution by Marina Sanusi, 2017

import java.util.*;

public class collatz {
  public static void main(String[] args) {
    Scanner kb = new Scanner(System.in);

    // Iterate over each case
    int numCases = kb.nextInt();
    for (int currCase = 0; currCase < numCases; currCase++) {
      long num = kb.nextLong();
      String ans = "";
      // sad day because no recursion
      // but unfortunately this was more efficient
      while (num != 1) {
        if (num % 2 == 0) {
          num /= 2;
        } else {
          num = 3*num + 1;
        }
        ans += num + " ";
      }
      System.out.println(ans);
      }
    }
}

