import java.util.*;

public class Gods {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int cases = sc.nextInt();
        for(int caseno = 0; caseno < cases; caseno++) {
            int gods = sc.nextInt();
            int queries = sc.nextInt();
            HashMap<String, String> godOf = new HashMap<>();
            for (int i = 0; i < gods; i++)
                godOf.put(sc.next(), sc.next());
            for (int i = 0; i < queries; i++)
                System.out.println(godOf.get(sc.next()));
        }
    }
}
