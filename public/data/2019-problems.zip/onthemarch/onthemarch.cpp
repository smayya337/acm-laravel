#include <iostream>
#include <string>

bool dfs(int x, int y, int** map, bool** visited, int height, int width){
    if(map[y][x] == -3)
        return true;
    if(visited[y][x]) return false;
    visited[y][x] = true;
    if(x != 0 && !visited[y][x - 1] && map[y][x - 1] != -1 && dfs(x - 1, y, map, visited, height, width))
        return true;
    if(x != width - 1 && !visited[y][x + 1] && map[y][x + 1] != -1 && dfs(x + 1, y, map, visited, height, width))
        return true;
    if(y != 0 && !visited[y - 1][x] && map[y - 1][x] != -1 && dfs(x, y - 1, map, visited, height, width))
        return true;
    return y != height - 1 && !visited[y + 1][x] && map[y + 1][x] != -1 && dfs(x, y + 1, map, visited, height, width);
}

int main(int argc, char** argv) {
    int cases;
    std::cin >> cases;
    for (int caseno = 0; caseno < cases; caseno++) {
        int height, width;
        std::cin >> height >> width;
        int** map = new int*[height];
        for(int i = 0; i < height; i++) map[i] = new int[width];
        bool** visited = new bool*[height];
        for(int i = 0; i < height; i++) visited[i] = new bool[width];
        int rX, rY = rX = -1;
        std::string dummy;
        std::getline(std::cin, dummy);
        for (int i = 0; i < height; i++) {
            std::string line;
            std::getline(std::cin, line);
            for (int j = 0; j < width; j++) {
                char c = line.at(j);
                if (c == 'R') {
                    map[i][j] = 0;
                    rX = j;
                    rY = i;
                }
                if (c == 'A')
                    map[i][j] = -3;
                if (c == 'O')
                    map[i][j] = 1;
                if (c == 'X')
                    map[i][j] = -1;
                visited[i][j] = false;
            }
        }
        if (dfs(rX, rY, map, visited, height, width))
            std::cout << "March onward!" << std::endl;
        else std::cout << "Stay home!" << std::endl;
    }
}
