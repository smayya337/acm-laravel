/**Problem: Reducing Improper Fractions
  * Solver: Daniel Epstein dae5y@virginia.edu
  * Problem Writers: Allison Light aml9j@virginia.edu, Matthew Hurtz mnh7mc@virginia.edu
  * Time Taken: 2 min
  * Overall Thoughts: Good problem, easy/straightforward to understand & code. We should decide how 
  * "evil" we want to be--should we essentially require the use of mod by making a really large numerator
  * & small denom to mess up repeated subtraction?
  * Things to fix: use standard input & output scheme (Case X: answer, number of cases as the first line)
**/
  
import java.io.*;
import java.util.*;

public class solution1 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int numCases = in.nextInt();
		for(int aaa=1;aaa<=numCases;aaa++) {
			int N = in.nextInt();
			int D = in.nextInt();
			int I = N/D;
			int R = N%D;
			System.out.print("Case " + aaa + ": ");
			if(I!=0 && R == 0)
				System.out.print(I);
			else if(I!=0)
				System.out.print(I + " ");
			if(R != 0)
				System.out.println(R + "/" + D);
			if (I == 0 && R == 0)
			    System.out.println("0");
			else if (R == 0)
			    System.out.println();
		}
	}
}
