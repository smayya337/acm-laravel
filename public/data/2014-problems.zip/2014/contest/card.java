import java.util.*;

public class card {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int g,x;
        String n;
        x=in.nextInt();
        for(int i=0; i<x; i++) {
            n=in.next();
            g=in.nextInt();
            if ( g <= 59 )
                System.out.println(n+ " F" );
            else if ( g <= 66 )
                System.out.println(n+ " D" );
            else if ( g <= 69 )
                System.out.println(n+ " D+" );
            else if ( g <= 76 )
                System.out.println(n+ " C" );
            else if ( g <= 79 )
                System.out.println(n+ " C+" );
            else if ( g <= 86 )
                System.out.println(n+ " B" );
            else if ( g <= 89 )
                System.out.println(n+ " B+" );
            else if ( g <= 96 )
                System.out.println(n+ " A" );
            else
                System.out.println(n+ " A+" );
        }
    }
}
